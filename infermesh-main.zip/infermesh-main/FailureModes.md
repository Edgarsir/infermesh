# InferMesh: System Failure Modes & Guarantees

This document maps the requested structural failure guarantees directly to the implemented codebase.

## 1. C++ Worker Crashes Mid-Inference
*   **Behavior**: The socket connection breaks. Go's proxy catches `io.EOF` or an immediate gRPC error. The Gateway maps this logic to an HTTP `503 Service Unavailable`.
*   **System Response**: The `Proxy` logs the failure. The `HealthMonitor` (`pkg/worker/health.go` and `watcher.go`) flags the worker as `DEAD`. The Router (`pkg/router/router.go`) bypasses it. The `ProcessWatcher` automatically spawns a replacement worker to replenish the pool.

## 2. All C++ Workers Dead Simultaneously
*   **Behavior**: The `Router` fails to find an available worker immediately.
*   **System Response**: Incoming requests enter the `Queue` (`pkg/worker/queue.go`). They wait up to their `context.Deadline`. If a replacement worker boots and becomes `HEALTHY` within the window, the `Dispatcher` (`pkg/router/dispatcher.go`) immediately pulls the waiting request and serves it. If the deadline expires, the queue returns `ErrQueueTimeout`, triggering a `503` to the client. No manual intervention is needed.

## 3. S3 Unreachable During Deployment
*   **Behavior**: The `Downloader` (`pkg/artifact/downloader.go`) encounters network failures.
*   **System Response**: The download fails and an error is returned. The `DeployManager` (`pkg/webhook/deployer.go`) drops the deployment job and logs the error. Because there are no automatic retries loops natively built in, the pipeline stops safely. The currently running model remains completely untouched in the `current` deployment directory.

## 4. Shadow Inference Fails (Bad Model Weights)
*   **Behavior**: The model passes the SHA-256 hash check, but produces mathematically incorrect outputs.
*   **System Response**: The `ShadowTester` (`pkg/deployment/shadow.go`) spins up a temporary worker with the new model, sends a golden request, and compares the output probabilities. If it diverges beyond the floating-point tolerance, it returns an error. The `TransactionManager` aborts the `Swap`, preventing the bad model from ever reaching production.

## 5. Go Gateway Crashes
*   **Behavior**: The main `coordinator` binary dies (e.g., OOM, Segmentation Fault, Server Reboot). 
*   **System Response**: The C++ workers independently continue running. When Go restarts, the `RecoveryManager` (`pkg/recovery/recovery.go`) scans the UNIX Domain Sockets directory (e.g., `/tmp/`), pings the existing processes, adopts them back into its internal `Pool`, constructs the `Registry` from the DB, and resumes serving traffic instantly.

## 6. GPU Out-Of-Memory (OOM)
*   **Behavior**: A tenant sends a validly shaped but exceptionally large or dense payload that exhausts VRAM.
*   **System Response**: The C++ memory layer catches the `std::bad_alloc` or backend framework exception. It prevents the C++ binary from crashing. It populates the `error_message` field in `PredictResponse` (added in `proto/inference.proto`). Go receives this response, recognizes the failure, decrements the active counter, and pushes an async JSON log attributing the `OOM_ERROR` explicitly to that `tenant_id` without penalizing the overall C++ worker process.
