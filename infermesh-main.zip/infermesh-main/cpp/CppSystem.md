/**
 * CppSystem.md
 * 
 * Documentation linking all C++ components implemented in Part 1.
 * Provides a high-level map of the modules.
 */
# Component Map

1. **Config (Startup)**: Environment-variable driven configuration (`Config.h`, `Config.cpp`).
2. **HardwareChecker (Startup)**: Verifies GPU existence and VRAM availability (`HardwareChecker.h`, `HardwareChecker.cpp`).
3. **ModelSession (Startup/Runtime)**: Manages model loading, warmup, and execution (`ModelSession.h`, `ModelSession.cpp`).
4. **ModelHasher (Startup)**: Computes model fingerprint to prevent version mismatch (`ModelHasher.h`, `ModelHasher.cpp`).
5. **WorkerStatus (Startup)**: Signals readiness to Go supervisor (`WorkerStatus.h`, `WorkerStatus.cpp`).
6. **ServerBinder (Runtime)**: Binds gRPC server to Unix socket (`ServerBinder.h`, `ServerBinder.cpp`).
7. **RequestValidator (Runtime)**: Validates incoming requests (`RequestValidator.h`, `RequestValidator.cpp`).
8. **TensorBuilder (Runtime)**: Handles zero-copy tensor creation (`TensorBuilder.h`, `TensorBuilder.cpp`).
9. **InferenceService (Runtime)**: Thread-safe gRPC handler (`InferenceService.h`, `InferenceService.cpp`).
10. **PostProcessor (Runtime)**: Converts raw outputs to business logic (`PostProcessor.h`, `PostProcessor.cpp`).
11. **ResponseSerializer (Runtime)**: Serializes responses and metrics (`ResponseSerializer.h`, `ResponseSerializer.cpp`).
12. **MemoryManager (Runtime)**: Prevents memory leaks (`MemoryManager.h`, `MemoryManager.cpp`).
13. **SignalHandler (Shutdown)**: Graceful shutdown logic (`SignalHandler.h`, `SignalHandler.cpp`).
