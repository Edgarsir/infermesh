/**
 * Logger.h
 * 
 * Centralized logging facility for the C++ worker.
 * 
 * Responsibilities:
 * 1. Structured Logging: Writes ISO-8601 timestamps, log levels, and request IDs.
 * 2. File Output: appends to a persistent log file, not just stderr.
 * 3. Status Signalling: For FATAL errors, updates the dedicated status file 
 *    so the Go supervisor can react instantly (faster than process exit detection).
 */
#pragma once

#include <string>
#include <mutex>

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    FATAL
};

class Logger {
public:
    /**
     * Init
     * 
     * Configures the logger with file paths.
     * @param logFilePath Where to write the structured logs.
     * @param statusFilePath Where to write CRASHED signal on fatal errors.
     */
    static void Init(const std::string& logFilePath, const std::string& statusFilePath);

    /**
     * Log
     * 
     * Writes a structured log entry.
     * 
     * @param level Severity level.
     * @param message Human-readable description.
     * @param requestId Optional request ID context (empty if system-wide).
     */
    static void Log(LogLevel level, const std::string& message, const std::string& requestId = "");

private:
    static std::string logFile;
    static std::string statusFile;
    static std::mutex mutex;

    static std::string LevelToString(LogLevel level);
    static std::string CurrentTimestamp();
};
