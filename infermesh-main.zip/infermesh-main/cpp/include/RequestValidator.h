#pragma once

#include "DataTypes.h"

class RequestValidator {
public:
    static void Validate(const InferenceRequest& request, int64_t maxLatencyMs = 5000);
};
