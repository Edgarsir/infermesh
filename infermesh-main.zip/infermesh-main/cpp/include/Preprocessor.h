#pragma once

#include <string>
#include <vector>

struct PreprocessingParams {
    std::vector<float> means;
    std::vector<float> std_devs;
};

/**
 * Preprocessor handles the mathematical scaling of raw feature vectors
 * before they are packed into the TensorPool buffers. 
 * By keeping this strictly in C++, we guarantee that the specific weights.pt 
 * and its specific preprocessing_config.json are atomically bound together.
 */
class Preprocessor {
public:
    /**
     * Loads the atomic pair configuration file that always ships identically 
     * alongside the model weights.
     */
    static PreprocessingParams LoadConfig(const std::string& configFilePath);

    /**
     * Applies standard scaling: (x - mean) / std_dev
     * Modifies the rawFeatures vector in place for zero-allocation performance.
     */
    static void NormalizeInPlace(std::vector<float>& rawFeatures, const PreprocessingParams& params);
};
