#pragma once

#include <vector>
#include <mutex>
#include <condition_variable>
#include <functional>

// Mock of cudaStream_t
typedef int cudaStream_t;

/**
 * CudaStreamPool maintains a set of CUDA hardware streams.
 * Streams allow the GPU to execute operations asynchronously. By using multiple streams,
 * we can overlap the Memory Transfer (Device-to-Host) of Batch N-1 with the actual
 * Compute Kernel execution of Batch N, achieving near 100% GPU utilization.
 */
class CudaStreamPool {
public:
    CudaStreamPool(int numStreams);
    ~CudaStreamPool();

    /**
     * Blocks until a CUDA stream is available.
     * In a real implementation, you might prefer binding a stream permanently 
     * to a specific memory buffer (TensorPool buffer) to avoid synchronization.
     */
    cudaStream_t AcquireStream();
    void ReleaseStream(cudaStream_t stream);

private:
    std::vector<cudaStream_t> streams;
    std::mutex mtx;
    std::condition_variable cv;
};

/**
 * PipelinedEngine mocks the asynchronous CUDA API to demonstrate 
 * overlapping memory transfers and compute kernels.
 */
class PipelinedEngine {
public:
    PipelinedEngine(int numStreams);
    
    // Abstracted async operations
    void MemcpyHostToDeviceAsync(void* dst, void* src, size_t size, cudaStream_t stream);
    void ExecuteModelKernelAsync(void* input, void* output, int batchSize, cudaStream_t stream);
    void MemcpyDeviceToHostAsync(void* dst, void* src, size_t size, cudaStream_t stream);
    
    // Synchronize the stream (wait for all operations on this stream to complete)
    void StreamSynchronize(cudaStream_t stream);

    CudaStreamPool* GetStreamPool() { return pool; }

private:
    CudaStreamPool* pool;
};
