/**
 * PostProcessor.h
 * 
 * Responsible for interpreting the raw mathematical output of the neural network
 * into actionable business domain objects (e.g., Trading Signals).
 * 
 * This logic is tightly coupled to the model's training objective.
 * For example: Converting a Softmax distribution [0.1, 0.8, 0.1] -> "SELL" with 80% confidence.
 */
#pragma once

#include "DataTypes.h"
#include <string>
#include <vector>

struct InferenceResponse {
    std::string requestId;
    std::string label;       // "BUY", "SELL", "HOLD"
    float confidenceScore;   // 0.0 to 1.0 (or higher if not normalized)
    std::vector<float> rawProbabilities; 
    double processingTimeMs;
    std::string errorMessage; // Set if request failed internally (e.g. OOM)
};

class PostProcessor {
public:
    /**
     * Interpret
     * 
     * Applies ArgMax and class mapping logic to the raw output tensor.
     * 
     * @param result The raw output from the inference engine.
     * @param requestId The original request ID for correlation.
     * @return A structured response ready for Protobuf serialization.
     */
    static InferenceResponse Interpret(const InferenceResult& result, const std::string& requestId);

private:
    // Hardcoded mapping based on training: 0=HOLD, 1=BUY, 2=SELL
    // This MUST match the label encoder used during training.
    static const std::vector<std::string> CLASS_LABELS;
};
