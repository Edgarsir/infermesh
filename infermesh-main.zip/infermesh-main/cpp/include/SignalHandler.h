/**
 * SignalHandler.h
 * 
 * Manages the graceful shutdown sequence when the process receives termination signals (SIGTERM/SIGINT).
 * 
 * Key Responsibilities:
 * 1. Catch OS signals.
 * 2. Unbind the server from the socket immediately (stop new connections).
 * 3. Wait for ongoing inference to complete (don't kill GPU mid-kernel).
 * 4. Explicitly destroy ModelSession to free VRAM.
 * 5. Clean up the Unix Domain Socket file.
 */
#pragma once

#include <functional>
#include <string>

class SignalHandler {
public:
    /**
     * SetupSignalHandling
     * 
     * Registers the signal handlers (SIGTERM, SIGINT).
     * 
     * @param shutdownCallback A function to call when shutdown is triggered (e.g., server stop).
     */
    static void SetupSignalHandling(std::function<void()> shutdownCallback);

    /**
     * SetupCrashHandling
     * 
     * Registers handlers for catastrophic faults (SIGSEGV, SIGABRT).
     * This ensures the process writes a "CRASHED" state to its status file
     * and re-raises the signal to allow the OS to generate a core dump.
     */
    static void SetupCrashHandling();
    /**
     * PerformCleanup
     * 
     * Executed after the server loop exits but before process death.
     * Handles VRAM release and socket file deletion.
     * 
     * @param socketPath Path to the Unix socket file to unlink.
     */
    static void PerformCleanup(const std::string& socketPath);
};
