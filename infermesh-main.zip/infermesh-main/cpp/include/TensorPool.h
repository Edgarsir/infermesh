#pragma once

#include <vector>
#include <mutex>
#include <condition_variable>
#include <chrono>

/**
 * TensorBuffer represents a pre-allocated chunk of unified memory or GPU VRAM.
 */
struct TensorBuffer {
    int id;
    void* data; 
    size_t sizeBytes;
};

/**
 * TensorPool manages a deterministic, fixed-size pool of GPU memory buffers to 
 * eliminate the profound latency and memory fragmentation of synchronous
 * cudaMalloc/cudaFree during individual inference requests.
 */
class TensorPool {
public:
    /**
     * @param poolSize The exact number of maximum concurrent batches to buffer.
     * @param bufferSizeBytes The dimensions required for MaxBatchSize * FeatureDim * sizeof(float).
     */
    TensorPool(int poolSize, size_t bufferSizeBytes);
    ~TensorPool();

    /**
     * AcquireBuffer
     * Blocks the calling thread until a pre-allocated tensor buffer is free.
     * @param timeoutMs Maximum time to wait in the queue before shedding the request.
     * @return TensorBuffer* or nullptr if the timeout expires (pool exhausted).
     */
    TensorBuffer* AcquireBuffer(int timeoutMs = 100);

    /**
     * ReleaseBuffer
     * Returns the buffer to the warm pool and wakes up any blocked threads awaiting memory.
     */
    void ReleaseBuffer(TensorBuffer* buffer);

private:
    std::vector<TensorBuffer*> availableBuffers;
    std::vector<TensorBuffer*> allBuffers; // Used for clean destruction

    std::mutex mtx;
    std::condition_variable cv;
    int totalPoolSize;
};
