#pragma once

#include "ModelSession.h"
#include <vector>
#include <memory>

class SelfConsistencyChecker {
public:
    /**
     * @param session The active inference model session.
     * @param checkInterval Trigger a background / inline check every N inferences.
     * @param tolerance The max floating-point deviation allowed before declaring corruption.
     */
    SelfConsistencyChecker(std::shared_ptr<ModelSession> session, int checkInterval, float tolerance = 1e-4f);

    /**
     * Initializes the golden standard.
     * Should be called right after model load. It runs a predefined or random deterministic
     * tensor and records the exact output as the "Golden Output".
     */
    void InitializeGoldenStandard(const std::vector<float>& goldenInput);

    /**
     * Called on every inference request. Increment a counter. If counter % checkInterval == 0,
     * runs the consistency check.
     * 
     * @return true if the system is mathematically stable, false if corruption is detected.
     */
    bool CheckIfTime();

private:
    std::shared_ptr<ModelSession> session;
    int checkInterval;
    float tolerance;
    int inferenceCount;

    std::vector<float> goldenInput;
    std::vector<float> goldenExpectedOutput;

    bool RunConsistencyCheck();
};
