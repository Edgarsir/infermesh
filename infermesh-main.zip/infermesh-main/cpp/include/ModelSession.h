#pragma once

#include <string>
#include <memory>
// #include <torch/script.h> // Example for LibTorch

/**
 * ModelSession
 * 
 * Represents the persistent state of the loaded model.
 * Created once at startup and reused for every inference request.
 * 
 * Responsibilities:
 * - Load model weights from disk.
 * - Validate model architecture/version compatibility.
 * - Hold the model in memory/VRAM for the lifetime of the process.
 */
class ModelSession {
public:
    /**
     * Load
     * 
     * Static factory method to create and initialize a session.
     * Takes the path to weights and the target GPU device.
     * 
     * Throws descriptive std::runtime_error for all failure modes:
     * - File not found
     * - Corrupted file
     * - Version mismatch
     */
    static std::shared_ptr<ModelSession> Load(const std::string& weightsPath, int deviceId);

    // ... Inference methods would go here (Part 3)

    /**
     * RunInference
     * 
     * Executes the model forward pass.
     * 
     * @param inputTensor A pointer to the prepared input tensor (void* mock).
     * @param timeoutMs Maximum allowable time for inference in milliseconds.
     * @return InferenceResult containing CPU-accessible output data.
     * @throws std::runtime_error on timeout or execution failure.
     */
    InferenceResult RunInference(void* inputTensor, int timeoutMs = 1000);

private:
    ModelSession(); // Private constructor to force usage of Load()
    
    // torch::jit::script::Module model; // Actual model object
    std::string loadedPath;
    int boundDevice;
};
