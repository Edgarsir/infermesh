/**
 * InferenceService.h
 * 
 * Implements the gRPC service logic.
 * 
 * Concurrency Model:
 * - The gRPC framework (Server) manages a thread pool for I/O (receiving bytes, parsing Protobuf).
 * - However, the `Predict` method enforces a critical section for the actual GPU execution.
 * - This ensures we don't crash the GPU with concurrent kernels, while keeping the network stack responsive.
 */
#pragma once

#include "DataTypes.h"
#include "ModelSession.h"
#include <mutex>
#include <memory>
#include <string>

// Mocking the gRPC Service base class
class InferenceService {
public:
    InferenceService(std::shared_ptr<ModelSession> session);

    /**
     * Predict
     * 
     * The main gRPC handler.
     * 1. Deserializes request (handled by gRPC, passed as arg here).
     * 2. Acquires lock (Wait for GPU).
     * 3. Validates -> Builds Tensor -> Infers -> PostProcesses.
     * 4. Releases lock.
     * 5. Returns response.
     */
    std::string Predict(const InferenceRequest& request);

    /**
     * PredictBatch
     * 
     * Handles dynamic batching from Go.
     * 1. Deserializes batched request.
     * 2. Builds a single Tensor [BatchSize, FeatureDim].
     * 3. Infers -> PostProcesses [BatchSize] results.
     */
    std::string PredictBatch(const InferenceBatchRequest& requestBatch);

private:
    std::shared_ptr<ModelSession> session;
    
    // The Gatekeeper: Forces input serialization for the GPU.
    // Even if gRPC calls Predict() on 10 threads, they will serialize here.
    std::mutex inferenceMutex; 
};
