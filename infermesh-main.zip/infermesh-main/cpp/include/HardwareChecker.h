/**
 * HardwareChecker.h
 * 
 * Verifies that the hardware configuration requested is physically present and capable.
 * This prevents cryptic runtime errors (like CUDA OOM or device ordinal errors) 
 * by checking constraints *before* any heavy lifting.
 */
#pragma once

#include "Config.h"
#include <string>

class HardwareChecker {
public:
    /**
     * VerifyHardware
     * 
     * Performs all startup checks:
     * 1. Validates the requested GPU ID exists.
     * 2. Checks available VRAM against estimated model requirements.
     * 
     * Throws a specific std::runtime_error if any check fails, with a clear message.
     */
    static void VerifyHardware(const AppConfig& config);

    /**
     * EstimatedVRAMRequirement
     * 
     * Returns the estimated VRAM (in bytes) required for the model.
     * In a real implementation, this would look up model metadata.
     * For now, we return a safe default or placeholder.
     */
    static size_t EstimatedVRAMRequirement();
};
