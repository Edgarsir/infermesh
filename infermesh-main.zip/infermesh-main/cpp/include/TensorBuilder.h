/**
 * TensorBuilder.h
 * 
 * Responsible for converting raw C++ data structures (std::vector) into 
 * hardware-accelerated Tensor objects (e.g., torch::Tensor) ready for inference.
 * 
 * Key Responsibilities:
 * 1. Zero-Copy Wrapping: Wrap existing memory without duplication on CPU.
 * 2. Reshaping: Correctly view the flat array as a multi-dimensional tensor.
 * 3. Device Transfer: efficiently move data to GPU VRAM.
 */
#pragma once

#include "DataTypes.h"
#include <memory> 

// Forward declaration of the Tensor type to avoid hard dependency on LibTorch in headers
// if we were using a PIMPL idiom or purely abstract interfaces. 
// For this logical implementation, we'll assume a "Tensor" type exists.
namespace torch { class Tensor; }

class TensorBuilder {
public:
    /**
     * BuildInputTensor
     * 
     * Constructs a prepared Tensor from the request data.
     * 
     * @param request The validated inference request containing raw data.
     * @param deviceId The GPU device index to move the tensor to (-1 for CPU).
     * @return A Tensor object (mocked here as void* for compilation, strictly typed in real code).
     */
    static void* BuildInputTensor(const InferenceRequest& request, int deviceId);
};
