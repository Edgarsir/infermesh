#pragma once

#include <string>
#include <vector>
#include <cstdint>

/**
 * InferenceRequest
 * 
 * Represents the parsed Protobuf message.
 */
struct InferenceRequest {
    std::string requestId;
    int64_t timestampUnixMs;
    int32_t featureDim; 
    std::vector<float> features;
};

/**
 * InferenceResult
 * 
 * Holds the output of a model inference call.
 * 
 * - outputData: The raw float array result, copied back to CPU.
 * - executionTimeMs: How long the actual GPU compute took.
 * - outputShape: The dimensions of the output tensor [Batch, OutputDim].
 */
struct InferenceResult {
    std::vector<float> outputData;
    std::vector<int64_t> outputShape;
    double executionTimeMs;
};
