/**
 * MemoryManager.h
 * 
 * Ensures robust cleanup of tensor resources to prevent memory leaks.
 * This is critical in long-running services where even small leaks 
 * accumulated over millions of requests will crash the process (OOM).
 * 
 * Responsibilities:
 * 1. Tracking allocated tensors during a request.
 * 2. Explicitly freeing memory (CPU & GPU) after the response is sent.
 * 3. Clearing unexpected debris from failed requests.
 */
#pragma once

#include <vector>
#include <mutex>

class MemoryManager {
public:
    /**
     * RegisterTensor
     * 
     * Registers a raw tensor pointer for lifecycle management.
     * The manager assumes ownership and will free it when ReleaseAll is called.
     * 
     * @param tensorPtr Pointer to the tensor object (mocked as void*).
     */
    static void RegisterTensor(void* tensorPtr);

    /**
     * ReleaseTensor
     * 
     * Immediately frees a specific tensor resource.
     * Used when a tensor is no longer needed in the middle of a pipeline
     * (e.g. freeing the CPU input tensor once it's on GPU).
     */
    static void ReleaseTensor(void* tensorPtr);

    /**
     * CleanupRequest
     * 
     * Frees all registered resources for the current request.
     * MUST be called at the end of every request cycle (success or failure).
     */
    static void CleanupRequest();

private:
    // Thread-local storage would be ideal here for a multi-threaded server.
    // For this simple mock, we'll use a static vector protected by a mutex
    // to simulate a single request context or shared pool.
    static std::vector<void*> activeTensors;
    static std::mutex mutex;
};
