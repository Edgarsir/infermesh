#pragma once

#include <string>
#include "Config.h"

// Forward declaration if we were using real gRPC
// class InferenceService; 

class ServerBinder {
public:
    /**
     * RunServer
     * 
     * Binds the gRPC server to the Unix Domain Socket specified in config.
     * Enters the main request loop. This function blocks until shutdown.
     */
    static void RunServer(const AppConfig& config);
};
