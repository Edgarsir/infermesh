/**
 * ResponseSerializer.h
 * 
 * Responsible for the final step before the data leaves the C++ system.
 * 
 * Objectives:
 * 1. Convert the internal C++ Infermesh:Response struct into a binary Blob 
 *    (e.g., Protobuf message) for network transmission.
 * 2. Calculate and inject critical observability metrics:
 *    - Internal Latency: The precise time spent inside the C++ process.
 *    - Timestamps: When the process finished.
 */
#pragma once

#include "PostProcessor.h"
#include <string>
#include <cstdint>

// Forward declaration of the Protobuf class (mock)
// namespace infermesh { class InferenceResponseProto; }

class ResponseSerializer {
public:
    /**
     * Serialize
     * 
     * Converts the structured business response into a serialized byte string.
     * Computes the final 'internal_latency' by comparing current time with start time.
     * 
     * @param response The structured business logic output.
     * @param startTimeUnixMs The timestamp when the request first entered the C++ handler.
     * @return A std::string containing the serialized binary data.
     */
    static std::string Serialize(const InferenceResponse& response, int64_t startTimeUnixMs);
};
