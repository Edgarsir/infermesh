#pragma once

#include <string>
#include <vector>

/**
 * AppConfig
 * 
 * Holds the runtime configuration for the InferMesh C++ Core.
 * Populated strictly from Environment Variables to ensure
 * reliability during the critical startup phase (avoiding disk I/O risks).
 */
struct AppConfig {
    // The Unix Domain Socket path this process will bind to for receiving requests.
    std::string socketPath;
    
    // Absolute filesystem path to the model weights file.
    std::string modelWeightsPath;
    
    // The specific GPU index (e.g., 0 for cuda:0) to start this instance on.
    int gpuDeviceId;
    
    // The maximum number of requests to batch together for inference.
    int maxBatchSize;
    
    // Max seconds allowed for the startup sequence to complete before self-termination.
    int startupTimeoutSeconds;

    /**
     * Parsing Logic:
     * Reads from std::getenv. Throws std::runtime_error if critical
     * variables are missing or malformed.
     */
    static AppConfig LoadFromEnv();
};
