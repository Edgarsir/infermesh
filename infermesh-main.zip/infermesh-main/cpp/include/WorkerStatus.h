#pragma once

#include <string>
#include <fstream>

class WorkerStatus {
public:
    /**
     * SignalReady
     * 
     * Writes the "READY" signal byte to a specific status file monitored by the
     * Go supervisor. This is the handshake confirmation that startup, model load,
     * and warmup are all complete.
     */
    static void SignalReady();

    /**
     * SignalDegraded
     * 
     * Writes "DEGRADED" to the status file. This actively tells the Go Go coordinator
     * that this worker is alive (so the TCP port is working), but the internal math
     * has drifted or corrupted. Go will stop routing traffic here and cleanly kill it.
     */
    static void SignalDegraded();

    /**
     * UpdateWatchdog
     * 
     * Writes the current epoch timestamp to the watchdog file. 
     * Proves to Go that the process is not frozen via deadlock.
     */
    static void UpdateWatchdog();

    /**
     * GetStatusFilePath
     * 
     * Returns the agreed-upon path for the status file.
     * Often communicated via env var or convention.
     */
    static std::string GetStatusFilePath();
};
