#pragma once

#include <string>
#include <vector>

class ModelHasher {
public:
    /**
     * ComputeHash
     * 
     * Reads the file at the given path and computes its SHA-256 hash.
     * This hash is used to verify that the worker loaded the correct model file,
     * preventing silent mismatches in distributed deployments.
     */
    static std::string ComputeHash(const std::string& filePath);
};
