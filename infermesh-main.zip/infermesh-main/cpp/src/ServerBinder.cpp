#include "ServerBinder.h"
#include <iostream>
#include <thread>
#include <chrono>

// #include <grpcpp/grpcpp.h>
// #include "inference.grpc.pb.h"

void ServerBinder::RunServer(const AppConfig& config) {
    std::cout << "[INFO] Binding gRPC Server to Unix Socket: " << config.socketPath << std::endl;

    // -------------------------------------------------------------------------
    // BIND TO SOCKET
    // -------------------------------------------------------------------------
    // Real implementation:
    // std::string server_address = "unix://" + config.socketPath;
    // InferenceServiceImpl service;
    // grpc::ServerBuilder builder;
    // builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    // builder.RegisterService(&service);
    // std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
    
    std::cout << "       Server listening on " << config.socketPath << std::endl;
    std::cout << "       Entering Request Loop (Blocking)..." << std::endl;

    // -------------------------------------------------------------------------
    // REQUEST LOOP (Blocking)
    // -------------------------------------------------------------------------
    // server->Wait();

    // MOCK: Simulate a running server loop for demonstration
    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        // Check for shutdown signal here in real app
    }
}
