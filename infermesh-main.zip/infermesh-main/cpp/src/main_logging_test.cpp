#include "../include/Logger.h"
#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::cout << "[INFO] TEST: Error Reporting Logic" << std::endl;

    std::string logPath = "test_worker.log";
    std::string statusPath = "test_worker.status";

    // 1. Initialize
    Logger::Init(logPath, statusPath);

    // 2. Clear previous test artifacts
    std::remove(logPath.c_str());
    std::ofstream(statusPath) << "READY"; // Simulate running state

    // 3. Log Info (Should verify log file creation)
    Logger::Log(LogLevel::INFO, "Worker started.", "startup");
    
    // 4. Log Request Error (Contextual)
    Logger::Log(LogLevel::ERROR, "GPU Out of Memory for tensor allocation", "req_123");

    // Check Log File Content
    std::ifstream lf(logPath);
    std::string line;
    bool foundError = false;
    while (std::getline(lf, line)) {
        std::cout << "LOG: " << line << std::endl;
        if (line.find("GPU Out of Memory") != std::string::npos && line.find("req_123") != std::string::npos) {
            foundError = true;
        }
    }
    lf.close();

    if (!foundError) {
        std::cerr << "[FAIL] Log file missing expected error entry." << std::endl;
        return 1;
    }

    // 5. Log FATAL (Should trigger status file update)
    Logger::Log(LogLevel::FATAL, "CUDA Context Lost. Creating core dump.");

    // Check Status File
    std::ifstream sf(statusPath);
    std::string statusContent;
    sf >> statusContent;
    sf.close();

    if (statusContent == "CRASHED") {
        std::cout << "STATUS: " << statusContent << std::endl;
        std::cout << "[SUCCESS] Fatal error correctly updated status file to CRASHED." << std::endl;
    } else {
        std::cerr << "[FAIL] Status file not updated to CRASHED. Content: " << statusContent << std::endl;
        return 1;
    }

    return 0;
}
