#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <stdexcept>
#include <memory> 
#include <atomic>

// Includes for all steps
#include "../include/Config.h"
#include "../include/HardwareChecker.h"
#include "../include/ModelSession.h"
#include "../include/ModelHasher.h"
#include "../include/WorkerStatus.h"
#include "../include/ServerBinder.h"
#include "../include/SignalHandler.h" 
#include "../include/Logger.h" // New

// Global flag to control the main loop
std::atomic<bool> g_Running(true);

int main(int argc, char* argv[]) {
    auto startupStartTime = std::chrono::steady_clock::now();
    
    // Default paths, can be overridden by env in real app
    Logger::Init("infermesh_worker.log", "infermesh_worker.status");
    Logger::Log(LogLevel::INFO, "InferMesh C++ Core: Boot sequence initiated.");

    AppConfig config;
    std::shared_ptr<ModelSession> modelSession;

    try {
        // =========================================================================
        // STARTUP SEQUENCE (Steps 1-6)
        // =========================================================================
        config = AppConfig::LoadFromEnv();
        HardwareChecker::VerifyHardware(config);
        
        // Update Logger paths if config has them (optional refinement)
        
        modelSession = ModelSession::Load(config.modelWeightsPath, config.gpuDeviceId);
        ModelHasher::ComputeHash(config.modelWeightsPath);
        
        // Warmup (Mock)
        Logger::Log(LogLevel::INFO, "Starting Warmup..."); 
        
        auto currentTime = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::seconds>(currentTime - startupStartTime).count() > config.startupTimeoutSeconds) {
             throw std::runtime_error("Startup timeout.");
        }
        
        WorkerStatus::SignalReady();

        // =========================================================================
        // SHUTDOWN HANDLER REGISTRATION 
        // =========================================================================
        SignalHandler::SetupSignalHandling([](){
            Logger::Log(LogLevel::INFO, "Shutdown requested via Signal.");
            g_Running = false;
        });

    } catch (const std::exception& e) {
        Logger::Log(LogLevel::FATAL, e.what());
        return 1; 
    }

    // =========================================================================
    // SERVER LOOP (Step 7)
    // =========================================================================
    Logger::Log(LogLevel::INFO, "Binding Server and entering request loop...");
    
    // MOCK Server Loop controlled by SignalHandler
    while (g_Running) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        // Server logic will use Logger::Log(...) inside exceptions
    }

    // =========================================================================
    // GRACEFUL SHUTDOWN
    // =========================================================================
    SignalHandler::PerformCleanup(config.socketPath);

    return 0;
}
