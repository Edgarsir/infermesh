#include "../include/TensorPool.h"
#include <iostream>
#include <thread>
#include <vector>

void worker_thread(TensorPool* pool, int tid) {
    TensorBuffer* buf = pool->AcquireBuffer(500); // Wait up to 500ms for free VRAM
    if (buf) {
        std::cout << "   [THREAD " << tid << "] Acquired VRAM buffer #" << buf->id << "\n";
        
        // Simulate heavy GPU inference computation blocking the buffer
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        
        std::cout << "   [THREAD " << tid << "] Inference finished. Releasing VRAM buffer #" << buf->id << "\n";
        pool->ReleaseBuffer(buf);
    } else {
        std::cout << "   [THREAD " << tid << "] Failed to acquire buffer! TIMEOUT.\n";
    }
}

int main() {
    std::cout << "[INFO] TEST: Tensor Memory Pool (Zero Allocation Overhead)" << std::endl;

    // Simulate a heavily constrained GPU environment:
    // Only 2 total buffers exist in VRAM. Concurrency must queue cleanly!
    TensorPool pool(2, 1024);

    std::cout << "\n--- Case 1: Thundering Herd Concurrency ---" << std::endl;
    // Launch 4 concurrent inference HTTP request threads.
    // Threads 0 and 1 will acquire the two physical buffers immediately.
    // Threads 2 and 3 will block entirely. 
    // After 200ms, 0 and 1 finish their CUDA kernels and release the memory. 
    // Threads 2 and 3 should immediately wake up and grasp the warm buffers before their 500ms timeout.
    
    std::vector<std::thread> threads;
    for (int i = 0; i < 4; i++) {
        threads.push_back(std::thread(worker_thread, &pool, i));
    }

    for (auto& t : threads) {
        t.join();
    }
    std::cout << "[PASS] 4 concurrent threads intelligently queued atop 2 physical VRAM buffers entirely safely.\n" << std::endl;

    std::cout << "--- Case 2: Pool Exhaustion Isolation ---" << std::endl;
    // We explicitly checkout the ONLY 2 available buffers in existence.
    TensorBuffer* b1 = pool.AcquireBuffer(10);
    TensorBuffer* b2 = pool.AcquireBuffer(10);
    
    // Now we simulate a massive traffic spike arriving. The pool is totally empty.
    // Instead of fragmenting VRAM with dynamic panic allocs (`new float[n]`), the Pool strictly blocks 
    // the incoming thread until the 200ms timeout trips, explicitly triggering a graceful `503 Load Shed` mapped to Go.
    std::cout << "[Attempting to check out Buffer #3 from empty pool. Will purposefully block for 200ms...]" << std::endl;
    TensorBuffer* b3 = pool.AcquireBuffer(200); 

    if (b3 == nullptr) {
        std::cout << "[PASS] Pool deliberately starved thread #3 instead of illegally allocating out-of-pool VRAM fragmentation.\n";
    } else {
        std::cout << "[FAIL] Thread illegally acquired buffer!\n";
    }

    // Cleanup
    pool.ReleaseBuffer(b1);
    pool.ReleaseBuffer(b2);

    return 0;
}
