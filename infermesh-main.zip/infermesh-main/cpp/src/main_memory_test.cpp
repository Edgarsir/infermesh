#include <iostream>
#include <vector>
#include <chrono>

// Includes
#include "../include/DataTypes.h"
#include "../include/TensorBuilder.h"
#include "../include/MemoryManager.h"

int main() {
    std::cout << "[INFO] TEST: Memory Cleanup Logic" << std::endl;

    // 1. Setup Data
    InferenceRequest req;
    req.featureDim = 4;
    req.features = {1, 2, 3, 4};

    // 2. Build Tensors (Simulate Allocation)
    // In a real loop, we'd do this thousands of times.
    
    std::cout << "--- Cycle 1: Request Processing ---" << std::endl;
    // TensorBuilder returns a "void*" pointer to the GPU tensor
    void* gpuTensor = TensorBuilder::BuildInputTensor(req, 0); 
    
    // CRITICAL: We must register this so it gets cleaned up.
    // (Ideally TensorBuilder would do this, but explicit control is requested)
    MemoryManager::RegisterTensor(gpuTensor);

    // ... Run Inference ...
    // (Inference would create intermediate tensors, which should also be registered 
    // or scoped within the function. For this test, we assume they are internal 
    // to the session or registered similarly)

    // 3. Explicit Cleanup
    // If we forget this, 'gpuTensor' leaks.
    MemoryManager::CleanupRequest();

    std::cout << "--- Cycle 1 Complete ---" << std::endl;

    // 4. Verify Leak Prevention Logic
    // If CleanupRequest works, the active list should be empty ready for next req.
    
    std::cout << "--- Cycle 2: Stress Test (Simulated) ---" << std::endl;
    for (int i = 0; i < 5; i++) {
        void* t = TensorBuilder::BuildInputTensor(req, 0);
        MemoryManager::RegisterTensor(t);
        // Maybe we release the input immediately after inference starts to save peak memory?
        // MemoryManager::ReleaseTensor(t); 
    }
    // End of batch
    MemoryManager::CleanupRequest(); 
    
    std::cout << "[SUCCESS] Memory operations verified." << std::endl;

    return 0;
}
