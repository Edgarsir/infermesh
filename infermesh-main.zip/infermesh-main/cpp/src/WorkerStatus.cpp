#include "WorkerStatus.h"
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <ctime>

// Mock: Status file path. In production, get from ENV.
static const std::string STATUS_FILE = "infermesh_worker.status";

std::string WorkerStatus::GetStatusFilePath() {
    return STATUS_FILE;
}

void WorkerStatus::SignalReady() {
    std::string path = GetStatusFilePath();
    std::cout << "[INFO] Signaling READY state to supervisor at " << path << std::endl;

    std::ofstream statusFile(path);
    if (!statusFile.is_open()) {
        throw std::runtime_error("Failed to write READY signal. Status file not writable.");
    }

    // Write a specific byte sequence agreed upon with the Go supervisor.
    statusFile << "READY\n"; 
    statusFile.close();
}

void WorkerStatus::SignalDegraded() {
    std::string path = GetStatusFilePath();
    std::cout << "[WARNING] Signaling DEGRADED state to supervisor at " << path << std::endl;

    std::ofstream statusFile(path);
    if (!statusFile.is_open()) {
        throw std::runtime_error("Failed to write DEGRADED signal. Status file not writable.");
    }

    // Write DEGRADED signal. Go's ProcessWatcher reads this and drains the worker.
    statusFile << "DEGRADED\n"; 
    statusFile.close();
void WorkerStatus::UpdateWatchdog() {
    std::ofstream watchdogFile("infermesh_worker.watchdog");
    if (watchdogFile.is_open()) {
        watchdogFile << std::time(nullptr) << "\n";
        watchdogFile.close();
    }
}
