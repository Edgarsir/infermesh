#include "../include/Preprocessor.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

int main() {
    std::cout << "[INFO] TEST: Model Input Preprocessing (Atomic Sidecar)" << std::endl;

    std::string configPath = "preprocessing_config.txt";

    // Create a mock sidecar config
    std::ofstream cfg(configPath);
    cfg << "10.0,-5.0,0.0\n";      // means
    cfg << "2.0,5.0,1.0\n";        // std_devs
    cfg.close();

    // 1. Load the atomic pair
    std::cout << "--- Case 1: Load Sidecar Config ---" << std::endl;
    PreprocessingParams params = Preprocessor::LoadConfig(configPath);

    if (params.means.size() == 3 && params.std_devs.size() == 3) {
        std::cout << "[PASS] Config loaded successfully with proper dimensionality." << std::endl;
    } else {
        std::cout << "[FAIL] Failed to construct proper dimensions." << std::endl;
        return 1;
    }

    // 2. Normalize Incoming Tensor
    std::cout << "\n--- Case 2: Z-Score Normalization ---" << std::endl;
    // User requested [12.0, 0.0, 5.0]
    // Expected:
    // (12.0 - 10.0) / 2.0 = 1.0
    // (0.0 - -5.0) / 5.0 = 1.0
    // (5.0 - 0.0) / 1.0 = 5.0
    std::vector<float> features = {12.0, 0.0, 5.0};
    
    std::vector<float> expected = {1.0, 1.0, 5.0};

    Preprocessor::NormalizeInPlace(features, params);

    bool zscorePass = true;
    for (size_t i = 0; i < features.size(); i++) {
        if (std::abs(features[i] - expected[i]) > 1e-5) {
            zscorePass = false;
        }
    }

    if (zscorePass) {
        std::cout << "[PASS] Features normalized accurately using exactly the parameters trained with the sidecar weights." << std::endl;
    } else {
        std::cout << "[FAIL] Mathematical deviation during Z-Score Standard Scaling." << std::endl;
        return 1;
    }

    return 0;
}
