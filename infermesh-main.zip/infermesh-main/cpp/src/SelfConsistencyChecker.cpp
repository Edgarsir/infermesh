#include "SelfConsistencyChecker.h"
#include "WorkerStatus.h"
#include <iostream>
#include <cmath>
#include <stdexcept>

SelfConsistencyChecker::SelfConsistencyChecker(std::shared_ptr<ModelSession> session, int checkInterval, float tolerance)
    : session(session), checkInterval(checkInterval), tolerance(tolerance), inferenceCount(0) {}

void SelfConsistencyChecker::InitializeGoldenStandard(const std::vector<float>& input) {
    std::cout << "[CONSISTENCY] Initializing Golden Standard Reference Tensor... " << std::endl;
    this->goldenInput = input;
    
    // Convert to void* mock tensor structure
    void* inputTensor = const_cast<void*>(static_cast<const void*>(goldenInput.data()));
    
    InferenceResult res = session->RunInference(inputTensor, 1000);
    this->goldenExpectedOutput = res.outputScores;

    std::cout << "[CONSISTENCY] Expected Baseline Logged. Dimension: " << goldenExpectedOutput.size() << std::endl;
}

bool SelfConsistencyChecker::CheckIfTime() {
    inferenceCount++;
    if (inferenceCount % checkInterval == 0) {
        return RunConsistencyCheck();
    }
    return true; // No check needed, assumed mathematically stable
}

bool SelfConsistencyChecker::RunConsistencyCheck() {
    std::cout << "[CONSISTENCY] Background Self-Consistency Check Triggered (Inference #" << inferenceCount << ")..." << std::endl;
    
    if (goldenInput.empty()) {
        std::cerr << "[WARNING] Consistency Checker not initialized with a Golden Standard!" << std::endl;
        return true; 
    }

    void* inputTensor = const_cast<void*>(static_cast<const void*>(goldenInput.data()));
    InferenceResult res = session->RunInference(inputTensor, 1000);
    
    if (res.outputScores.size() != goldenExpectedOutput.size()) {
        std::cerr << "[CRITICAL] Model signature corrupted: Output Dimension Mismatch." << std::endl;
        WorkerStatus::SignalDegraded();
        return false;
    }

    // Floating-Point Drift Calculation (L1 Norm essentially)
    float maxDelta = 0.0f;
    for (size_t i = 0; i < goldenExpectedOutput.size(); i++) {
        float b1 = goldenExpectedOutput[i];
        float b2 = res.outputScores[i];
        float delta = std::abs(b1 - b2);
        
        if (delta > maxDelta) {
            maxDelta = delta;
        }

        if (delta > tolerance) {
            std::cerr << "[CRITICAL_FAULT] Silent Mathematical Corruption Detected!\n";
            std::cerr << "   Index " << i << " -> Expected: " << b1 << ", Got: " << b2 << " (Delta: " << delta << " > " << tolerance << ")\n";
            std::cerr << "   This may be a GPU VRAM ECC error, floating-point accumulation drift, or non-deterministic thread lock.\n";
            
            WorkerStatus::SignalDegraded();
            return false;
        }
    }

    std::cout << "[CONSISTENCY] Check passed. Maths are stable. (Max Delta: " << maxDelta << ")" << std::endl;
    return true;
}
