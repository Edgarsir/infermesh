#include <iostream>
#include <vector>
#include <stdexcept>

// New Header
#include "../include/RequestValidator.h" 

// ... (Existing includes and mock definitions from previous steps) ...
// We'll keep the example focused on testing the validation logic 
// without needing the full gRPC stack yet.

int main(int argc, char* argv[]) {
    // ... (Startup sequence code from Part 1 would be here) ...
    std::cout << "[INFO] Mocking Request Pipeline for Concept Verification..." << std::endl;

    // Simulate a Valid Request
    InferenceRequest validReq;
    validReq.requestId = "req_123";
    validReq.timestampUnixMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    validReq.featureDim = 3;
    validReq.features = {0.1f, 0.2f, 0.3f};

    try {
        RequestValidator::Validate(validReq);
        std::cout << "[SUCCESS] Valid request passed validation." << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Valid request incorrectly rejected: " << e.what() << std::endl;
    }

    // Simulate a Malformed Request (Dimension Mismatch)
    InferenceRequest badDimReq;
    badDimReq.requestId = "req_bad_dim";
    badDimReq.timestampUnixMs = validReq.timestampUnixMs;
    badDimReq.featureDim = 10; // Declares 10
    badDimReq.features = {0.1f, 0.2f}; // Only provides 2

    try {
        RequestValidator::Validate(badDimReq);
        std::cerr << "[FAIL] Malformed request (dim mismatch) was NOT rejected!" << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cout << "[SUCCESS] Malformed request correctly rejected: " << e.what() << std::endl;
    }

    // Simulate a Stale Request
    InferenceRequest staleReq;
    staleReq.requestId = "req_stale";
    staleReq.timestampUnixMs = validReq.timestampUnixMs - 10000; // 10 seconds ago
    staleReq.featureDim = 3;
    staleReq.features = {0.1f, 0.2f, 0.3f};

    try {
        RequestValidator::Validate(staleReq, 5000); // 5s timeout
        std::cerr << "[FAIL] Stale request was NOT rejected!" << std::endl;
    } catch (const std::invalid_argument& e) {
        std::cout << "[SUCCESS] Stale request correctly rejected: " << e.what() << std::endl;
    }

    return 0;
}
