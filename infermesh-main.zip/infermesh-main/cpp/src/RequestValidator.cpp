#include "RequestValidator.h"
#include <stdexcept>
#include <sstream>
#include <chrono>
#include <iostream>

void RequestValidator::Validate(const InferenceRequest& request, int64_t maxLatencyMs) {
    // -------------------------------------------------------------------------
    // CHECK 1: DATA INTEGRITY (Dimension Mismatch)
    // -------------------------------------------------------------------------
    // The model expects a specific input vector size. If the metadata says 'N'
    // but the payload has 'M', something is wrong (corruption or bug in client).
    // Failing to catch this often leads to segfaults or silent garbage output.
    if (request.features.size() != static_cast<size_t>(request.featureDim)) {
        std::stringstream ss;
        ss << "Invalid Request: Feature dimension mismatch. "
           << "Declared: " << request.featureDim << ", "
           << "Actual: " << request.features.size();
        throw std::invalid_argument(ss.str());
    }

    // -------------------------------------------------------------------------
    // CHECK 2: REQUEST STALENESS (Timestamp Check)
    // -------------------------------------------------------------------------
    // If a request has been sitting in a queue for too long, the result might
    // be useless to the user (who has likely timed out). We can shed load by
    // rejecting it early.
    
    // Get current time in milliseconds
    auto now = std::chrono::system_clock::now();
    auto nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();

    int64_t age = nowMs - request.timestampUnixMs;

    // Sanity check: Future timestamps suggest clock skew issues.
    if (age < -1000) { // Allow 1s skew
        std::cerr << "[WARN] Client timestamp is in the future. " 
                  << "Client: " << request.timestampUnixMs << ", Server: " << nowMs << std::endl;
        // We usually don't reject for this, but worth logging.
    } 
    else if (age > maxLatencyMs) {
        std::stringstream ss;
        ss << "Request Dropped: Too old. Age: " << age << "ms (Max: " << maxLatencyMs << "ms).";
        throw std::invalid_argument(ss.str());
    }
}
