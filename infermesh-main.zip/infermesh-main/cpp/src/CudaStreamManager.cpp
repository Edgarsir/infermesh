#include "../include/CudaStreamManager.h"
#include <iostream>
#include <thread>
#include <chrono>

CudaStreamPool::CudaStreamPool(int numStreams) {
    for (int i = 0; i < numStreams; ++i) {
        // Real CUDA API: cudaStreamCreate(&stream);
        streams.push_back(i + 1); // Mock stream IDs
    }
    std::cout << "[CUDA_STREAM_POOL] Created " << numStreams << " concurrent hardware streams." << std::endl;
}

CudaStreamPool::~CudaStreamPool() {
    // Real CUDA API: cudaStreamDestroy(...)
}

cudaStream_t CudaStreamPool::AcquireStream() {
    std::unique_lock<std::mutex> lock(mtx);
    cv.wait(lock, [this]() { return !streams.empty(); });
    
    cudaStream_t s = streams.back();
    streams.pop_back();
    return s;
}

void CudaStreamPool::ReleaseStream(cudaStream_t stream) {
    std::lock_guard<std::mutex> lock(mtx);
    streams.push_back(stream);
    cv.notify_one();
}

// -------------------------------------------------------------

PipelinedEngine::PipelinedEngine(int numStreams) {
    pool = new CudaStreamPool(numStreams);
}

// Memory copy Host -> Device (System RAM -> GPU VRAM)
void PipelinedEngine::MemcpyHostToDeviceAsync(void* dst, void* src, size_t size, cudaStream_t stream) {
    // std::cout << "     --- [Stream " << stream << "] H2D Transfer Starting..." << std::endl;
    // Real CUDA API: cudaMemcpyAsync(dst, src, size, cudaMemcpyHostToDevice, stream);
    
    // Simulate non-blocking memory transfer on the GPU's DMA engines.
    // In a real system, the CPU immediately continues to the next line of code.
    std::this_thread::sleep_for(std::chrono::milliseconds(50)); // Simulating 50ms transfer
}

// Computes the actual neural network layers in parallel hardware SMs
void PipelinedEngine::ExecuteModelKernelAsync(void* input, void* output, int batchSize, cudaStream_t stream) {
    // std::cout << "     --- [Stream " << stream << "] GPU Compute Kernel Launching (" << batchSize << " inputs)..." << std::endl;
    // Real API: my_model_forward_kernel<<<grid, block, 0, stream>>>(input, output);
    
    // Simulate intense compute 
    std::this_thread::sleep_for(std::chrono::milliseconds(150)); // Simulating 150ms compute
}

// Memory copy Device -> Host (GPU VRAM -> System RAM for returning to Go via gRPC)
void PipelinedEngine::MemcpyDeviceToHostAsync(void* dst, void* src, size_t size, cudaStream_t stream) {
    // std::cout << "     --- [Stream " << stream << "] D2H Transfer Starting..." << std::endl;
    // Real CUDA API: cudaMemcpyAsync(dst, src, size, cudaMemcpyDeviceToHost, stream);
    
    // Simulate result data returning to CPU main memory.
    std::this_thread::sleep_for(std::chrono::milliseconds(30)); 
}

// The CPU explicitly blocks on a SINGLE stream to wait for its compute to finish.
// Notice it only synchronizes ONE stream, leaving the other streams unblocked to continue processing other batches.
void PipelinedEngine::StreamSynchronize(cudaStream_t stream) {
    // Real CUDA API: cudaStreamSynchronize(stream);
    // Because we use sleep to simulate asynchronous queue pushing in this mock, we don't have a 
    // real hardware queue to block on. So this is a conceptual placeholder.
    // In real code, the thread blocks here until D2H transfer has landed.
}
