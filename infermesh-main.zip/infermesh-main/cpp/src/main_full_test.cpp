#include <iostream>
#include <vector>
#include <chrono>

// Includes
#include "../include/Config.h"
#include "../include/DataTypes.h"
#include "../include/RequestValidator.h"
#include "../include/TensorBuilder.h"
#include "../include/ModelSession.h"
#include "../include/PostProcessor.h"

int main() {
    std::cout << "[INFO] TEST: Full End-to-End Logic" << std::endl;

    try {
        // 1. Setup Request
        InferenceRequest req;
        req.requestId = "req_final_1";
        req.timestampUnixMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        req.featureDim = 4;
        req.features = {1.0f, 2.0f, 3.0f, 4.0f};

        // 2. Load & Predict (Mock Pipeline)
        // Creating mock result directly to test PostProcessor in isolation from full engine
        InferenceResult rawResult;
        rawResult.executionTimeMs = 12.5; 
        rawResult.outputShape = {1, 3};
        // Simulated output: [0.1, 0.85, 0.05] -> Index 1 should be highest
        rawResult.outputData = {0.1f, 0.85f, 0.05f}; 

        // 3. Post-Process
        InferenceResponse finalResp = PostProcessor::Interpret(rawResult, req.requestId);

        // 4. Verify
        std::cout << "--- Final Interpretation ---" << std::endl;
        std::cout << "Request ID: " << finalResp.requestId << std::endl;
        std::cout << "Label: " << finalResp.label << std::endl; // Expect "BUY" (Index 1)
        std::cout << "Confidence: " << finalResp.confidenceScore << std::endl;

        if (finalResp.label == "BUY" && finalResp.confidenceScore > 0.8f) {
            std::cout << "[SUCCESS] PostProcessor correct." << std::endl;
        } else {
            std::cerr << "[FAIL] PostProcessor incorrect logic." << std::endl;
            return 1;
        }

    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Execution Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
