#include "../include/InferenceService.h"
#include "../include/ModelSession.h"
#include <iostream>
#include <memory>
#include <stdexcept>

// Mock session that throws an exception simulating GPU OOM
class OOMModelSession : public ModelSession {
public:
    OOMModelSession(std::shared_ptr<Config> cfg, std::shared_ptr<WorkerStatus> status)
        : ModelSession(cfg, status) {}

    InferenceResult RunInference(void* inputTensor, int timeoutMs) override {
        // Simulate catching an internal bad alloc from the tensor engine
        throw std::bad_alloc(); 
    }
};

int main() {
    std::cout << "[INFO] TEST: Graceful C++ Failure Handling (GPU OOM)" << std::endl;

    // 1. Setup mock infrastructure
    auto cfg = std::make_shared<Config>();
    auto status = std::make_shared<WorkerStatus>();
    auto badSession = std::make_shared<OOMModelSession>(cfg, status);

    InferenceService service(badSession);

    // 2. Create valid request
    InferenceRequest request;
    request.requestId = "req-oom-001";
    request.featureDim = 3;
    request.features = {1.0, 2.0, 3.0}; // Valid inputs, but backend will OOM

    // 3. Execute! This should NOT crash the program, but return a serialized error payload
    std::string response = service.Predict(request);

    // 4. Verify output
    std::cout << "\n--- Result Payload ---" << std::endl;
    std::cout << response << std::endl;

    if (response.find("err=C++_EXCEPTION: std::bad_alloc") != std::string::npos) {
        std::cout << "[PASS] Exception successfully caught and serialized to error string." << std::endl;
    } else {
        std::cout << "[FAIL] Failed to catch and format exception!" << std::endl;
        return 1;
    }

    std::cout << "[PASS] C++ Worker survived the OOM gracefully!" << std::endl;
    return 0;
}
