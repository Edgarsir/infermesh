#include "SignalHandler.h"
#include <iostream>
#include <csignal>
#include <atomic>
#include <thread>
#include <cstdio> // for remove()

// Global atomic flag to prevent double-shutdown
std::atomic<bool> g_ShutdownRequested(false);
std::function<void()> g_ShutdownCallback;

// The actual signal handler function (must be void(int))
void signal_handler(int signal) {
    if (g_ShutdownRequested.exchange(true)) {
        return; // Already shutting down
    }
    std::cout << "\n[INFO] Signal " << signal << " received. Initiating graceful shutdown..." << std::endl;
    
    // Trigger the callback to stop the server loop (unblock main thread)
    if (g_ShutdownCallback) {
        g_ShutdownCallback();
    }
}

void segfault_handler(int sig) {
    std::cerr << "\n[CRITICAL_FAULT] Received fatal signal " << sig << " (e.g. SIGSEGV, SIGABRT)!" << std::endl;
    std::cerr << "                 Writing metadata to status file for Go Supervisor to reap..." << std::endl;

    // Open file without allocating new memory if possible, but for demonstration we use fstream
    // Real systems use raw write() calls here because malloc is unsafe in signal handlers.
    FILE* f = fopen("infermesh_worker.status", "w");
    if (f) {
        fprintf(f, "CRASHED\n");
        fclose(f);
    }

    std::cerr << "                 Re-raising signal to generate OS Core Dump for post-mortem analysis." << std::endl;
    // Reset handler to default and re-raise to produce core dump
    std::signal(sig, SIG_DFL);
    std::raise(sig);
}

void SignalHandler::SetupSignalHandling(std::function<void()> shutdownCallback) {
    g_ShutdownCallback = shutdownCallback;
    std::signal(SIGTERM, signal_handler);
    std::signal(SIGINT, signal_handler); // Handle Ctrl+C too
}

void SignalHandler::SetupCrashHandling() {
    std::signal(SIGSEGV, segfault_handler); // Catch Segmentation Faults
    std::signal(SIGABRT, segfault_handler); // Catch Aborts (assertions)
    std::signal(SIGILL, segfault_handler);  // Catch Illegal Instructions
    std::signal(SIGFPE, segfault_handler);  // Catch Floating Point Exceptions
}

void SignalHandler::PerformCleanup(const std::string& socketPath) {
    std::cout << "[SHUTDOWN] Step 1: Waiting for In-Flight Inference (Handled by Server Stop)... Done." << std::endl;

    std::cout << "[SHUTDOWN] Step 2: Unlinking Socket File..." << std::endl;
    if (std::remove(socketPath.c_str()) != 0) {
        std::cerr << "[WARN] Failed to delete socket file: " << socketPath << std::endl;
    } else {
        std::cout << "           Socket deleted successfully." << std::endl;
    }

    std::cout << "[SHUTDOWN] Step 3: Releasing Model VRAM..." << std::endl;
    // In a real app, the shared_ptr<ModelSession> in main() would go out of scope naturally
    // or be reset explicitly here if global.
    // Since our scope is in main(), returning from main() triggers the destructor of ModelSession.
    // The ModelSession destructor should have logic to free torch::jit::Module.
    
    std::cout << "[SHUTDOWN] Cleanup Complete. Process Exiting." << std::endl;
}
