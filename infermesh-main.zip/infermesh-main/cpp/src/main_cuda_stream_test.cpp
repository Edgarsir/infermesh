#include "../include/CudaStreamManager.h"
#include <iostream>
#include <vector>
#include <thread>
#include <chrono>

void request_handler_thread(PipelinedEngine* engine, int batch_id) {
    auto pool = engine->GetStreamPool();
    cudaStream_t stream = pool->AcquireStream();

    void *h_input = nullptr, *d_input = nullptr, *h_output = nullptr, *d_output = nullptr;

    // Phase 1: DMA Transfer (Host -> Device)
    std::cout << " [Batch " << batch_id << "] DMA Transfer -> GPU VRAM (on Stream " << stream << ")\n";
    engine->MemcpyHostToDeviceAsync(d_input, h_input, 1024, stream);

    // Phase 2: Compute execution (Device only)
    std::cout << " [Batch " << batch_id << "] Kernel Executing on GPU SMs (on Stream " << stream << ")\n";
    engine->ExecuteModelKernelAsync(d_input, d_output, 32, stream);

    // Phase 3: DMA Transfer (Device -> Host)
    std::cout << " [Batch " << batch_id << "] DMA Transfer <- System RAM (on Stream " << stream << ")\n";
    engine->MemcpyDeviceToHostAsync(h_output, d_output, 1024, stream);

    // Phase 4: Synchronize specific stream to return to client
    engine->StreamSynchronize(stream);
    std::cout << " [Batch " << batch_id << "] Finished & Returned to Go Gateway.\n";

    pool->ReleaseStream(stream);
}

int main() {
    std::cout << "[INFO] TEST: CUDA Hardware Stream Pipelining Logic" << std::endl;

    // Simulate 2 hardware queues (streams) actively dispatching asynchronous commands to the GPU.
    PipelinedEngine engine(2);

    auto start_time = std::chrono::high_resolution_clock::now();

    // Spawn 4 immediate inference requests.
    // If run synchronously, execution time = 4 * (50 + 150 + 30) = 4 * 230ms = 920ms.
    // With 2 overlapping streams, the hardware overlaps:
    // Batch 0 Compute (150ms) overlaps directly with Batch 1 DMA H2D Transfer (50ms).
    // Total execution drops to ~460ms.

    std::vector<std::thread> handlers;
    for (int i = 0; i < 4; ++i) {
        handlers.emplace_back(std::thread(request_handler_thread, &engine, i));
        std::this_thread::sleep_for(std::chrono::milliseconds(20)); // Submitting requests with slight stagger
    }

    for (auto& h : handlers) {
        h.join();
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    int total_duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

    std::cout << "\n--- Execution Summary ---" << std::endl;
    std::cout << "Total Runtime: " << total_duration << "ms.\n";
    
    // Theoretical sync time = 4 * 230ms = 920ms
    if (total_duration < 900) {
        std::cout << "[PASS] Hardware Execution Pipelined Successfully! GPU Utilization maximized through asynchronous streams.\n";
    } else {
        std::cout << "[FAIL] Execution blocked synchronously. GPU Compute cores were left idle waiting for PCI-E transfers to finish.\n";
    }

    return 0;
}
