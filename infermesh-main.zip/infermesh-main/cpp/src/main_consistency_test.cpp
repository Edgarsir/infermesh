#include "../include/SelfConsistencyChecker.h"
#include "../include/ModelSession.h"
#include "../include/WorkerStatus.h"
#include <iostream>
#include <memory>
#include <vector>

// Mock session that silently corrupts its floating point outputs over time
class DriftedSession : public ModelSession {
public:
    int callCount = 0;

    DriftedSession(std::shared_ptr<Config> cfg, std::shared_ptr<WorkerStatus> status)
        : ModelSession(cfg, status) {}

    InferenceResult RunInference(void* inputTensor, int timeoutMs) override {
        callCount++;
        
        // Simulating the base computation
        std::vector<float> baseResp = {0.8f, 0.1f, 0.1f}; // [BUY, SELL, HOLD]

        if (callCount > 5) {
            // At call > 5, a bit flips in memory. 
            // The score shifts silently by +0.0005, which exceeds the strict 1e-4 tolerance.
            baseResp[0] += 0.0005f; 
        }

        InferenceResult res;
        res.outputScores = baseResp;
        res.computeTimeMs = 5;
        return res;
    }
};

int main() {
    std::cout << "[INFO] TEST: Mathematical Silent Corruption Logic" << std::endl;

    auto cfg = std::make_shared<Config>();
    auto status = std::make_shared<WorkerStatus>();
    auto badSession = std::make_shared<DriftedSession>(cfg, status);

    // Checker: Check every 3 inferences, tolerance 1e-4
    SelfConsistencyChecker checker(badSession, 3, 1e-4f);

    // Initial load, Golden Standard established while system is fresh
    std::vector<float> goldenInput = {1.0f, 2.0f, 3.0f};
    checker.InitializeGoldenStandard(goldenInput); 
    // ^ callCount = 1

    bool corruptionDetected = false;

    // Simulate 10 ongoing prediction cycles
    for (int i = 1; i <= 10; ++i) {
        std::cout << "--- Inference Request #" << i << " Executing..." << std::endl;
        
        // Simulating the actual frontend handling this
        if (!checker.CheckIfTime()) {
            corruptionDetected = true;
            std::cout << "--- Inference #" << i << " ABORTED due to corruption." << std::endl;
            break;
        }

        badSession->RunInference(nullptr, 0); // Actual user's prediction. callCount increments.
    }

    if (corruptionDetected) {
        std::cout << "[PASS] Background checker successfully detected mathematical drift!" << std::endl;
    } else {
        std::cout << "[FAIL] Failed to detect the memory drift." << std::endl;
        return 1;
    }

    // Verify it signaled DEGRADED to Go.
    std::ifstream file("infermesh_worker.status");
    std::string state;
    if (file >> state && state == "DEGRADED") {
        std::cout << "[PASS] Worker cleanly flushed DEGRADED state to disk for Go to reap." << std::endl;
    } else {
        std::cout << "[FAIL] Expected DEGRADED, got " << state << std::endl;
    }

    return 0;
}
