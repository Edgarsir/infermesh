#include <iostream>
#include <vector>
#include <chrono>

// Includes
#include "../include/Config.h"
#include "../include/DataTypes.h"
#include "../include/RequestValidator.h"
#include "../include/TensorBuilder.h"

// Mock definitions for integration testing
void LogFatalError(const std::string& msg) { std::cerr << "[FATAL] " << msg << std::endl; }


int main() {
    std::cout << "[INFO] TEST: Logic Flow - Request to Tensor" << std::endl;

    // 1. Setup Mock Request
    InferenceRequest req;
    req.requestId = "req_test";
    req.timestampUnixMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    req.featureDim = 4;
    req.features = {1.0f, 2.0f, 3.0f, 4.0f};

    // 2. Validate
    try {
        RequestValidator::Validate(req);
        std::cout << "[PASS] Validation success." << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Validation failed: " << e.what() << std::endl;
        return 1;
    }

    // 3. Build Tensor
    // Simulate AppConfig having GPU 0
    int gpuId = 0; 
    
    try {
        void* tensorParams = TensorBuilder::BuildInputTensor(req, gpuId);
        // In real code, we'd assert tensorParams is not null or check properties.
        std::cout << "[PASS] Tensor construction logic executed." << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Tensor construction failed: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
