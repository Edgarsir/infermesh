#include "PostProcessor.h"
#include <algorithm>
#include <stdexcept>
#include <cmath>
#include <iostream>

// Define the class labels based on the specific model contract.
const std::vector<std::string> PostProcessor::CLASS_LABELS = {"HOLD", "BUY", "SELL"};

InferenceResponse PostProcessor::Interpret(const InferenceResult& result, const std::string& requestId) {
    // -------------------------------------------------------------------------
    // VALIDATION
    // -------------------------------------------------------------------------
    if (result.outputData.empty()) {
        throw std::runtime_error("PostProcessing Failed: Empty output data.");
    }

    // Ensure we have enough outputs for our labels
    if (result.outputData.size() < CLASS_LABELS.size()) {
        // This suggests model architecture mismatch
        throw std::runtime_error("PostProcessing Failed: Output size smaller than expected number of classes.");
    }

    // -------------------------------------------------------------------------
    // ARGMAX LOGIC
    // -------------------------------------------------------------------------
    // Find the index with the highest probability
    auto maxElementIt = std::max_element(result.outputData.begin(), result.outputData.end());
    int maxIndex = std::distance(result.outputData.begin(), maxElementIt);
    float maxVal = *maxElementIt;

    // -------------------------------------------------------------------------
    // CONSTRUCT RESPONSE
    // -------------------------------------------------------------------------
    InferenceResponse response;
    response.requestId = requestId;
    
    // Safety check for index bounds (should be caught by size check above, but safe is better)
    if (maxIndex >= 0 && maxIndex < static_cast<int>(CLASS_LABELS.size())) {
        response.label = CLASS_LABELS[maxIndex];
    } else {
        response.label = "UNKNOWN"; // Should theoretically not happen
    }

    response.confidenceScore = maxVal;
    response.rawProbabilities = result.outputData;
    response.processingTimeMs = result.executionTimeMs;

    return response;
}
