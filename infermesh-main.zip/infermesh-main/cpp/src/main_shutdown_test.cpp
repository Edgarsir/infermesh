#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>
#include <csignal>

#include "../include/SignalHandler.h"

// Mock functionality for test
void mockServerLoop() {
    std::cout << "Server running..." << std::endl;
    int ticks = 0;
    while (ticks < 10) { // Should be interrupted
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        ticks++;
    }
}

int main() {
    std::cout << "[INFO] TEST: Graceful Shutdown" << std::endl;
    
    std::string socketPath = "test_socket.sock";
    // Create dummy socket file
    std::ofstream f(socketPath); f << "mock"; f.close();

    bool stopLoop = false;
    SignalHandler::SetupSignalHandling([&](){
        std::cout << "Callback Triggered: Stopping Loop." << std::endl;
        stopLoop = true;
    });

    std::cout << "[TEST] Simulating SIGTERM in 200ms..." << std::endl;
    std::thread killer([&](){
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        std::raise(SIGTERM);
    });

    // Run "Server"
    while (!stopLoop) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        std::cout << "." << std::flush;
    }
    
    killer.join();
    
    // Cleanup
    SignalHandler::PerformCleanup(socketPath);

    std::ifstream check(socketPath);
    if (!check.good()) {
        std::cout << "[SUCCESS] Socket file deleted." << std::endl;
    } else {
        std::cerr << "[FAIL] Socket file still exists!" << std::endl;
        return 1;
    }

    return 0;
}
