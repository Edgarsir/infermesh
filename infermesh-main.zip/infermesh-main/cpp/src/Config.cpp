#include "Config.h"
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

// Helper: safe retrieval of env vars with optional default values
static std::string getEnvVar(const char* key, bool required = true, const std::string& defaultValue = "") {
    const char* val = std::getenv(key);
    if (val == nullptr) {
        if (required) {
            throw std::runtime_error(std::string("Missing required environment variable: ") + key);
        }
        return defaultValue;
    }
    return std::string(val);
}

AppConfig AppConfig::LoadFromEnv() {
    AppConfig config;
    try {
        // CRITICAL: The socket path is the lifeline to the Go supervisor.
        // Must be provided.
        config.socketPath = getEnvVar("INFERMESH_SOCKET_PATH");

        // CRITICAL: Cannot start without model weights.
        config.modelWeightsPath = getEnvVar("INFERMESH_MODEL_PATH");

        // Optional: Default to GPU 0 if not specified.
        std::string gpuStr = getEnvVar("INFERMESH_GPU_ID", false, "0");
        try {
            config.gpuDeviceId = std::stoi(gpuStr);
        } catch (...) {
            throw std::runtime_error("Invalid integer for INFERMESH_GPU_ID");
        }

        // Optional: Default batch size 32.
        std::string batchStr = getEnvVar("INFERMESH_MAX_BATCH_SIZE", false, "32");
        try {
            config.maxBatchSize = std::stoi(batchStr);
        } catch (...) {
            throw std::runtime_error("Invalid integer for INFERMESH_MAX_BATCH_SIZE");
        }

        // Optional: Default timeout 30 seconds.
        std::string timeoutStr = getEnvVar("INFERMESH_STARTUP_TIMEOUT", false, "30");
        try {
            config.startupTimeoutSeconds = std::stoi(timeoutStr);
        } catch (...) {
            throw std::runtime_error("Invalid integer for INFERMESH_STARTUP_TIMEOUT");
        }

    } catch (const std::exception& e) {
        // Re-throw with context so the main logger can capture the specific reason for failure.
        throw std::runtime_error(std::string("Config Load Error: ") + e.what());
    }
    
    return config;
}
