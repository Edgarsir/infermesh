#include "MemoryManager.h"
#include <iostream>
#include <algorithm>

// Define static members
std::vector<void*> MemoryManager::activeTensors;
std::mutex MemoryManager::mutex;

// Helper to simulate tensor destruction
void MockFree(void* ptr) {
    // In reality: 
    // delete static_cast<torch::Tensor*>(ptr);
    // or ptr->reset();
    if (ptr) {
        // Just printing for verification
        // std::cout << "       [GC] Releasing Tensor at " << ptr << std::endl;
    }
}

void MemoryManager::RegisterTensor(void* tensorPtr) {
    if (!tensorPtr) return;
    std::lock_guard<std::mutex> lock(mutex);
    activeTensors.push_back(tensorPtr);
    // std::cout << "[MEM] Registered Tensor " << tensorPtr << std::endl;
}

void MemoryManager::ReleaseTensor(void* tensorPtr) {
    if (!tensorPtr) return;
    std::lock_guard<std::mutex> lock(mutex);
    
    auto it = std::find(activeTensors.begin(), activeTensors.end(), tensorPtr);
    if (it != activeTensors.end()) {
        MockFree(*it); // Simulate the expensive free operation
        activeTensors.erase(it);
        std::cout << "[MEM] Explicitly released specific Tensor " << tensorPtr << std::endl;
    }
}

void MemoryManager::CleanupRequest() {
    std::lock_guard<std::mutex> lock(mutex);
    if (activeTensors.empty()) return;

    std::cout << "[MEM] cleanup: Releasing " << activeTensors.size() << " remaining tensors." << std::endl;
    for (void* ptr : activeTensors) {
        MockFree(ptr);
    }
    activeTensors.clear();
    
    // Optional: Force GPU cache clear if necessary (e.g., c10::cuda::CUDACachingAllocator::emptyCache())
    // This is expensive so only do it if fragmentation is high or OOM is near.
}
