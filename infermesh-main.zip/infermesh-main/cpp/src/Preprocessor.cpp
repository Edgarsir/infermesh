#include "../include/Preprocessor.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sstream>

// Mocking JSON parse for simplicity in C++ without external libraries like nlohmann/json.
// Assuming a very simple config format:
// Line 1: means (comma separated list)
// Line 2: std_devs (comma separated list)
PreprocessingParams Preprocessor::LoadConfig(const std::string& configFilePath) {
    std::ifstream file(configFilePath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to load atomic preprocessing config sidecar: " + configFilePath);
    }

    PreprocessingParams params;
    std::string line;

    auto parseLine = [](const std::string& l) {
        std::vector<float> vals;
        std::stringstream ss(l);
        std::string token;
        while (std::getline(ss, token, ',')) {
            vals.push_back(std::stof(token));
        }
        return vals;
    };

    if (std::getline(file, line)) {
        params.means = parseLine(line);
    }
    if (std::getline(file, line)) {
        params.std_devs = parseLine(line);
    }

    if (params.means.size() != params.std_devs.size()) {
        throw std::runtime_error("Malformed Preprocessing Config: Means and StdDevs length mismatch!");
    }

    std::cout << "[PREPROCESSOR] Successfully loaded preprocessing_config.json bounding. Feature Dim: " << params.means.size() << std::endl;
    return params;
}

void Preprocessor::NormalizeInPlace(std::vector<float>& rawFeatures, const PreprocessingParams& params) {
    if (rawFeatures.size() != params.means.size()) {
        throw std::runtime_error("Input Feature Dimension mismatch against Training Preprocessing Signature.");
    }

    for (size_t i = 0; i < rawFeatures.size(); ++i) {
        // Apply Z-Score Standardization (x - u) / sigma
        if (params.std_devs[i] == 0.0f) {
            rawFeatures[i] = 0.0f; // Handle divide by zero edge cases safely
        } else {
            rawFeatures[i] = (rawFeatures[i] - params.means[i]) / params.std_devs[i];
        }
    }
}
