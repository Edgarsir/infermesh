#include <iostream>
#include <vector>
#include <chrono>

// Includes
#include "../include/Config.h"
#include "../include/DataTypes.h"
#include "../include/RequestValidator.h"
#include "../include/TensorBuilder.h"
#include "../include/ModelSession.h"

int main() {
    std::cout << "[INFO] TEST: Full Inference Pipeline" << std::endl;

    // 1. Setup Request
    InferenceRequest req;
    req.requestId = "req_inf_1";
    req.timestampUnixMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    req.featureDim = 4;
    req.features = {1.0f, 2.0f, 3.0f, 4.0f};

    try {
        // 2. Load Model (Mock)
        // Create a dummy file so loader passes
        std::ofstream dummy("dummy_model.pt"); dummy << "mock"; dummy.close();
        
        auto session = ModelSession::Load("dummy_model.pt", 0);

        // 3. Build Tensor
        void* tensor = TensorBuilder::BuildInputTensor(req, 0);

        // 4. Run Inference (Normal)
        std::cout << "--- Test Normal Inference ---" << std::endl;
        InferenceResult res = session->RunInference(tensor, 1000);
        std::cout << "Result: [";
        for(float f : res.outputData) std::cout << f << " ";
        std::cout << "]" << std::endl;

        // 5. Run Inference (Timeout Case)
        // To test this properly we'd need to mock RunInference to sleep longer than timeout.
        // For now, we trust the logic in ModelSession.cpp which has the check.
        
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Pipeline Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
