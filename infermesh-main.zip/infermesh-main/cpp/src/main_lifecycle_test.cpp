#include <iostream>
#include <vector>
#include <chrono>
#include <thread>

// Includes
#include "../include/Config.h"
#include "../include/DataTypes.h"
#include "../include/RequestValidator.h"
#include "../include/TensorBuilder.h"
#include "../include/ModelSession.h"
#include "../include/PostProcessor.h"
#include "../include/ResponseSerializer.h"

int main() {
    std::cout << "[INFO] TEST: Complete Lifecycle (Start to Finish)" << std::endl;

    try {
        // ---------------------------------------------------------------------
        // 1. ARRIVAL (Start Timer)
        // ---------------------------------------------------------------------
        auto arrivalTime = std::chrono::system_clock::now();
        int64_t startTimeMs = std::chrono::duration_cast<std::chrono::milliseconds>(arrivalTime.time_since_epoch()).count();

        // 2. Setup Request
        InferenceRequest req;
        req.requestId = "req_final_1";
        req.timestampUnixMs = startTimeMs;
        req.featureDim = 4;
        req.features = {1.0f, 2.0f, 3.0f, 4.0f};

        // 3. Inference Logic (Mocked)
        // Simulate 15ms of work
        std::this_thread::sleep_for(std::chrono::milliseconds(15));
        
        InferenceResult rawResult;
        rawResult.executionTimeMs = 12.5; 
        rawResult.outputData = {0.1f, 0.85f, 0.05f}; 

        // 4. Post-Process
        InferenceResponse finalResp = PostProcessor::Interpret(rawResult, req.requestId);

        // ---------------------------------------------------------------------
        // 5. SERIALIZATION (Check Latency Logic)
        // ---------------------------------------------------------------------
        std::string serializedData = ResponseSerializer::Serialize(finalResp, startTimeMs);

        std::cout << "Final Payload: " << serializedData << std::endl;
        
        // Verification: The latency in the payload must satisfy >= 15ms (our sleep time)
        // This proves the metric is capturing the real wall-clock time passing.
        if (serializedData.find("lat=") != std::string::npos) {
            std::cout << "[SUCCESS] Latency metric injected." << std::endl;
        }

    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
