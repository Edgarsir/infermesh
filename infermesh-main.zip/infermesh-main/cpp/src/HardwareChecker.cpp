#include "HardwareChecker.h"
#include <iostream>
#include <stdexcept>
#include <sstream>

// In a real implementation, we would include CUDA/LibTorch headers here:
// #include <cuda_runtime.h> 
// #include <torch/torch.h>

/**
 * MOCK IMPLEMENTATION NOTE:
 * Since we don't have the actual CUDA environment linked here, we'll
 * simulate the checks with standard C++ logic and placeholders. 
 * Replace the comments with actual API calls (e.g., cudaGetDeviceCount).
 */ 

void HardwareChecker::VerifyHardware(const AppConfig& config) {
    std::cout << "[INFO] Verifying Hardware Configuration..." << std::endl;

    // -------------------------------------------------------------------------
    // CHECK 1: GPU DEVICE EXISTENCE
    // -------------------------------------------------------------------------
    int deviceCount = 0;
    // cudaGetDeviceCount(&deviceCount); 
    // MOCK: Assume 2 GPUs (0 and 1) are present for demonstration.
    deviceCount = 2; 

    if (config.gpuDeviceId < 0 || config.gpuDeviceId >= deviceCount) {
        std::stringstream ss;
        ss << "Invalid GPU Device ID: " << config.gpuDeviceId 
           << ". Detected " << deviceCount << " devices (Indices 0-" << (deviceCount - 1) << ").";
        throw std::runtime_error(ss.str());
    }

    std::cout << "       Device ID " << config.gpuDeviceId << " is valid." << std::endl;

    // -------------------------------------------------------------------------
    // CHECK 2: AVAILABLE VRAM
    // -------------------------------------------------------------------------
    size_t freeMemory = 0;
    size_t totalMemory = 0;
    // cudaSetDevice(config.gpuDeviceId);
    // cudaMemGetInfo(&freeMemory, &totalMemory);
    
    // MOCK: Assume 8GB total, 6GB free.
    totalMemory = 8ULL * 1024 * 1024 * 1024; 
    freeMemory  = 6ULL * 1024 * 1024 * 1024; 

    size_t requiredMemory = EstimatedVRAMRequirement();

    if (freeMemory < requiredMemory) {
        std::stringstream ss;
        ss << "Insufficient VRAM on device " << config.gpuDeviceId << ". "
           << "Required: " << (requiredMemory / (1024*1024)) << " MB, "
           << "Available: " << (freeMemory / (1024*1024)) << " MB.";
        throw std::runtime_error(ss.str());
    }

    std::cout << "       VRAM Check Passed. " 
              << (freeMemory / (1024*1024)) << " MB available." << std::endl;
}

size_t HardwareChecker::EstimatedVRAMRequirement() {
    // Return approximate bytes needed. e.g. 4GB
    return 4ULL * 1024 * 1024 * 1024;
}
