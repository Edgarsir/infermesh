#include "../include/TensorPool.h"
#include <iostream>
#include <cstdlib>

TensorPool::TensorPool(int poolSize, size_t bufferSizeBytes) : totalPoolSize(poolSize) {
    for (int i = 0; i < poolSize; i++) {
        TensorBuffer* buf = new TensorBuffer();
        buf->id = i;
        buf->sizeBytes = bufferSizeBytes;
        
        // Simulating cudaMalloc with standard CPU malloc.
        // In real CUDA code, this is `cudaMalloc(&buf->data, bufferSizeBytes)`
        // which takes 20+ microseconds. Moving this to boot-time saves that per request.
        buf->data = std::malloc(bufferSizeBytes);
        if (!buf->data) {
            // Catch catastrophic OS memory exhaustion during pre-allocation
            throw std::bad_alloc(); 
        }
        
        allBuffers.push_back(buf);
        availableBuffers.push_back(buf);
    }
    std::cout << "[TENSOR_POOL] Successfully bootstrapped " << poolSize 
              << " buffers (" << bufferSizeBytes << " bytes each) into continuous VRAM." << std::endl;
}

TensorPool::~TensorPool() {
    for (auto buf : allBuffers) {
        // Real CUDA: cudaFree(buf->data);
        std::free(buf->data); 
        delete buf;
    }
}

TensorBuffer* TensorPool::AcquireBuffer(int timeoutMs) {
    std::unique_lock<std::mutex> lock(mtx);
    
    // Block the thread until a buffer is returned to the queue OR the timer expires
    bool acquired = cv.wait_for(lock, std::chrono::milliseconds(timeoutMs), [this]() {
        return !availableBuffers.empty();
    });

    if (!acquired) {
        std::cerr << "[WARNING] TensorPool exhausted! Blocking wait timeout (" << timeoutMs << "ms) expired." << std::endl;
        return nullptr;
    }

    // Pop from the back of the queue (warmest memory first / L2 cache locality)
    TensorBuffer* buf = availableBuffers.back();
    availableBuffers.pop_back();
    return buf;
}

void TensorPool::ReleaseBuffer(TensorBuffer* buffer) {
    if (!buffer) return;
    
    std::lock_guard<std::mutex> lock(mtx);
    availableBuffers.push_back(buffer);
    
    // Wake up exactly one blocked C++ worker thread waiting for VRAM
    cv.notify_one(); 
}
