#include "InferenceService.h"
#include "RequestValidator.h"
#include "TensorBuilder.h"
#include "PostProcessor.h"
#include "ResponseSerializer.h"
#include "MemoryManager.h"
#include <iostream>
#include <chrono>

InferenceService::InferenceService(std::shared_ptr<ModelSession> sess) 
    : session(sess) {}

std::string InferenceService::Predict(const InferenceRequest& request) {
    // -------------------------------------------------------------------------
    // I/O PHASE (Parallelizable)
    // -------------------------------------------------------------------------
    // gRPC has already read the bytes and parsed 'request'. 
    // We can do lightweight validation here without locking.
    
    try {
        RequestValidator::Validate(request);
    } catch (const std::exception& e) {
        return "ERROR: " + std::string(e.what());
    }

    // Capture start time for latency metric
    int64_t startTime = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    // -------------------------------------------------------------------------
    // CRITICAL SECTION (Sequential)
    // -------------------------------------------------------------------------
    // We lock the mutex. If another thread is inferencing, we wait here.
    // This effectively queues requests at the application layer.
    std::unique_lock<std::mutex> lock(inferenceMutex);

    std::string responsePayload;
    
    try {
        // 1. Build Tensor (CPU -> GPU Transfer happens here)
        // Note: We might want to move CPU-side build *outside* the lock if inputs are huge,
        // but typically we lock early to prevent GPU memory fragmentation context switching.
        void* inputTensor = TensorBuilder::BuildInputTensor(request, 0 /* GPU 0 */);
        MemoryManager::RegisterTensor(inputTensor);

        // 2. Run Inference (The Long Operation)
        InferenceResult result = session->RunInference(inputTensor, 1000 /* timeout */);

        // 3. Post-Process (Pure CPU logic, could potentially be outside lock if data copy is done)
        InferenceResponse response = PostProcessor::Interpret(result, request.requestId);

        // 4. Serialize
        responsePayload = ResponseSerializer::Serialize(response, startTime);

    } catch (const std::exception& e) {
        // Log critical failure (e.g. GPU OOM, bad_alloc)
        std::cerr << "[ERROR] Inference Failed (" << request.requestId << "): " << e.what() << std::endl;
        
        // Graceful Error Reporting (Returns structured error to Go instead of crashing)
        InferenceResponse errorResponse;
        errorResponse.requestId = request.requestId;
        errorResponse.errorMessage = "C++_EXCEPTION: " + std::string(e.what());
        
        responsePayload = ResponseSerializer::Serialize(errorResponse, startTime);
    }

    // 5. Cleanup Resources
    MemoryManager::CleanupRequest();

    return responsePayload; 
    // Lock releases automatically here.
}
