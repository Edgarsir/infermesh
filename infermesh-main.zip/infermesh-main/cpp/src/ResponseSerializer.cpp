#include "ResponseSerializer.h"
#include <iostream>
#include <sstream>
#include <chrono>

// Mock Protobuf Message Structure
// In reality, this is generated code from .proto files
struct MockProtoResponse {
    std::string request_id;
    std::string label;
    float confidence;
    int64_t compute_duration_ms;
    std::string error_message;
    
    std::string SerializeAsString() {
        std::stringstream ss;
        ss << "PROTO_BIN:{" 
           << "id=" << request_id << ","
           << "lbl=" << label << ","
           << "conf=" << confidence << ","
           << "lat=" << compute_duration_ms << ","
           << "err=" << error_message
           << "}";
        return ss.str();
    }
};

std::string ResponseSerializer::Serialize(const InferenceResponse& response, int64_t startTimeUnixMs) {
    // -------------------------------------------------------------------------
    // LATENCY CALCULATION
    // -------------------------------------------------------------------------
    // Measure pure compute time (Total time inside C++ process).
    auto now = std::chrono::system_clock::now();
    int64_t endTimeMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
    int64_t totalInternalLatency = endTimeMs - startTimeUnixMs;

    // -------------------------------------------------------------------------
    // PROTOBUF CONSTRUCTION
    // -------------------------------------------------------------------------
    MockProtoResponse proto;
    proto.request_id = response.requestId;
    proto.label = response.label;
    proto.confidence = response.confidenceScore;
    proto.compute_duration_ms = totalInternalLatency; 
    proto.error_message = response.errorMessage;
    
    // In a real gRPC handler, you might populate the response object directly
    // rather than serializing to string, but the logic remains identical.
    
    std::cout << "[INFO] Serializer: Request " << response.requestId 
              << " completed in " << totalInternalLatency << "ms total internal time." << std::endl;

    return proto.SerializeAsString();
}
