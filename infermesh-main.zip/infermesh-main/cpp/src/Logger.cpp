#include "Logger.h"
#include <iostream>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <sstream>

std::string Logger::logFile = "infermesh_worker.log"; 
std::string Logger::statusFile = "infermesh_worker.status";
std::mutex Logger::mutex;

void Logger::Init(const std::string& lPath, const std::string& sPath) {
    if (!lPath.empty()) logFile = lPath;
    if (!sPath.empty()) statusFile = sPath;
}

std::string Logger::LevelToString(LogLevel level) {
    switch(level) {
        case LogLevel::INFO: return "INFO";
        case LogLevel::WARN: return "WARN";
        case LogLevel::ERROR: return "ERROR";
        case LogLevel::FATAL: return "FATAL";
        default: return "UNKNOWN";
    }
}

std::string Logger::CurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&time), "%Y-%m-%dT%H:%M:%S"); 
    return ss.str();
}

void Logger::Log(LogLevel level, const std::string& message, const std::string& requestId) {
    std::lock_guard<std::mutex> lock(mutex);

    std::stringstream entry;
    entry << "[" << CurrentTimestamp() << "] "
          << "[" << LevelToString(level) << "] "
          << (requestId.empty() ? "" : "[ReqID=" + requestId + "] ")
          << message;

    std::string line = entry.str();

    // 1. Write to Standard Error (for container logs/supervisor capture)
    std::cerr << line << std::endl;

    // 2. Write to Structured Log File
    std::ofstream f(logFile, std::ios::app);
    if (f.is_open()) {
        f << line << std::endl;
        f.close();
    }

    // 3. Special Handling for FATAL
    if (level == LogLevel::FATAL) {
        // Write CRASHED to status file for immediate Go detection
        std::ofstream sf(statusFile); // Overwrite mode
        if (sf.is_open()) {
            sf << "CRASHED\n";
            sf.close();
        }
        // Note: We do NOT exit here. The caller should exit after logging fatal.
        // This keeps the logger pure.
    }
}
