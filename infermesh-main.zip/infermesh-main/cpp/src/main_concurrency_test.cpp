#include <iostream>
#include <thread>
#include <vector>
#include <future>
#include <chrono>

#include "../include/InferenceService.h"
#include "../include/ModelSession.h"

// Mock setup helper
std::shared_ptr<ModelSession> createMockSession() {
    // We create a dummy file to satisfy the loader checks
    std::ofstream f("dummy_model.pt"); f << "mock"; f.close();
    return ModelSession::Load("dummy_model.pt", 0);
}

int main() {
    std::cout << "[INFO] TEST: Concurrency Logic (Serialized Inference)" << std::endl;

    auto session = createMockSession();
    InferenceService service(session);

    // We will launch 3 concurrent requests from different threads.
    // The service should process them one by one.
    
    auto worker = [&](int id) {
        InferenceRequest req;
        req.requestId = "req_" + std::to_string(id);
        req.timestampUnixMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        req.featureDim = 4;
        req.features = {1, 1, 1, 1};

        std::cout << "[Thread " << id << "] sending request..." << std::endl;
        
        // This call blocks until the mutex is acquired and inference finishes
        std::string resp = service.Predict(req);
        
        std::cout << "[Thread " << id << "] got response. " << std::endl;
    };

    // Launch threads
    std::vector<std::future<void>> futures;
    auto start = std::chrono::steady_clock::now();

    for(int i=0; i<3; i++) {
        futures.push_back(std::async(std::launch::async, worker, i));
    }

    // Wait for all
    for(auto& f : futures) f.get();

    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    std::cout << "All 3 requests finished in " << duration << "ms." << std::endl;
    // Since our mock inference sleeps 50ms (in ModelSession), 
    // sequential execution should take at least 150ms. 
    // Parallel would be ~50ms.
    
    if (duration >= 150) {
        std::cout << "[SUCCESS] Serial execution verified (Time > 3 * single_inference)." << std::endl;
    } else {
        std::cout << "[WARN] Execution was too fast, parallelism might have occurred (unexpected for this test)." << std::endl;
    }

    return 0;
}
