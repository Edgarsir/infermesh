package sdk

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strconv"
	"time"
)

// Config represents the client SDK initialization parameters.
type Config struct {
	Endpoint   string
	Token      string
	MaxRetries int
	BaseDelay  time.Duration
	MaxDelay   time.Duration
}

// Client acts as the gateway to the InferMesh platform, handling authentication,
// clock synchronization, and intelligent retries transparently.
type Client struct {
	config         Config
	httpClient     *http.Client
	serverOffsetMs int64 // Extracted delta to fake NTP synchronization
}

func NewClient(cfg Config) *Client {
	if cfg.MaxRetries == 0 {
		cfg.MaxRetries = 3
	}
	if cfg.BaseDelay == 0 {
		cfg.BaseDelay = 100 * time.Millisecond
	}
	if cfg.MaxDelay == 0 {
		cfg.MaxDelay = 2 * time.Second
	}
	return &Client{
		config:     cfg,
		httpClient: &http.Client{Timeout: 5 * time.Second},
	}
}

// PredictRequest wraps the feature slice.
type PredictRequest struct {
	Features []float64 `json:"features"`
}

// PredictResponse represents the structured prediction result.
type PredictResponse struct {
	RequestID    string  `json:"request_id"`
	Signal       string  `json:"signal"`
	Confidence   float64 `json:"confidence"`
	ErrorMessage string  `json:"error_message,omitempty"`
}

// Predict executes an inference call with Exponential Backoff and Jitter.
func (c *Client) Predict(features []float64) (*PredictResponse, error) {
	reqBody, err := json.Marshal(PredictRequest{Features: features})
	if err != nil {
		return nil, fmt.Errorf("failed to marshal payload: %w", err)
	}

	var lastErr error
	delay := c.config.BaseDelay

	for attempt := 0; attempt <= c.config.MaxRetries; attempt++ {
		req, err := http.NewRequest("POST", c.config.Endpoint+"/predict", bytes.NewReader(reqBody))
		if err != nil {
			return nil, fmt.Errorf("failed to build HTTP request: %w", err)
		}

		req.Header.Set("Authorization", "Bearer "+c.config.Token)
		req.Header.Set("Content-Type", "application/json")

		// Transparently adjust client clock against historical server offset
		adjustedTime := time.Now().UnixMilli() + c.serverOffsetMs
		req.Header.Set("X-Client-Timestamp", strconv.FormatInt(adjustedTime, 10))

		resp, err := c.httpClient.Do(req)
		
		var reqID string
		
		if err != nil {
			// OS/Network level error (e.g. DNS failure, connection refused)
			lastErr = err
		} else {
			// HTTP Response parsed. Read headers cleanly.
			reqID = resp.Header.Get("X-Request-Id")
			
			// Extract clock time to calibrate the offset for the NEXT request
			srvTimeStr := resp.Header.Get("X-Server-Timestamp")
			if srvTimeStr != "" {
				if srvTime, parseErr := strconv.ParseInt(srvTimeStr, 10, 64); parseErr == nil {
					c.serverOffsetMs = srvTime - time.Now().UnixMilli()
				}
			}

			if resp.StatusCode == http.StatusOK {
				defer resp.Body.Close()
				bodyBytes, _ := ioutil.ReadAll(resp.Body)

				var result PredictResponse
				if err := json.Unmarshal(bodyBytes, &result); err != nil {
					return nil, fmt.Errorf("failed to decode response JSON: %w", err)
				}
				
				// Ensure traceability bubbles up to the caller
				if result.RequestID == "" {
					result.RequestID = reqID
				}
				return &result, nil
			}

			// We hit an error code. Drain body to reuse connection.
			resp.Body.Close()

			switch resp.StatusCode {
			case http.StatusBadRequest:
				// 400 Series (Bad Request): Missing payload, corrupted JSON, NaN errors.
				// NEVER RETRY. This is a persistent user error.
				return nil, fmt.Errorf("HTTP 400 Bad Request [TraceID: %s]. Check payload syntax", reqID)

			case http.StatusUnauthorized, http.StatusForbidden:
				// 401/403 Series: Bad JWT, Expired Key, Bad Issuer.
				// NEVER RETRY. Retrying an invalid token wastes network bandwidth.
				return nil, fmt.Errorf("HTTP %d Auth Failed [TraceID: %s]. Check tokens", resp.StatusCode, reqID)

			case http.StatusConflict:
				// 409 Series: Tenant registered but Model Pending CI/CD loop.
				// No need to backoff quickly, the caller should just wait longer.
				return nil, fmt.Errorf("HTTP 409 Model Not Ready [TraceID: %s]. Please wait for deployment", reqID)

			case http.StatusTooManyRequests, http.StatusServiceUnavailable:
				// 429/503 Series: Gateway memory load-shedding, Tenant Bucket empty, Pool Dead.
				// PERFECT CANDIDATES FOR EXPONENTIAL BACKOFF.
				lastErr = fmt.Errorf("HTTP %d Rate-limited/Overloaded [TraceID: %s]", resp.StatusCode, reqID)

				// Attempt to parse explicit Backpressure signaling
				if retryAfter := resp.Header.Get("Retry-After"); retryAfter != "" {
					if seconds, parseErr := strconv.Atoi(retryAfter); parseErr == nil && seconds > 0 {
						// Override the local exponential delay with the server's exact structural instruction
						delay = time.Duration(seconds) * time.Second
						fmt.Printf("[SDK] Received explicit Backpressure Signal: Delaying exactly %ds for cluster queue to drain...\n", seconds)
					}
				}

			default:
				// 5xx unexpected server errors (Gateway panicked, Node physically crashed)
				if resp.StatusCode >= 500 {
					lastErr = fmt.Errorf("HTTP %d Server Error [TraceID: %s]", resp.StatusCode, reqID)
				} else {
					return nil, fmt.Errorf("unexpected HTTP %d [TraceID: %s]", resp.StatusCode, reqID)
				}
			}
		}

		if attempt == c.config.MaxRetries {
			break
		}

		// Calculate Jittered Backoff
		jitter := time.Duration(rand.Int63n(int64(delay) / 2)) // Jitter is 0 to 50% of delay
		sleepTime := delay + jitter

		fmt.Printf("[SDK] Request failed. Retrying in %v (Attempt %d/%d) - Error: %v\n", sleepTime, attempt+1, c.config.MaxRetries, lastErr)
		time.Sleep(sleepTime)

		// Exponential growth bounded by MaxDelay
		delay *= 2
		if delay > c.config.MaxDelay {
			delay = c.config.MaxDelay
		}
	}

	return nil, fmt.Errorf("maximum retries exhausted (%d): latest err: %v", c.config.MaxRetries, lastErr)
}
