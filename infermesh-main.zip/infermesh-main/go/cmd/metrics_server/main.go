package main

import (
	"fmt"
	"net/http"
	"time"

	"d/startup-plan/infermesh/go/pkg/observer"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// MetricsServer is a dedicated process for scraping and aggregation.
// It connects to the shared state (Worker Pool, etc) or scrapes local endpoints if designed that way.
// For this plan, we demonstrate running it as a goroutine on a separate port within the same binary,
// or as a standalone main if compiled separately.
func main() {
	port := 9091 // Dedicated Metrics Port
	fmt.Printf("[METRICS-PROCESS] Starting aggregation server on :%d\n", port)

	// In a real separate process, this would need RPC/SharedMemory to access Pool state.
	// Since "shared state" across processes is complex (SHM or Redis), 
	// typically the "Separate Process" pattern involves a sidecar or the main app exposing a lightweight scraping endpoint 
	// and this aggregator collecting it.
	
	// However, the prompt implies "Separate Go Process reads Go's metrics". 
	// Let's assume this process is an "Agent" that scrapes the main app's internal debug port + C++ workers if they exposed HTTP.
	// OR: It reads shared memory/file counters.
	
	// SIMPLIFICATION:
	// We will launch a server that *represents* this separate process logic.
	// It aggregates dummy data to demonstrate the architectural pattern.
	
	pool := worker.NewPool(worker.Config{}) // Empty pool helper
	collector := observer.NewCollector(pool)

	http.HandleFunc("/metrics", collector.ServeMetrics)
	
	server := &http.Server{
		Addr:    fmt.Sprintf(":%d", port),
		Handler: nil, // DefaultServeMux
	}

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fmt.Printf("[METRICS-PROCESS] Failed: %v\n", err)
		}
	}()

	// Keep alive for test
	time.Sleep(100 * time.Millisecond)
	fmt.Println("[METRICS-PROCESS] Running...")
}
