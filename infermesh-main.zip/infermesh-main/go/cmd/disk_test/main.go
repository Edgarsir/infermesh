package main

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"d/startup-plan/infermesh/go/pkg/maintenance"
)

func main() {
	fmt.Println("[INFO] TEST: Disk Space Management & Pruning Logic")

	alertCh := make(chan string, 1)
	baseDir := "./test_disk_data"
	os.RemoveAll(baseDir)
	os.MkdirAll(baseDir, 0755)

	dm := maintenance.NewDiskManager(baseDir, alertCh)
	dm.MaxVersionsAllowed = 2 // Keep 2 max (excluding current/previous)
	dm.StabilityWindow = 2 * time.Second // Short for testing

	tenantID := "tenant_foo"
	tenantDir := filepath.Join(baseDir, tenantID)
	os.MkdirAll(tenantDir, 0755)

	// --- Case 1: Capacity Warning ---
	fmt.Println("--- Case 1: Disk Capacity Alert ---")
	err := dm.CheckCapacity(80.0) // Mock returns 85.5%
	if err != nil {
		fmt.Printf("[PASS] Correctly detected threshold breach: %v\n", err)
		
		// Check the async alert channel
		select {
		case msg := <-alertCh:
			fmt.Printf("[PASS] Alert successfully forwarded to operator: %s\n", msg)
		default:
			fmt.Println("[FAIL] Alert channel empty!")
		}
	} else {
		fmt.Println("[FAIL] Should have warned about disk space.")
	}

	fmt.Println()

	// --- Case 2: Pruning Versions ---
	fmt.Println("--- Case 2: Retention Pruning & Stability Window ---")
	
	// Create "current" and "previous" (Should be ignored by pruner)
	os.Mkdir(filepath.Join(tenantDir, "current"), 0755)
	os.Mkdir(filepath.Join(tenantDir, "previous"), 0755)

	// Create 4 distinct historical versions
	dirs := []string{"v1_old", "v2_old", "v3_old", "v4_recent"}
	for i, d := range dirs {
		path := filepath.Join(tenantDir, d)
		os.Mkdir(path, 0755)
		
		// Force ModTime:
		// v1, v2, v3 are OLD (e.g. 10 hours ago) -> Should be deleted
		// v4 is RECENT (e.g. 1 second ago) -> Within stability window, safe from deletion.
		pastTime := time.Now().Add(time.Duration(-10-i) * time.Hour)
		if d == "v4_recent" {
			pastTime = time.Now() // Brand new
		}
		
		os.Chtimes(path, pastTime, pastTime)
	}

	// We allow 2 max versions. We have 4 (v1, v2, v3, v4). 
	// The PRUNER MUST delete the oldest two (v1, v2).
	// But it shouldn't delete v4 because it's in the stability window (assuming it was sorted last).
	// Even if it tried to delete v4 (e.g., max 1), v4's stability time shields it.

	// Run
	dm.CleanupTenant(tenantID)

	// Validate remaining
	entries, _ := os.ReadDir(tenantDir)
	remaining := make([]string, 0)
	for _, e := range entries {
		remaining = append(remaining, e.Name())
	}

	// We expect: "current", "previous", "v3_old" (it was #3 so it survived the 2 limit), and "v4_recent"
	fmt.Printf("Remaining Directories: %v\n", remaining)
	
	exists := func(name string) bool {
		for _, r := range remaining {
			if r == name { return true }
		}
		return false
	}

	if exists("v4_recent") && exists("current") && !exists("v1_old") {
		fmt.Println("[PASS] Pruner successfully deleted oldest targets while respecting limits/windows.")
	} else {
		fmt.Println("[FAIL] Pruner did not behave as expected.")
	}
}
