package main

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"strconv"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Clock Skew & Staleness Validation Logic")

	// Max 2000ms old, Max 200ms in the future
	cfg := gateway.ClockSkewConfig{
		MaxStalenessMs:    2000,
		FutureToleranceMs: 200,
	}
	middleware := gateway.NewClockMiddleware(cfg)

	// Mock next handler
	dummyHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Success"))
	})
	wrapped := middleware.WrapHandler(dummyHandler)

	runTest := func(name string, offsetMs int64, expectedStatus int) {
		fmt.Printf("--- Case: %s ---\n", name)
		
		serverTime := time.Now().UnixMilli()
		clientTime := serverTime + offsetMs // Negative offset = client is in the past (stale request)

		req := httptest.NewRequest("GET", "/predict", nil)
		req.Header.Set("X-Client-Timestamp", strconv.FormatInt(clientTime, 10))
		
		rr := httptest.NewRecorder()
		wrapped.ServeHTTP(rr, req)

		// 1. Verification of Status Code
		if rr.Code == expectedStatus {
			fmt.Printf("[PASS] Expected HTTP %d, got %d.\n", expectedStatus, rr.Code)
		} else {
			fmt.Printf("[FAIL] Expected HTTP %d, got %d. Body: %s\n", expectedStatus, rr.Code, rr.Body.String())
		}

		// 2. Verification of Server Timestamp Header injection
		serverHeader := rr.Header().Get("X-Server-Timestamp")
		if serverHeader != "" {
			fmt.Printf("[PASS] X-Server-Timestamp successfully injected: %s\n", serverHeader)
		} else {
			fmt.Println("[FAIL] X-Server-Timestamp NOT INJECTED!")
		}
		fmt.Println()
	}

	// Case 1: Perfect Sync (0ms offset)
	runTest("Perfect Synchronization", 0, http.StatusOK)

	// Case 2: Slightly Stale but valid (client is 500ms behind server)
	// Example: Server=1000, Client=500 -> Delta=+500 -> Allowed (<2000)
	runTest("Slight Network Delay (500ms)", -500, http.StatusOK)

	// Case 3: Reject Stale Request (client is 2500ms behind server)
	// Example: Server=3000, Client=500 -> Delta=+2500 -> Blocked (>2000)
	runTest("Too Stale (2500ms delay)", -2500, http.StatusRequestTimeout)

	// Case 4: Slightly Future but valid (client clock is fast by 100ms)
	// Example: Server=1000, Client=1100 -> Delta=-100 -> Allowed (>-200)
	runTest("Clock Drift Fast (100ms future)", 100, http.StatusOK)

	// Case 5: Reject Future Request (client clock massively desynced, 5000ms fast)
	// Example: Server=1000, Client=6000 -> Delta=-5000 -> Blocked (<-200)
	runTest("Clock Desync (5000ms future)", 5000, http.StatusBadRequest)
}
