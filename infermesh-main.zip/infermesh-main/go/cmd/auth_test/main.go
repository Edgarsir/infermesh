package main

import (
	"crypto/rand"
	"crypto/rsa"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Rigorous JWT Validation & Secret Rotation")

	// 1. Setup Keys (Simulating an active and a retired key)
	keyV1, _ := rsa.GenerateKey(rand.Reader, 2048)
	keyV2, _ := rsa.GenerateKey(rand.Reader, 2048)

	initialKeys := map[string]*rsa.PublicKey{
		"kid-v1": &keyV1.PublicKey,
	}

	val := gateway.NewTokenValidator(gateway.AuthConfig{
		Issuer:    "infermesh-auth",
		Keys:      initialKeys,
	})

	validClaims := gateway.TenantClaims{
		TenantID: "tenant-123",
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(1 * time.Hour)),
			Issuer:    "infermesh-auth",
		},
	}

	// 2. Initial State: Only V1 key is trusted
	fmt.Println("--- Phase 1: Pre-Rotation ---")
	
	// Create Token signed with V1 (Explicitly setting kid)
	token1 := jwt.NewWithClaims(jwt.SigningMethodRS256, validClaims)
	token1.Header["kid"] = "kid-v1"
	tokenString1, _ := token1.SignedString(keyV1)

	_, err1 := val.VerifyToken(tokenString1)
	if err1 == nil {
		fmt.Println("[PASS] Accepted token signed with V1 Key.")
	} else {
		fmt.Printf("[FAIL] V1 Token rejected: %v\n", err1)
	}

	// 3. The Rotation Window: Trust both V1 and V2
	fmt.Println("--- Phase 2: The Rotation Window (Both Keys Trusted) ---")
	
	val.UpdateKeys(map[string]*rsa.PublicKey{
		"kid-v1": &keyV1.PublicKey,
		"kid-v2": &keyV2.PublicKey,
	})
	fmt.Println("[INFO] Admin triggered UpdateKeys() adding V2.")

	// Create Token signed with V2
	token2 := jwt.NewWithClaims(jwt.SigningMethodRS256, validClaims)
	token2.Header["kid"] = "kid-v2"
	tokenString2, _ := token2.SignedString(keyV2)

	_, errV1Agn := val.VerifyToken(tokenString1)
	_, errV2 := val.VerifyToken(tokenString2)

	if errV1Agn == nil && errV2 == nil {
		fmt.Println("[PASS] Both legacy V1 tokens and new V2 tokens are accepted simultaneously!")
	} else {
		fmt.Println("[FAIL] Rotation window failed to accept both tokens.")
	}

	// 4. Finalizing Rotation: Drop V1
	fmt.Println("--- Phase 3: Finalizing Rotation (Drop V1) ---")
	
	val.UpdateKeys(map[string]*rsa.PublicKey{
		"kid-v2": &keyV2.PublicKey, // V1 is intentionally dropped
	})
	fmt.Println("[INFO] Admin triggered UpdateKeys() dropping V1.")

	_, errV1Final := val.VerifyToken(tokenString1)
	if errV1Final != nil {
		fmt.Printf("[PASS] Correctly rejected legacy V1 token: %v\n", errV1Final)
	} else {
		fmt.Println("[FAIL] V1 token was still accepted after being dropped!")
	}
}
