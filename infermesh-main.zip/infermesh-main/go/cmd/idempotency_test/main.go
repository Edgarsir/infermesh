package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
	"d/startup-plan/infermesh/go/sdk"
)

func main() {
	fmt.Println("[INFO] TEST: Go Orchestrator Idempotency Deduplication Logic")

	// 1. Setup our mock centralized cache (representing Redis instances mapped to Go processes)
	redisMock := gateway.NewMockRedisStore()
	
	// Create middleware with a tiny 2-second TTL for testing
	idemMiddleware := gateway.NewIdempotencyMiddleware(redisMock, 2*time.Second)

	// 2. Setup a Dummy Backend Simulation
	var cpuComputationsExecuted int32

	backendHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&cpuComputationsExecuted, 1)

		mode := r.URL.Query().Get("mode")
		if mode == "fail" {
			// Simulating an internal error where we SHOULD NOT cache the result
			w.WriteHeader(http.StatusInternalServerError)
			w.Write([]byte("Internal Compute Error"))
			return
		}

		// Simulating successful heavy float multiplication
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		resp := sdk.PredictResponse{
			Signal:     "SELL",
			Confidence: 0.99,
		}
		json.NewEncoder(w).Encode(resp)
	})

	wrappedHandler := idemMiddleware.WrapHandler(backendHandler)

	server := httptest.NewServer(wrappedHandler)
	defer server.Close()

	// Helper for HTTP firing
	fireRequest := func(key string, mode string) int {
		req, _ := http.NewRequest("POST", server.URL+"?mode="+mode, nil)
		req.Header.Set("Idempotency-Key", key)
		req.Header.Set("X-Tenant-Id", "tenant-test-1")

		resp, _ := http.DefaultClient.Do(req)
		resp.Body.Close()
		return resp.StatusCode
	}

	fmt.Println("--- Case 1: First Execution (Cache Miss) ---")
	status1 := fireRequest("key-abc-123", "success")
	if status1 == 200 && atomic.LoadInt32(&cpuComputationsExecuted) == 1 {
		fmt.Println("[PASS] Request forwarded to backend compute layer and executed.")
	} else {
		fmt.Println("[FAIL] Request didn't compute normally.")
		return
	}

	fmt.Println("\n--- Case 2: Immediate Retry Execution (Cache Hit) ---")
	// Fire again instantly with exactly the same key. The backend count should NOT increment.
	status2 := fireRequest("key-abc-123", "success")
	if status2 == 200 && atomic.LoadInt32(&cpuComputationsExecuted) == 1 {
		fmt.Println("[PASS] Deduplication successful! Returned JSON from memory without waking backend CPU.")
	} else {
		fmt.Println("[FAIL] Cache missed on immediate retry! Compute count incremented dangerously.")
		return
	}

	// Wait 2+ seconds for TTL to drop the cache
	fmt.Println("\n--- Case 3: TTL Cache Garbage Collection / Deletion ---")
	fmt.Println(" Waiting 3 seconds for TTL expiration bounds...")
	time.Sleep(3 * time.Second)

	status3 := fireRequest("key-abc-123", "success")
	if status3 == 200 && atomic.LoadInt32(&cpuComputationsExecuted) == 2 {
		fmt.Println("[PASS] TTL wiped accurately. Retry treated as fresh request and sent back to compute.")
	} else {
		fmt.Println("[FAIL] TTL Logic frozen!")
		return
	}

	fmt.Println("\n--- Case 4: Idempotency with Server Failures ---")
	// If a user hits a 503 load-shed error, we explicitly Do NOT cache it, 
	// because they intend to retry until they get a 200 OK.
	status4 := fireRequest("key-xyz-999", "fail")
	if status4 == 500 && atomic.LoadInt32(&cpuComputationsExecuted) == 3 {
		fmt.Println("[PASS] Initial error thrown properly.")
	}

	// Retry instantly. Since we skipped caching the failure, the backend count SHOULD iterate.
	status5 := fireRequest("key-xyz-999", "fail")
	if status5 == 500 && atomic.LoadInt32(&cpuComputationsExecuted) == 4 {
		fmt.Println("[PASS] Cache deliberately skipped storing 500-level error state, allowing physical retries to pass through gate.")
	} else {
		fmt.Println("[FAIL] System erroneously cached a failure state!")
	}
}
