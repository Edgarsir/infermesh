package main

import (
	"fmt"
	"runtime"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Go Runtime Memory Pressure & Load Shedding Logic")

	alertCh := make(chan string, 10)

	// Since we are running a tiny test, overallcating the actual host RAM is impossible.
	// Instead, we will simulate pressure by setting the MaxHeapBytes artificially low
	// exactly against our current MemStats.
	
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	
	// Set Max to exactly match current usage, ensuring we are already at ~100% 
	// of our simulated capacity.
	mockMaxBytes := m.Alloc + 100 
	
	mm := gateway.NewMemoryManager(mockMaxBytes, alertCh)

	fmt.Println("--- Case 1: Initializing under CRITICAL Load ---")
	// The background loop checks every 2s, but we'll force a check by allocating slightly more.
	
	// Create some garbage to push it over the edge immediately
	dummyGarbage := make([][]byte, 0)
	for i := 0; i < 1000; i++ {
		dummyGarbage = append(dummyGarbage, make([]byte, 1024))
	}

	time.Sleep(2500 * time.Millisecond) // Wait for the monitor loop to tick once

	if mm.ShouldShedLoad() {
		fmt.Println("[PASS] Gateway is actively SHEDDING incoming load.")
		
		scale := mm.GetDynamicQueueScale()
		if scale == 0.1 {
			fmt.Printf("[PASS] Dispatch Queues successfully clamped to %.0f%% capacity.\n", scale*100)
		} else {
			fmt.Println("[FAIL] Queue shrink scalar incorrect.")
		}

		// Verify Alert Fired
		select {
		case msg := <-alertCh:
			fmt.Printf("[PASS] SRE Alert successfully dispatched: %s\n", msg)
		default:
			fmt.Println("[FAIL] Alert channel was empty!")
		}
	} else {
		fmt.Println("[FAIL] Gateway failed to detect critical memory pressure and failed to shed load!")
	}

	// --- Case 2: Recovery ---
	fmt.Println("\n--- Case 2: Memory Recovery (Garbage Collection) ---")
	
	// Free the garbage and force GC
	dummyGarbage = nil
	runtime.GC()
	
	// Increase the mock limit massively to drop the simulated percentage
	runtime.ReadMemStats(&m)
	mm.MaxHeapBytes = m.Alloc * 10 // Pct drops to ~10%
	
	time.Sleep(2500 * time.Millisecond) // Wait for the monitor loop to tick again

	if !mm.ShouldShedLoad() {
		fmt.Println("[PASS] Load shedding deactivated successfully.")
		if mm.GetDynamicQueueScale() == 1.0 {
			fmt.Println("[PASS] Dispatch Queues restored to 100% capacity.")
		} else {
			fmt.Println("[FAIL] Queues failed to restore.")
		}
	} else {
		fmt.Println("[FAIL] System is still shedding load incorrectly.")
	}
}
