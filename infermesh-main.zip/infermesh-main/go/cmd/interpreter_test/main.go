package main

import (
	"fmt"
	"math"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Output Interpretation Logic")

	interpreter := gateway.NewInterpreter()
	
	// Ensure precision is float32 to match C++ return type
	
	// Case 1: Standard Training Layout (0=BUY, 1=SELL, 2=HOLD)
	// Output: 80% Buy, 10% Sell, 10% Hold
	fmt.Println("--- Case 1: Standard Layout (Expect BUY) ---")
	raw1 := []float32{0.80, 0.10, 0.10}
	
	sig1, conf1, _ := interpreter.Interpret(raw1, nil)
	if sig1 == "BUY" && math.Abs(conf1-0.80) < 0.001 {
		fmt.Println("[PASS] Translated to BUY correctly.")
	} else {
		fmt.Printf("[FAIL] Expected BUY, got %s (%.2f)\n", sig1, conf1)
	}

	// Case 2: Standard Layout (Expect HOLD)
	// Output: 5% Buy, 20% Sell, 75% Hold
	fmt.Println("--- Case 2: Standard Layout (Expect HOLD) ---")
	raw2 := []float32{0.05, 0.20, 0.75}
	
	sig2, conf2, _ := interpreter.Interpret(raw2, nil)
	if sig2 == "HOLD" && math.Abs(conf2-0.75) < 0.001 {
		fmt.Println("[PASS] Translated to HOLD correctly.")
	} else {
		fmt.Printf("[FAIL] Expected HOLD, got %s (%.2f)\n", sig2, conf2)
	}

	// Case 3: Tenant-Specific Custom Label Encoding
	// Suppose a tenant trained their model with logic: 0=HOLD, 1=BUY, 2=SELL
	fmt.Println("--- Case 3: Custom Tenant Mapping (Expect SELL) ---")
	customLabels := map[int]string{
		0: "HOLD",
		1: "BUY",
		2: "SELL",
	}
	
	// Output: 10% Hold, 30% Buy, 60% Sell (Index 2 is highest)
	raw3 := []float32{0.10, 0.30, 0.60}
	sig3, conf3, _ := interpreter.Interpret(raw3, customLabels)
	
	if sig3 == "SELL" {
		fmt.Println("[PASS] Used custom tenant mapping correctly.")
	} else {
		fmt.Printf("[FAIL] Expected SELL, got %s\n", sig3)
	}
}
