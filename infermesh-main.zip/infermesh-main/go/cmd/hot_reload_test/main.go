package main

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/config"
)

// MockSubsystem simulates the physical workers, rate limiters, and TLS cert managers.
type MockSubsystem struct {
	ActiveMinWorkers int
	ActiveMaxWorkers int
	ActiveRPS        int
	ActiveTLSCert    string

	// Tracking flags to verify precise granular reloads
	WorkersReloaded bool
	RPSReloaded     bool
	TLSReloaded     bool
}

// Reset clears the event tracking flags between test cases.
func (m *MockSubsystem) ResetFlags() {
	m.WorkersReloaded = false
	m.RPSReloaded = false
	m.TLSReloaded = false
}

func (m *MockSubsystem) OnWorkerLimitsChanged(min, max int) {
	fmt.Printf("   -> [Subsystem Callback] Auto-scaler updating limits: Min=%d, Max=%d\n", min, max)
	m.ActiveMinWorkers = min
	m.ActiveMaxWorkers = max
	m.WorkersReloaded = true
}

func (m *MockSubsystem) OnRateLimitChanged(rps int) {
	fmt.Printf("   -> [Subsystem Callback] Rate Limiter adopting new token-bucket rule: RPS=%d\n", rps)
	m.ActiveRPS = rps
	m.RPSReloaded = true
}

func (m *MockSubsystem) OnTLSCertChanged(path string) {
	fmt.Printf("   -> [Subsystem Callback] TLS Gateway draining old connections and rotating cert to: %s\n", path)
	m.ActiveTLSCert = path
	m.TLSReloaded = true
}

func main() {
	fmt.Println("[INFO] TEST: Zero-Downtime Configuration Hot Reloading")

	initialCfg := config.AppConfig{
		MinWorkers:   1,
		MaxWorkers:   10,
		RateLimitRPS: 1000,
		TLSCertPath:  "/certs/v1.pem",
	}

	cm := config.NewConfigManager(initialCfg)
	system := &MockSubsystem{
		ActiveMinWorkers: 1,
		ActiveMaxWorkers: 10,
		ActiveRPS:        1000,
		ActiveTLSCert:    "/certs/v1.pem",
	}
	
	cm.RegisterListener(system)

	// --- Case 1: Partial Configuration Update (Granular Notification) ---
	fmt.Println("\n--- Case 1: Granular Hot-Swapping (RPS Only) ---")
	newCfg1 := initialCfg
	newCfg1.RateLimitRPS = 5000 // Only mutate Rate Limits!

	err1 := cm.Reload(newCfg1)
	if err1 == nil && system.RPSReloaded && !system.WorkersReloaded && !system.TLSReloaded {
		fmt.Println("[PASS] Orchestrator uniquely targeted the Rate Limiter subsystem without restarting Workers or TLS.")
	} else {
		fmt.Printf("[FAIL] Incorrect execution: Workers=%v, TLS=%v\n", system.WorkersReloaded, system.TLSReloaded)
		return
	}
	system.ResetFlags()

	// --- Case 2: Catastrophic Configuration Alert (Safe Rejection) ---
	fmt.Println("\n--- Case 2: Unserviceable State Rejection (MaxWorkers = 0) ---")
	fatalCfg := cm.GetConfig()
	fatalCfg.MaxWorkers = 0 // Engineer pushes bad config deleting all capacity

	err2 := cm.Reload(fatalCfg)
	if err2 != nil {
		fmt.Printf("[PASS] Engine actively refused to apply unserviceable state. Old config preserved.\n")
		// Verify Old Config is rigorously preserved
		if system.ActiveMaxWorkers == 10 && cm.GetConfig().MaxWorkers == 10 && !system.WorkersReloaded {
			fmt.Println("[PASS] Live traffic was fundamentally insulated from the structural API misconfiguration.")
		}
	} else {
		fmt.Println("[FAIL] Engine committed suicide by accepting 0 MaxWorkers!")
		return
	}
	system.ResetFlags()

	// --- Case 3: Conflicting Configuration Mutation Rejection (Min > Max) ---
	fmt.Println("\n--- Case 3: Logical Collision Rejection (MinWorkers > MaxWorkers) ---")
	collisionCfg := cm.GetConfig()
	collisionCfg.MinWorkers = 50 // Collides because Max is 10
	
	err3 := cm.Reload(collisionCfg)
	if err3 != nil {
		fmt.Println("[PASS] Engine safely calculated logical paradox ('Min > Max') and aborted the swap.")
	} else {
		fmt.Println("[FAIL] Paradox bypass!")
		return
	}
	system.ResetFlags()

	// --- Case 4: Complete Broadside Update (Multiple Subsystems) ---
	fmt.Println("\n--- Case 4: Global Valid Hardware/TLS Swap ---")
	broadCfg := config.AppConfig{
		MinWorkers:   5,
		MaxWorkers:   50,
		RateLimitRPS: 5000, 
		TLSCertPath:  "/certs/v2-expiry-2027.pem",
	}

	err4 := cm.Reload(broadCfg)
	if err4 == nil && system.TLSReloaded && system.WorkersReloaded && !system.RPSReloaded {
		fmt.Printf("[PASS] All mutating subsystems perfectly notified and rewired memory on exactly the new inputs. (RPS accurately skipped because 5000==5000)\n")
	} else {
		fmt.Println("[FAIL] Broadside failed!")
	}
}
