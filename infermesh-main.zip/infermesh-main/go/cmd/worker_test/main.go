package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Worker Pool Initialization")

	// 1. Configure Pool
	cfg := worker.Config{
		MinWorkers:       5, // Try to start 5
		MaxWorkers:       10,
		WorkerBinaryPath: "/bin/true", // Mock binary
		ModelPath:        "/models/v1",
		StartupTimeout:   2 * time.Second,
	}

	pool := worker.NewPool(cfg)

	// 2. Run Initialization
	// We use a context with timeout to strictly enforce the startup limit.
	ctx, cancel := context.WithTimeout(context.Background(), cfg.StartupTimeout)
	defer cancel()

	start := time.Now()
	err := pool.Initialize(ctx)
	duration := time.Since(start)

	if err != nil {
		fmt.Printf("[FAIL] Pool init failed: %v\n", err)
		return
	}

	// 3. Verify Parallelism
	// If 5 workers start sequentially with 100ms delay, it takes >500ms.
	// Parallel, it should take ~100ms (plus overhead).
	fmt.Printf("[PASS] Pool Ready in %v.\n", duration)

	if duration < 200*time.Millisecond {
		fmt.Println("[SUCCESS] Parallel startup confirmed (Fast duration).")
	} else {
		fmt.Println("[WARN] Startup took longer than expected for parallel executing.")
	}

	// 4. Verify Degraded Start Logic (Mock Failure)
	// (To demonstrate complex decision logic, we'd mock Failures in WaitUntilHealthy)
	fmt.Println("       Degraded start logic is implemented in pool.go (checking len < MinWorkers).")
}
