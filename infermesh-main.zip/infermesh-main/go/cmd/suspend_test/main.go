package main

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/registry"
)

func main() {
	fmt.Println("[INFO] TEST: Tenant Emergency Stop (Suspension) Logic")

	reg := registry.NewRegistry()
	registrar := registry.NewRegistrar(reg)

	tenant := "fintech-bank-1"

	// 1. Initial Setup
	registrar.RegisterNewTenant(tenant, "enterprise", 2, 10)
	registrar.ActivateTenantModel(tenant, "v1.0.0", "xyz")

	fmt.Println("--- Case 1: Healthy Active Traffic ---")
	ready, _ := registrar.EvaluateRequestReadiness(tenant)
	if ready {
		fmt.Println("[PASS] Traffic flowing smoothly to active workers.")
	} else {
		fmt.Println("[FAIL] Traffic arbitrarily blocked!")
	}

	// 2. Emergency Trigger
	fmt.Println("\n--- Case 2: Administrative Emergency Suspend ---")
	registrar.SuspendTenant(tenant, "Trading algorithm generating hallucinated/dangerous signals.")
	
	// Try routing
	readyAfterSuspend, errMsg := registrar.EvaluateRequestReadiness(tenant)
	if !readyAfterSuspend && errMsg == "Tenant account is suspended due to an administrative or safety hold." {
		fmt.Println("[PASS] Gateway immediately blocked new inferences natively. Workers abandoned but physically left alive (vRAM kept warm).")
	} else {
		fmt.Printf("[FAIL] Suspension failed to kill switch the router! Result: %v | %s\n", readyAfterSuspend, errMsg)
	}

	// Double check state
	cfg := reg.GetTenant(tenant)
	if cfg.Status == registry.StatusSuspended {
		fmt.Println("[PASS] Database/Registry effectively isolated the tenant state.")
	}

	// 3. Lift the Suspension
	fmt.Println("\n--- Case 3: Lifting the Emergency Hold ---")
	registrar.ResumeTenant(tenant)

	readyAfterResume, _ := registrar.EvaluateRequestReadiness(tenant)
	if readyAfterResume {
		fmt.Println("[PASS] Traffic instantly unleashed back onto the natively waiting hardware with zero reboot penalty!")
	} else {
		fmt.Println("[FAIL] Infrastructure failed to resume.")
	}
}
