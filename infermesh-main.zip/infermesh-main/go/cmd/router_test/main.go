package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Router Load Balancing Logic")

	// 1. Setup Pool
	cfg := worker.Config{MinWorkers: 2, MaxWorkers: 2}
	pool := worker.NewPool(cfg)
    
	w1 := &worker.Worker{ID: 1, Healthy: true}
	w2 := &worker.Worker{ID: 2, Healthy: true}
	pool.Workers = []*worker.Worker{w1, w2}

	r := worker.NewRouter(pool)
	r.InitializeStats() // Important!

	// 2. Simulate Load
	// We expect perfect splitting if requests are short.
	fmt.Println("--- Simulation Start ---")

    // Request 1 -> Should go to W1 (First valid)
    sel1, _ := r.SelectWorker(context.Background(), "default")
    fmt.Printf("Req 1 -> Worker %d\n", sel1.ID)
    
    // Request 2 -> Should go to W2 (W1 has 1 InFlight)
    sel2, _ := r.SelectWorker(context.Background(), "default")
    fmt.Printf("Req 2 -> Worker %d\n", sel2.ID)

    // Request 3 -> Tie (Both have 1 InFlight), check TotalRequests
    // W1 has 1 total, W2 has 1 total. Tie-break via iteration order usually W1.
    sel3, _ := r.SelectWorker(context.Background(), "default")
    fmt.Printf("Req 3 -> Worker %d\n", sel3.ID)

    // Release W2
    r.ReleaseWorker(sel2)
    fmt.Println("Released Req 2 (Worker 2)")

    // Request 4 -> Should definitely go to W2 (InFlight 0 vs W1 InFlight 2)
    sel4, _ := r.SelectWorker(context.Background(), "default")
    fmt.Printf("Req 4 -> Worker %d\n", sel4.ID)

    if sel4.ID == 2 {
         fmt.Println("[PASS] Smart Load Balancing: Chose Worker 2 (Least In-Flight).")
    } else {
         fmt.Printf("[FAIL] Bad routing decision. Chose %d\n", sel4.ID)
    }
}
