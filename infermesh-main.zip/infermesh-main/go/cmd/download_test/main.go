package main

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"

	"d/startup-plan/infermesh/go/pkg/artifact"
)

func main() {
	fmt.Println("[INFO] TEST: Resumable Download Logic")

	// 1. Setup Mock Server
	content := "This is a large file content simulation."
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rangeHeader := r.Header.Get("Range")
		if rangeHeader == "bytes=5-" {
			// Resume request
			w.WriteHeader(http.StatusPartialContent)
			w.Write([]byte(content[5:])) // "is a large..."
			return
		}
		w.Write([]byte(content))
	}))
	defer server.Close()

	dest := "test_model.bin"
	defer os.Remove(dest)

	dl := artifact.NewDownloader()

	// Case 1: Partial File Simulation
	// Create first 5 bytes
	f, _ := os.Create(dest)
	f.Write([]byte(content[:5])) // "This "
	f.Close()

	// 2. Resume Download
	fmt.Println("--- Resuming Download ---")
	err := dl.DownloadFile(context.Background(), server.URL, dest)
	if err != nil {
		fmt.Printf("[FAIL] Download error: %v\n", err)
		return
	}

	// 3. Verify Content
	finalBytes, _ := os.ReadFile(dest)
	if string(finalBytes) == content {
		fmt.Println("[PASS] File content matches original (Resume Successful).")
	} else {
		fmt.Printf("[FAIL] Content Mismatch.\nExpected: %s\nGot:      %s\n", content, string(finalBytes))
	}
}
