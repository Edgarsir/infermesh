package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Feature Store Enrichment & Timeout Fallbacks")

	// 1. Mock DB configuration
	store := gateway.NewMockFeatureStore(20 * time.Millisecond) // Fast database
	store.SeedData("account_balance", 150000.0)
	store.SeedData("historical_volatility", 0.045)

	enricher := gateway.NewFeatureEnricher(store)

	// User provides exactly 2 raw network features
	clientPayload := []float64{1.5, 99.0}
	
	requiredKeys := []string{"account_balance", "historical_volatility"}

	fmt.Println("--- Case 1: Healthy Vector Merge ---")
	cfg1 := gateway.EnrichmentConfig{
		Timeout:          50 * time.Millisecond,
		TimeoutBehavior:  gateway.TimeoutReject,
		RequiredFeatures: requiredKeys,
	}

	merged, err := enricher.Enrich(context.Background(), clientPayload, cfg1)
	if err == nil && len(merged) == 4 && merged[2] == 150000.0 {
		fmt.Printf("[PASS] Instantly aggregated external DB values into C++ Tensor array: %v\n", merged)
	} else {
		fmt.Printf("[FAIL] Normal merge failed: %v", err)
		return
	}

	fmt.Println("\n--- Case 2: Catastrophic DB Lag -> Strict Rejection Policy ---")
	// The DB suddenly takes 500ms to answer queries, completely missing the 50ms SLA
	store.SetLatency(500 * time.Millisecond)

	// Strict Financial Algorithmic tenant configuration: Drop everything if data isn't fresh
	cfgStrict := gateway.EnrichmentConfig{
		Timeout:          50 * time.Millisecond,
		TimeoutBehavior:  gateway.TimeoutReject,
		RequiredFeatures: requiredKeys,
	}

	_, errStrict := enricher.Enrich(context.Background(), clientPayload, cfgStrict)
	if errStrict != nil {
		fmt.Printf("[PASS] API strictly evaluated SLA latency and rejected matrix building natively to avoid stale trade. Error: %v\n", errStrict)
	} else {
		fmt.Println("[FAIL] API suicidally allowed stale features to pass through SLA breach.")
		return
	}

	fmt.Println("\n--- Case 3: DB Lag -> Proceed with Partial/Zeroed Vectors ---")
	// For Recommender systems, we might not care. If the DB lags, just guess.
	cfgPartial := gateway.EnrichmentConfig{
		Timeout:          50 * time.Millisecond,
		TimeoutBehavior:  gateway.TimeoutProceedPartial,
		RequiredFeatures: requiredKeys,
	}

	mergedPartial, errPartial := enricher.Enrich(context.Background(), clientPayload, cfgPartial)
	if errPartial == nil && mergedPartial[2] == 0.0 {
		fmt.Printf("[PASS] API bypassed sluggish backend. Handed C++ empty defaults to prevent pipeline stall. Result: %v\n", mergedPartial)
	} else {
		fmt.Println("[FAIL] Fallback array was malformed/did not execute!")
	}

	fmt.Println("\n--- Case 4: DB Lag -> Indefinite Queuing (Patience) Policy ---")
	// For batch processing loops, we want to wait until the DB is back online.
	cfgQueue := gateway.EnrichmentConfig{
		Timeout:          50 * time.Millisecond,
		TimeoutBehavior:  gateway.TimeoutQueue,
		RequiredFeatures: requiredKeys,
	}

	// Trigger a background fix of the database
	go func() {
		time.Sleep(1 * time.Second) // Let it retry twice
		store.SetLatency(10 * time.Millisecond) // Fix DB
	}()

	start := time.Now()
	mergedQueue, errQueue := enricher.Enrich(context.Background(), clientPayload, cfgQueue)
	elapsed := time.Since(start)

	if errQueue == nil && mergedQueue[2] == 150000.0 && elapsed > 1*time.Second {
		fmt.Printf("[PASS] Successfully halted request execution, endured network degradation, recovered DB, and mathematically formed Tensor %f seconds later.\n", elapsed.Seconds())
	} else {
		fmt.Println("[FAIL] Retrying execution blocked/dropped erroneously.")
	}
}
