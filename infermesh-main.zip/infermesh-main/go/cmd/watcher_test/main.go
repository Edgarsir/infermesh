package main

import (
	"context"
	"fmt"
	"io/ioutil"
	"os"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Status File Watching Logic")

	// 1. Setup Mock Worker
	w := &worker.Worker{ID: 99}
	statusPath := "/tmp/infermesh_worker_99.status"
	os.Remove(statusPath) // Clean start

	// 2. Case A: Successful Startup
	fmt.Println("--- Case A: Normal Startup ---")
	
	// Simulate C++ process writing READY after 200ms
	go func() {
		time.Sleep(200 * time.Millisecond)
		ioutil.WriteFile(statusPath, []byte("READY"), 0644)
	}()

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	start := time.Now()
	err := w.WaitUntilHealthy(ctx)
	if err == nil && w.Healthy {
		fmt.Printf("[PASS] Detected READY in %v\n", time.Since(start))
	} else {
		fmt.Printf("[FAIL] Failed to detect READY: %v\n", err)
	}

	// 3. Case B: Crash Detection
	fmt.Println("--- Case B: Crash Detection ---")
	statusPathCrash := "/tmp/infermesh_worker_100.status"
	wCrash := &worker.Worker{ID: 100}
	os.Remove(statusPathCrash)

	// Simulate C++ process crashing immediately
	go func() {
		time.Sleep(50 * time.Millisecond)
		ioutil.WriteFile(statusPathCrash, []byte("CRASHED"), 0644)
	}()

	ctx2, cancel2 := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel2()

	err = wCrash.WaitUntilHealthy(ctx2)
	if err != nil && wCrash.State == "CRASHED" {
		fmt.Printf("[PASS] Correctly detected CRASHED signal: %v\n", err)
	} else {
		fmt.Printf("[FAIL] Did not detect crash correctly. Healthy=%v, Err=%v\n", wCrash.Healthy, err)
	}
}
