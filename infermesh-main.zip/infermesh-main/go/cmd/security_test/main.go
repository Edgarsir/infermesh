package main

import (
	"fmt"
	"math/rand"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	rand.Seed(time.Now().UnixNano()) // Ensuring functional randomness
	fmt.Println("[INFO] TEST: Model Output Poisoning Defense & Anomaly Tracking")

	cfg := gateway.SecurityConfig{
		EnablePerturbation:     true,
		NoiseScale:             0.005, // Up to 0.5% shift
		EnableAnomalyDetection: true,
		SweepHistorySize:       5, // Need 5 consecutive uniform deltas to flag an attack
	}

	interceptor := gateway.NewSecurityInterceptor(cfg)

	fmt.Println("--- Case 1: Active Output Perturbation (Defending Model Gradients) ---")
	originalConfidence := 0.85000000
	
	// If an attacker requests the exact same float arrays, they normally get exactly 0.850000 every time.
	// By shifting it slightly, they cannot mathematically map the PyTorch/C++ matrix boundaries.
	fmt.Printf(" [Original] Output: %.8f\n", originalConfidence)
	for i := 1; i <= 3; i++ {
		perturbed := interceptor.PerturbOutput(originalConfidence)
		fmt.Printf(" [Noised]   Transmission %d: %.8f\n", i, perturbed)
		if perturbed == originalConfidence {
			fmt.Println("[FAIL] Output remained fatally static!")
			return
		}
	}
	fmt.Println("[PASS] Confidence systematically shifted via bound noise scalars. Inference functionally preserved (for humans), gradient extraction actively denied (for scripts).")

	fmt.Println("\n--- Case 2: Organic Business Traffic (Normal Variance) ---")
	// Normal users might click similar buttons but their payload data is chaotic naturally
	errOrganic1 := interceptor.AnalyzeFeatureDistribution("tenant-legit", []float64{10.2, 5.5, 3.1})
	errOrganic2 := interceptor.AnalyzeFeatureDistribution("tenant-legit", []float64{99.1, 1.2, 9.9})
	errOrganic3 := interceptor.AnalyzeFeatureDistribution("tenant-legit", []float64{10.0, 5.0, 3.0})
	errOrganic4 := interceptor.AnalyzeFeatureDistribution("tenant-legit", []float64{12.5, 4.4, 6.7})
	errOrganic5 := interceptor.AnalyzeFeatureDistribution("tenant-legit", []float64{15.0, 4.4, 6.7})
	
	_ = errOrganic1
	_ = errOrganic2
	_ = errOrganic3
	_ = errOrganic4

	if errOrganic5 == nil {
		fmt.Println("[PASS] Legitimate organic payload variance smoothly passed the Gateway Analysis loop.")
	} else {
		fmt.Printf("[FAIL] Gateway organically trapped an innocent client: %v\n", errOrganic5)
		return
	}

	fmt.Println("\n--- Case 3: Grid Search Model Extraction Attack ---")
	// An attacker systematically steps through floats (0.1, 0.2, 0.3) 
	// specifically to reverse engineer mathematical activation boundaries within the Deep Learning layers.
	fmt.Println(" [SECURITY] Bad actor assumes API control and begins sweeping tensor boundaries across 5 vectors...")
	
	var errAttack error
	baseFeature := 1.000
	
	for i := 1; i <= 5; i++ {
		// Systematic, mathematically flat incremental shift [ +0.50 per request ] across Array[0]
		errAttack = interceptor.AnalyzeFeatureDistribution("tenant-hacker", []float64{baseFeature, 5.0, 5.0})
		baseFeature += 0.50
	}
	
	if errAttack != nil {
		fmt.Printf("[PASS] Instantly pinpointed adversarial geometric matrix probing!\n")
		fmt.Printf("       Triggering Isolation Action: %v\n", errAttack)
	} else {
		fmt.Println("[FAIL] Hacker successfully grid-searched our intellectual property without triggering the anomaly boundary!")
	}
}
