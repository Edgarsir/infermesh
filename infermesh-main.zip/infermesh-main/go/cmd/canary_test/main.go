package main

import (
	"fmt"
	"time"

	"infermesh.com/core/pkg/deployment" // The package we just created/modified
)

func main() {
	fmt.Println("[INFO] TEST: Canary Performance Regression Detection (p99 Latency SLA)")

	threshold := 20.0 // 20% max degradation allowed
	canary := deployment.NewCanaryDeployment("algo-tenant", "v1.0", "v2.0", threshold, 5, "override_perf_123")

	// 1. Warm up baseline trackers
	fmt.Println("--- Case 1: Healthy Canary Rollout (`v2` is slightly slower, but within threshold) ---")
	// Baseline (v1) gets ~100ms
	for i := 0; i < 50; i++ {
		canary.BaselineTracker.Record(100 * time.Millisecond)
	}

	// Canary (v2) gets ~115ms (15% slower, which is below the 20% limit)
	for i := 0; i < 50; i++ {
		canary.CanaryTracker.Record(115 * time.Millisecond)
	}

	// Evaluate
	errHealthy := canary.Evaluate("")
	if errHealthy == nil {
		fmt.Printf("[PASS] Gateway verified latency regression (+15%%) was strictly beneath the 20%% safety limit. Rollout automatically proceeded.\n")
	} else {
		fmt.Println("[FAIL] API mathematically blocked a perfectly healthy release.")
		return
	}

	fmt.Println("\n--- Case 2: Catastrophic Performance Regression (`v2` violates SLAs) ---")
	// A new massive neural network architecture arrives. It hits 150ms on Canary GPUs (+50% degradation)
	for i := 0; i < 50; i++ {
		canary.CanaryTracker.Record(150 * time.Millisecond) // Poisoning the P99 with new models
	}

	errRegression := canary.Evaluate("")
	if errRegression == deployment.ErrPerformanceRegression {
		fmt.Printf("[PASS] Gateway mathematically halted the API deployment! Protected physical SLA bounds from a 50%% mathematical spike.\n")
	} else {
		fmt.Println("[FAIL] API allowed a broken SLA model through into production!")
		return
	}

	fmt.Println("\n--- Case 3: Explicit Sudo Override for Slower/Accurate Models ---")
	// The team decides v2's prediction accuracy is so profound it's worth the 50% hit.
	// They inject the administrative override.
	errOverride := canary.Evaluate("override_perf_123")
	if errOverride == nil {
		fmt.Printf("[PASS] Successfully acknowledged performance anomaly and mathematically bypassed the rollback explicitly via Audit Token.\n")
	} else {
		fmt.Println("[FAIL] Failed to apply Sudo Overrides on manual deployment push!")
	}
}
