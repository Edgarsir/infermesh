package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/registry"
)

func main() {
	fmt.Println("[INFO] TEST: Registry Consistency & TTL Logic")

	// 1. Setup
	baseReg := registry.NewRegistry()
	
	// Mock DB Fetcher
	dbCount := 0
	fetcher := func(id string) (*registry.TenantConfig, error) {
		dbCount++
		return &registry.TenantConfig{TenantID: id, ModelVersion: fmt.Sprintf("v%d", dbCount)}, nil
	}

	// TTL = 100ms for fast testing
	layer := registry.NewConsistencyLayer(baseReg, 100*time.Millisecond, fetcher)

	// 2. First Access (Cache Miss -> DB Fetch)
	ctx := context.Background()
	cfg1, _ := layer.GetTenantWithCache(ctx, "t1")
	fmt.Printf("[TEST] First Read: Ver=%s (DB Calls: %d)\n", cfg1.ModelVersion, dbCount)

	// 3. Immediate Start Read (Cache Hit)
	cfg2, _ := layer.GetTenantWithCache(ctx, "t1")
	fmt.Printf("[TEST] Fast Read: Ver=%s (DB Calls: %d)\n", cfg2.ModelVersion, dbCount)
	
	if dbCount != 1 {
		fmt.Println("[FAIL] Expected 1 DB call, got more.")
	} else {
		fmt.Println("[PASS] Cache hit confirmed.")
	}

	// 4. Expired Read (Wait > TTL)
	time.Sleep(150 * time.Millisecond)
	cfg3, _ := layer.GetTenantWithCache(ctx, "t1")
	fmt.Printf("[TEST] Expired Read: Ver=%s (DB Calls: %d)\n", cfg3.ModelVersion, dbCount)

	if dbCount == 2 && cfg3.ModelVersion == "v2" {
		fmt.Println("[PASS] TTL Expiry worked, re-fetched updated data.")
	} else {
		fmt.Printf("[FAIL] TTL Logic broken. DB Calls: %d\n", dbCount)
	}

	// 5. Explicit Invalidation
	layer.Invalidate("t1")
	layer.GetTenantWithCache(ctx, "t1")
	if dbCount == 3 {
		fmt.Println("[PASS] Invalidation forced re-fetch.")
	}
}
