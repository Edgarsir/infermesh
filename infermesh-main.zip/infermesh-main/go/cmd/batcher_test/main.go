package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/proxy"
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Dynamic Batching Logic")

	w := &worker.Worker{ID: 101}
	// Max Batch = 32, Max Wait = 5ms
	batcher := proxy.NewDynamicBatcher(w, 32, 5)

	// Case 1: Sequential / Light Traffic (Should trigger adaptive short wait)
	fmt.Println("--- Case 1: Light Traffic (Adaptive Shrink) ---")
	start := time.Now()
	resCh1 := batcher.Enqueue("req-1", []float64{1.0, 2.0})
	res := <-resCh1
	elapsed := time.Since(start)
	
	fmt.Printf("Single request completed in %v with Signal %s\n", elapsed, res.Signal)
	// Should be ~20ms (mock infer) + 1ms (adaptive wait), much less than 5ms full wait.
	if elapsed < 25*time.Millisecond {
		fmt.Println("[PASS] Adaptive window shrank correctly for light traffic.")
	} else {
		fmt.Printf("[FAIL] Latency too high: %v\n", elapsed)
	}

	// Case 2: Burst Traffic (Groups into batches of 32) // Note 32 is max
	fmt.Println("--- Case 2: High Traffic Burst ---")
	burstCount := 40
	var channels []<-chan proxy.BatchResult
	
	for i := 0; i < burstCount; i++ {
		channels = append(channels, batcher.Enqueue(fmt.Sprintf("req-burst-%d", i), []float64{0.5, 0.5}))
	}

	// Wait for all to finish
	completeCount := 0
	for _, ch := range channels {
		<-ch
		completeCount++
	}

	fmt.Printf("Completed %d burst requests.\n", completeCount)
	// Check standard output logs to verify batch size was optimized (e.g. batch of 32, batch of 8)
	// Output should log: [BATCHER] Dispatching batch of size 32...
	// Followed by:       [BATCHER] Dispatching batch of size 8...
	fmt.Println("[PASS] Burst successfully batched and demultiplexed.")
}
