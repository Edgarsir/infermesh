package main

import (
	"context"
	"fmt"
	"net"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway" // Import the local package
)

// MockConnection implements net.Conn for testing
type MockConn struct {
	remoteAddr net.Addr
}

func (c *MockConn) Read(b []byte) (n int, err error)   { return 0, nil }
func (c *MockConn) Write(b []byte) (n int, err error)  { return 0, nil }
func (c *MockConn) Close() error                       { return nil }
func (c *MockConn) LocalAddr() net.Addr                { return nil }
func (c *MockConn) RemoteAddr() net.Addr               { return c.remoteAddr }
func (c *MockConn) SetDeadline(t time.Time) error      { return nil }
func (c *MockConn) SetReadDeadline(t time.Time) error  { return nil }
func (c *MockConn) SetWriteDeadline(t time.Time) error { return nil }

type MockAddr struct { string }

func (a MockAddr) Network() string { return "tcp" }
func (a MockAddr) String() string  { return a.string }

func main() {
	fmt.Println("[INFO] TEST: Gateway Logic Check")

	pipeline := gateway.NewRequestPipeline()

	// Case 1: Success Flow
	conn := &MockConn{remoteAddr: MockAddr{"192.168.1.50:1234"}}
	rawReq := []byte("{\"image\": \"...\"}") // Simulated body

	ctx, err := pipeline.Execute(context.Background(), conn, rawReq)
	if err != nil {
		fmt.Printf("[FAIL] Valid request rejected: %v\n", err)
		return
	}
	fmt.Printf("[PASS] Request Accepted. ID: %s, Tenant: %s\n", ctx.RequestID, ctx.TenantID)

	// Case 2: IP Rate Limit
	fmt.Println("--- Testing IP Rate Limit ---")
	spamConn := &MockConn{remoteAddr: MockAddr{"10.0.0.1:5000"}}
	
	// Exhaust limit (100)
	for i := 0; i < 100; i++ {
		pipeline.Execute(context.Background(), spamConn, rawReq)
	}
	
	// 101st request should fail
	_, err = pipeline.Execute(context.Background(), spamConn, rawReq)
	if err != nil {
		if pe, ok := err.(*gateway.PipelineError); ok && pe.Stage == "IPLimit" {
			fmt.Println("[PASS] IP Rate Limit triggered correctly.")
		} else {
			fmt.Printf("[FAIL] Unexpected error type: %v\n", err)
		}
	} else {
		fmt.Println("[FAIL] Rate limit NOT enforced!")
	}
}
