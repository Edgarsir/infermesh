package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"

	"d/startup-plan/infermesh/go/pkg/webhook"
)

func main() {
	fmt.Println("[INFO] TEST: Webhook Signature Logic")

	secret := "my_secret_key"
	wh := webhook.NewWebhookHandler(secret)
	server := httptest.NewServer(wh)
	defer server.Close()

	payload := []byte(`{"ref": "refs/heads/main"}`)

	// Case 1: Valid Request
	fmt.Println("--- Case 1: Valid Signature ---")
	
	// Compute valid signature
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write(payload)
	validSig := "sha256=" + hex.EncodeToString(mac.Sum(nil))

	req, _ := http.NewRequest("POST", server.URL, strings.NewReader(string(payload)))
	req.Header.Set("X-Hub-Signature-256", validSig)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err == nil && resp.StatusCode == http.StatusOK {
		fmt.Println("[PASS] Accepted valid request.")
	} else {
		fmt.Printf("[FAIL] Rejected valid request. Status: %d\n", resp.StatusCode)
	}

	// Case 2: Invalid Secret (Tampering)
	fmt.Println("--- Case 2: Invalid Signature (Tampered) ---")
	tamperedSig := "sha256=" + "a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5a0b1c2d3e4f5ffff" // Fake
	
	req2, _ := http.NewRequest("POST", server.URL, strings.NewReader(string(payload)))
	req2.Header.Set("X-Hub-Signature-256", tamperedSig)

	resp2, _ := client.Do(req2)
	if resp2.StatusCode == http.StatusUnauthorized {
		fmt.Println("[PASS] Rejected invalid signature (401).")
	} else {
		fmt.Printf("[FAIL] Accepted invalid signature! Status: %d\n", resp2.StatusCode)
	}

	// Case 3: Missing Header
	fmt.Println("--- Case 3: Missing Header ---")
	req3, _ := http.NewRequest("POST", server.URL, strings.NewReader(string(payload)))
	resp3, _ := client.Do(req3)
	if resp3.StatusCode == http.StatusUnauthorized {
		fmt.Println("[PASS] Rejected request with missing header.")
	}
}
