package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/deployment"
)

func main() {
	fmt.Println("[INFO] TEST: Zero-Downtime Deployment Freeze & Geofencing")

	manager := deployment.NewFreezeManager()

	nyLoc, _ := time.LoadLocation("America/New_York")
	tokyoLoc, _ := time.LoadLocation("Asia/Tokyo")

	// 1. Setup Tenant Configuration
	tenantNY := "wall-street-algo-01"
	tenantTokyo := "nikkei-algo-02"

	manager.SetTenantPolicy(tenantNY, deployment.TenantDeploymentConfig{
		EmergencyToken: "overide-us-1234",
		FreezeWindows: []deployment.FreezeWindow{
			{
				Day:       time.Monday,
				Timezone:  nyLoc,
				StartTime: time.Date(0, 0, 0, 8, 0, 0, 0, time.UTC), // 8:00 AM NY
				EndTime:   time.Date(0, 0, 0, 10, 0, 0, 0, time.UTC), // 10:00 AM NY
			},
		},
	})

	manager.SetTenantPolicy(tenantTokyo, deployment.TenantDeploymentConfig{
		EmergencyToken: "override-jp-9876",
		FreezeWindows: []deployment.FreezeWindow{
			{
				Day:       time.Monday,
				Timezone:  tokyoLoc,
				StartTime: time.Date(0, 0, 0, 8, 30, 0, 0, time.UTC), // 8:30 AM Tokyo
				EndTime:   time.Date(0, 0, 0, 11, 0, 0, 0, time.UTC), // 11:00 AM Tokyo
			},
		},
	})

	// Establish UTC simulation pointers
	// Monday 13:00 UTC = 09:00 AM New York (Active NYSE Freeze) and 22:00 PM Tokyo (Outside limits)
	simulatedUTC := time.Date(2026, time.February, 23, 13, 15, 0, 0, time.UTC) // Assume it's a Monday

	fmt.Println("--- Case 1: Deploying to Tenant without a Blackout Limit ---")
	// Nikkei algo is resting. Deployment should breeze through natively.
	errTokyo := manager.EvaluateDeployment(tenantTokyo, "", &simulatedUTC)
	if errTokyo == nil {
		fmt.Printf("[PASS] Server timezone resolution confirmed: Tokyo Market is asleep. API released execution cleanly! (Tenant '%s')\n", tenantTokyo)
	} else {
		fmt.Println("[FAIL] Tokyo execution crashed against the New York bounds incorrectly.")
		return
	}

	fmt.Println("\n--- Case 2: Catastrophic Stomp on Market Open (The Monday Bug) ---")
	// An eager intern pushes a buggy code artifact exactly at 9:15 AM EST.
	errNY1 := manager.EvaluateDeployment(tenantNY, "", &simulatedUTC)
	if errNY1 == deployment.ErrDeploymentFrozen {
		fmt.Printf("[PASS] Architecture mathematically intercepted the pipeline push during New York's primary business hour natively!\n")
	} else {
		fmt.Println("[FAIL] API allowed a codebase mutation exactly at Market Open!")
		return
	}

	fmt.Println("\n--- Case 3: Failed Emergency Override Authorization ---")
	// The operator tries to fix it via Github Webhooks using normal passwords, lacking the Sudo Audit token
	errNY2 := manager.EvaluateDeployment(tenantNY, "wrong-pass", &simulatedUTC)
	if errNY2 == deployment.ErrInvalidBypass {
		fmt.Printf("[PASS] API mathematically rejected a forged/standard user authorization sequence attempting to violate a Freeze block!\n")
	}

	fmt.Println("\n--- Case 4: Auditable Sudo Operation ---")
	// The System Administrator officially executes a fix, piping the exact Sudo token through the API
	errNY3 := manager.EvaluateDeployment(tenantNY, "overide-us-1234", &simulatedUTC)
	if errNY3 == nil {
		fmt.Printf("[PASS] Gateway acknowledged the critical Emergency Token explicitly, successfully dropping the routing blockade and executing the GPU swap.\n")
	} else {
		fmt.Println("[FAIL] Emergency procedures failed!")
	}
}
