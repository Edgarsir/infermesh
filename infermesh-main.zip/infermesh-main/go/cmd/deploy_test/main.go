package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/webhook"
)

func main() {
	fmt.Println("[INFO] TEST: Async Deployment Queuing Logic")

	dm := webhook.NewDeployManager()

	// 1. Initial Job (Processed immediately)
	e1 := &webhook.DeploymentEvent{ModelVersion: "v1"}
	dm.QueueDeployment(e1) // -> Active

	// Add slight delay to let worker pick it up
	time.Sleep(10 * time.Millisecond)

	// 2. Queue Saturation Test
	// While v1 is "running" (simulated 100ms in deployer.go):
	
	e2 := &webhook.DeploymentEvent{ModelVersion: "v2"}
	dm.QueueDeployment(e2) // -> Pending Slot
	
	e3 := &webhook.DeploymentEvent{ModelVersion: "v3"}
	dm.QueueDeployment(e3) // -> Should Drop v2, Take Slot
	
	e4 := &webhook.DeploymentEvent{ModelVersion: "v4"}
	dm.QueueDeployment(e4) // -> Should Drop v3, Take Slot

	// 3. Wait regarding results
	// We expect:
	// - v1 starts and finishes.
	// - v2 is dropped.
	// - v3 is dropped.
	// - v4 starts and finishes.
	
	// Wait enough time for v1 (100ms) + v4 (100ms)
	time.Sleep(300 * time.Millisecond)
	
	fmt.Println("[PASS] Test Complete (Verify output log for v1 and v4 only).")
}
