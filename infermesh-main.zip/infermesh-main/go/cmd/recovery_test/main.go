package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"d/startup-plan/infermesh/go/pkg/recovery"
	"d/startup-plan/infermesh/go/pkg/registry"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// MockDB implements PersistenceStore
type MockDB struct {}
func (m *MockDB) LoadAllTenants() ([]registry.TenantConfig, error) {
	return []registry.TenantConfig{
		{TenantID: "t_alpha", ModelVersion: "v2.0"},
	}, nil
}

func main() {
	fmt.Println("[INFO] TEST: Go Restart Recovery Logic")

	// 1. Setup Mock System State
	reg := registry.NewRegistry()
	pool := worker.NewPool(worker.Config{})
	db := &MockDB{}
	
	// Create Mock Sockets representing living C++ processes
	socketDir := "./test_sockets"
	os.RemoveAll(socketDir)
	os.MkdirAll(socketDir, 0755)
	
	// A valid, running worker
	w99 := filepath.Join(socketDir, "infermesh_worker_99.sock")
	os.WriteFile(w99, []byte(""), 0755)

	// A stale socket from a previously crashed worker
	wDead := filepath.Join(socketDir, "infermesh_worker_101.sock")
	os.WriteFile(wDead, []byte(""), 0755)

	manager := recovery.NewRecoveryManager(db, reg, pool, socketDir)

	// 2. Perform Recovery
	fmt.Println("--- Starting Recovery ---")
	ctx := context.Background()
	err := manager.Recover(ctx)
	
	if err != nil {
		fmt.Printf("[FAIL] Recovery error: %v\n", err)
		return
	}

	// 3. Verify Registry Reconstruction
	fmt.Println("--- Verifying State ---")
	t := reg.GetTenant("t_alpha")
	if t != nil && t.ModelVersion == "v2.0" {
		fmt.Println("[PASS] Registry authoritative state restored from Database.")
	} else {
		fmt.Println("[FAIL] Registry empty or incorrect.")
	}

	// 4. Verify Worker Adoption
	if len(pool.Workers) == 1 && pool.Workers[0].ID == 99 {
		fmt.Println("[PASS] Worker 99 successfully adopted (State: HEALTHY).")
	} else {
		fmt.Printf("[FAIL] Pool contains wrong number of workers: %d\n", len(pool.Workers))
	}

	// Verify Stale Cleanup
	if _, err := os.Stat(wDead); os.IsNotExist(err) {
		fmt.Println("[PASS] Stale socket 101 correctly cleaned up.")
	} else {
		fmt.Println("[FAIL] Stale socket 101 STILL EXISTS.")
	}
}
