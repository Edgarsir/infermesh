package main

import (
	"fmt"
	
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Backward Compatibility & Rolling Upgrade Logic")

	matcher := &worker.VersionMatcher{}

	// Simulated rolling upgrade pool
	// We have 4 workers: two are fully upgraded to V2, two are lingering on V1.
	w1 := &worker.Worker{ID: 101, Healthy: true, ProtoVersion: 1} // Old Binary
	w2 := &worker.Worker{ID: 102, Healthy: true, ProtoVersion: 1} // Old Binary
	w3 := &worker.Worker{ID: 201, Healthy: true, ProtoVersion: 2} // Upgraded Binary
	w4 := &worker.Worker{ID: 202, Healthy: true, ProtoVersion: 2} // Upgraded Binary
	
	allWorkers := []*worker.Worker{w1, w2, w3, w4}

	// Case 1: Legacy Tenant Request (Needs V1)
	// V1 requests should be fully backward compatible. Both V1 AND V2 workers can process them.
	// New fields in V2 protobuf are optional defaults, so the V2 C++ binary simply ignores missing fields.
	fmt.Println("--- Case 1: Legacy Payload (Required Proto: V1) ---")
	legacyRequired := int32(1)
	compat1 := matcher.FilterCompatibleWorkers(allWorkers, legacyRequired)
	
	if len(compat1) == 4 {
		fmt.Printf("[PASS] Legacy payload routed completely dynamically to all %d workers.\n", len(compat1))
	} else {
		fmt.Printf("[FAIL] Expected 4 workers, got %d.\n", len(compat1))
	}

	// Case 2: New Tenant Request (Needs V2 Feature)
	// V2 requests contain fields the V1 C++ binary does not know how to parse or handle mathematically.
	// Go MUST explicitly filter out V1 workers and only route to the upgraded V2 workers.
	fmt.Println("--- Case 2: Modern Payload (Required Proto: V2) ---")
	modernRequired := int32(2)
	compat2 := matcher.FilterCompatibleWorkers(allWorkers, modernRequired)
	
	if len(compat2) == 2 && compat2[0].ID == 201 && compat2[1].ID == 202 {
		fmt.Printf("[PASS] Modern payload isolated to %d upgraded workers safely. Legacy workers skipped.\n", len(compat2))
	} else {
		fmt.Printf("[FAIL] Expected 2 upgraded workers, got %d.\n", len(compat2))
	}
}
