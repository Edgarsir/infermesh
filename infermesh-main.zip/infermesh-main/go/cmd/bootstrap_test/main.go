package main

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/registry"
)

func main() {
	fmt.Println("[INFO] TEST: Tenant Onboarding Bootstrap Logic")

	reg := registry.NewRegistry()
	registrar := registry.NewRegistrar(reg)

	tenant := "new_fintech_tenant"

	// Case 1: Initial Registration
	fmt.Println("--- Case 1: Provisioning (PENDING_MODEL) ---")
	registrar.RegisterNewTenant(tenant, "enterprise", 2, 10)
	
	// Fast-Fail Inference Evaluation
	ready, errMsg := registrar.EvaluateRequestReadiness(tenant)
	if !ready && errMsg == "Model configuration pending. Please finalize CI/CD artifact upload before sending inference traffic." {
		// Gateway maps this to a 409 Conflict, telling client "Hold on, setup incomplete"
		fmt.Printf("[PASS] Gateway successfully rejected premature API request: %s\n", errMsg)
	} else {
		fmt.Println("[FAIL] Premature request bypassed bootstrap gate!")
	}

	// Double check no workers were hypothetically started
	cfg := reg.GetTenant(tenant)
	if cfg.Status == registry.StatusPendingModel {
		fmt.Println("[PASS] Tenant confirmed locked in PENDING_MODEL state.")
	}

	// Case 2: Artifact Verified and Promoted
	fmt.Println("\n--- Case 2: Webhook CI/CD Finalized (ACTIVE) ---")
	// CI/CD pipeline downloads the model, verifies hash, moves to staging, and calls activate
	registrar.ActivateTenantModel(tenant, "v1.0.0", "abcdef1234")

	ready2, _ := registrar.EvaluateRequestReadiness(tenant)
	if ready2 {
		fmt.Println("[PASS] Tenant unlocked. Inference requests now permitted.")
	} else {
		fmt.Println("[FAIL] Tenant did not unlock after model activation!")
	}

	cfg2 := reg.GetTenant(tenant)
	if cfg2.Status == registry.StatusActive {
		fmt.Println("[PASS] State perfectly transitioned to ACTIVE.")
	}
}
