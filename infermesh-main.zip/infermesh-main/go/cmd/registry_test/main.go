package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/registry"
)

func main() {
	fmt.Println("[INFO] TEST: Tenant Registry Logic")

	reg := registry.NewRegistry()

	// 1. Seed Registry
	t1 := registry.TenantConfig{
		TenantID:     "t_123",
		ModelVersion: "v1.0",
		ModelHash:    "abc-hash",
		MinWorkers:   2,
		MaxWorkers:   5,
		RateLimitRPS: 100,
	}
	reg.UpdateTenant(t1)

	// 2. High-Speed Lookup Test
	start := time.Now()
	for i := 0; i < 1_000_000; i++ {
		_ = reg.GetTenant("t_123")
	}
	elapsed := time.Since(start)
	
	fmt.Printf("[PASS] 1M Lookups in %v (%.2f ns/op)\n", elapsed, float64(elapsed.Nanoseconds())/1e6)

	// 3. Verify Correctness
	cfg := reg.GetTenant("t_123")
	if cfg != nil && cfg.ModelVersion == "v1.0" {
		fmt.Println("[PASS] Retrieved correct config.")
	} else {
		fmt.Println("[FAIL] Config mismatch or missing.")
	}

	// 4. Verify Thread Safety (Update while reading)
	go func() {
		for i := 0; i < 100; i++ {
			t1.RateLimitRPS++ 
			reg.UpdateTenant(t1)
			time.Sleep(1 * time.Millisecond)
		}
	}()
	
	// Concurrent reads
	for i := 0; i < 100; i++ {
		c := reg.GetTenant("t_123")
		if c.RateLimitRPS < 100 {
			fmt.Println("[FAIL] Race condition or bad update logic.")
		}
	}
	fmt.Println("[PASS] Concurrent R/W verified safely.")
}
