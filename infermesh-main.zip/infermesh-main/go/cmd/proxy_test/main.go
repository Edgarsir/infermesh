package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/proxy"
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Proxy Timeout Logic")

	w := &worker.Worker{ID: 1, Healthy: true, ConsecutiveFailures: 0}
	p := &proxy.RequestProxy{}

	// Case 1: Success
	ctx := context.Background()
	_, err := p.Execute(ctx, w, "data")
	if err == nil {
		fmt.Printf("[PASS] Successful execution. Failures: %d\n", w.ConsecutiveFailures)
	}

	// Case 2: Timeout
	// Force timeout by passing context with very short deadline
	shortCtx, cancel := context.WithTimeout(context.Background(), 1*time.Millisecond)
	defer cancel()
	
	fmt.Println("--- Case 2: Timeout ---")
	_, err2 := p.Execute(shortCtx, w, "data")
	
	// Expect error AND incremented failure count
	if err2 != nil && w.ConsecutiveFailures > 0 {
		fmt.Printf("[PASS] Timeout correctly handled. Error: %v\n", err2)
		fmt.Printf("       Worker Failure Count Incremented to: %d\n", w.ConsecutiveFailures)
	} else {
		fmt.Printf("[FAIL] Timeout logic broken. Err: %v, Failures: %d\n", err2, w.ConsecutiveFailures)
	}
}
