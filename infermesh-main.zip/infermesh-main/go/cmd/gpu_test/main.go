package main

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: GPU Assignment and Affinity Logic")

	// Server with 4 physical GPUs (0, 1, 2, 3)
	mgr := worker.NewGPUManager(4)

	// Case 1: Initial Even Distribution
	fmt.Println("--- Case 1: Even Distribution ---")
	mgr.AssignGPU(101, "tenant_A", -1) // Expect GPU 0
	mgr.AssignGPU(102, "tenant_A", -1) // Expect GPU 0 (Affinity tie-break) OR 1? 
	// Wait, if GPU 0 has load 1 and GPU 1 has load 0, minLoad wins. Load MUST balance first!
	mgr.AssignGPU(103, "tenant_B", -1) 
	mgr.AssignGPU(104, "tenant_C", -1) 

	// Let's verify standard distribution:
	// Worker 101 -> GPU 0 (Load 1)
	// Worker 102 -> GPU 1 (Load 1)
	// Worker 103 -> GPU 2 (Load 1)
	// Worker 104 -> GPU 3 (Load 1)
	
	// Print load
	for i := 0; i < 4; i++ {
		fmt.Printf("GPU %d Load: %d\n", i, mgr.GPUs[i].WorkerCount)
	}

	// Case 2: Tenant Affinity on Scaling
	fmt.Println("--- Case 2: Tenant Affinity (Tie-Break) ---")
	// Now all GPUs have Load 1. We schedule a new worker for tenant_A.
	// GPU 0 and GPU 1 both have tenant_A workers from before (assuming 101->0, 102->1).
	// Actually 101->0(tenant_A), 102->1(tenant_A), 103->2(tenant_B), 104->3(tenant_C).
	// A new tenant_A worker should ideally snap to GPU 0 or 1.
	
	gpuID, _ := mgr.AssignGPU(105, "tenant_A", -1)
	if gpuID == 0 || gpuID == 1 {
		fmt.Printf("[PASS] Tenant Affinity working. tenant_A routed to existing cache on GPU %d\n", gpuID)
	} else {
		fmt.Printf("[FAIL] Tenant Affinity failed. Routed to GPU %d\n", gpuID)
	}

	// Case 3: Exact Replacement
	fmt.Println("--- Case 3: Replacement Worker Affinity ---")
	// Worker 103 (on GPU 2) dies.
	mgr.ReleaseGPU(103, "tenant_B")
	
	// Spawning replacement for 103. We MUST schedule it on GPU 2.
	newGpuID, _ := mgr.AssignGPU(999, "tenant_B", 2)
	if newGpuID == 2 {
		fmt.Println("[PASS] Replacement worker accurately pinned to predecessor's GPU 2.")
	} else {
		fmt.Printf("[FAIL] Replacement worker drifted to GPU %d!\n", newGpuID)
	}

	// Case 4: GPU Hardware Failure Quarantine
	fmt.Println("--- Case 4: GPU Failure Isolation ---")
	// GPU 3 throws a CUDA unrecoverable error
	mgr.MarkGPUDead(3)
	
	// Try to schedule 5 new workers
	for i := 110; i < 115; i++ {
		assigned, _ := mgr.AssignGPU(i, "tenant_X", -1)
		if assigned == 3 {
			fmt.Println("[FAIL] STOP! Assigned a worker to a DEAD GPU!")
			return
		}
	}
	fmt.Println("[PASS] Quarantine successful. No new workers assigned to dead GPU 3.")
}
