package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/router"
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Dispatch Pull Logic")

	// 1. Setup ecosystem
	pool := worker.NewPool(worker.Config{MinWorkers: 1})
	w := &worker.Worker{ID: 1, Healthy: true}
	pool.Workers = []*worker.Worker{w}
	
	r := router.NewRouter(pool)
	r.InitializeStats()
	
	q := worker.NewQueue(5)
	
	d := router.NewDispatcher(r, q, pool)

	// 2. Simulate Saturation: Queue is full of pending work
	fmt.Println("--- Seeding Queue ---")
	
	// Launch waiter
	go func() {
		ctx := context.Background()
		assigned, err := q.Enqueue(ctx, "t1")
		if err == nil {
			fmt.Printf("[PASS] Enqueued Request 1 picked up by Worker %d\n", assigned.ID)
		}
	}()
	
	// Give Enqueue a moment to sit in channel
	time.Sleep(50 * time.Millisecond)

	// 3. Worker Becomes Available (Simulate completion of previous task)
	fmt.Println("--- Worker Becomes Free ---")
	d.OnRequestComplete(w) // Triggers NotifyWorkerAvailable -> TryDequeue

	// Wait for goroutine print
	time.Sleep(50 * time.Millisecond)
	
	// 4. Verify Idle Behavior
	// Queue is now empty.
	fmt.Println("--- Worker Free Again (Queue Empty) ---")
	d.OnRequestComplete(w) 
	// Should print nothing or debug log about idle.
	fmt.Println("[PASS] Logic executed without panic on empty queue.")
}
