package main

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"sync"
	"time"

	"d/startup-plan/infermesh/go/pkg/lifecycle"
)

// -- Mocks --
type MockServer struct {
	Name string
}
func (m *MockServer) Shutdown(ctx context.Context) error {
	fmt.Printf("   [%s] Stopping. Draining active connections...\n", m.Name)
	time.Sleep(500 * time.Millisecond) // Simulating requests finishing
	fmt.Printf("   [%s] Fully drained.\n", m.Name)
	return nil
}

type MockLogger struct {
	Flushed bool
}
func (l *MockLogger) Flush() error {
	l.Flushed = true
	fmt.Println("   [MockLogger] Async buffers committed to disk.")
	return nil
}

type MockLock struct {
	Released bool
}
func (l *MockLock) ReleaseIfHeld() error {
	l.Released = true
	fmt.Println("   [MockLock] Distributed Lock abandoned successfully.")
	return nil
}

func main() {
	fmt.Println("[INFO] TEST: Go Graceful Shutdown Automation")

	gateway := &MockServer{Name: "Gateway-HTTP"}
	admin := &MockServer{Name: "Admin-mTLS"}
	logger := &MockLogger{}
	lock := &MockLock{}

	manager := lifecycle.NewShutdownManager(gateway, admin, logger, lock)

	// 1. Verify Load Balancer Readiness Output (Pre-Shutdown)
	fmt.Println("--- Case 1: Healthy Readiness Probe ---")
	req := httptest.NewRequest("GET", "/healthz", nil)
	rr := httptest.NewRecorder()
	manager.HealthCheckHandler(rr, req)
	if rr.Code == http.StatusOK {
		fmt.Printf("[PASS] Probe returned %d: Worker accepts traffic.\n", rr.Code)
	} else {
		fmt.Printf("[FAIL] Probe returned %d.\n", rr.Code)
	}

	// 2. Trigger Shutdown Asynchronously
	fmt.Println("\n--- Case 2: Signal Intercept & LB Draining ---")
	
	var wg sync.WaitGroup
	wg.Add(1)

	// Run the blocker in a goroutine
	go func() {
		defer wg.Done()
		manager.ListenAndServe()
	}()

	// Simulate OS sending SIGINT (CTRL+C)
	time.Sleep(100 * time.Millisecond)
	
	// Fetch the PID and send a kill signal
	p, _ := os.FindProcess(os.Getpid())
	p.Signal(os.Interrupt)

	// Immediately check the health probe (should be draining during the 2-second LB yielding window)
	time.Sleep(50 * time.Millisecond)
	rr2 := httptest.NewRecorder()
	manager.HealthCheckHandler(rr2, req)
	if rr2.Code == http.StatusServiceUnavailable {
		fmt.Printf("[PASS] Probe flipped to %d immediately! LB will stop sending new TCP connections.\n", rr2.Code)
	} else {
		fmt.Printf("[FAIL] Probe returned %d. Go might accept connections while dead.\n", rr2.Code)
	}

	// 3. Wait for full shutdown sequence to verify hooks
	wg.Wait()
	fmt.Println("\n--- Case 3: Teardown Verifications ---")
	if logger.Flushed {
		fmt.Println("[PASS] Log buffers successfully flushed.")
	} else {
		fmt.Println("[FAIL] Logs dropped entirely!")
	}

	if lock.Released {
		fmt.Println("[PASS] Hanging distributed locks purged.")
	} else {
		fmt.Println("[FAIL] Distributed lock leaked!")
	}
}
