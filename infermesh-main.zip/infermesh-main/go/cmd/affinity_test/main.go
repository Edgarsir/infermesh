package main

import (
	"fmt"
	"d/startup-plan/infermesh/go/pkg/router"
)

func main() {
	fmt.Println("[INFO] TEST: Worker Affinity Logic for Stateful inference (KV Cache/RNNs)")

	// 1. Initialize Rebuild State Policy 
	// The cluster automatically rebuilds state on a new node.
	arRebuild := router.NewAffinityRouter(router.PolicyRebuildState)
	
	// Two physical GPUs alive.
	arRebuild.UpdateWorkers([]string{"GPU_0", "GPU_1"})

	sessionID := "sess-chat-999"

	fmt.Println("--- Case 1: Active GPU Pinning ---")
	
	// Request #1: Hashes to random node and pins it
	assigned1, _ := arRebuild.RouteSession(sessionID)
	fmt.Printf(" [Chat Turn 1] Hashed KV State for %s -> %s\n", sessionID, assigned1)

	// Request #2: Instantly pulls the exact pinned GPU from map without hashing
	assigned2, _ := arRebuild.RouteSession(sessionID)
	fmt.Printf(" [Chat Turn 2] Retrieved Active State Affinity -> %s\n", assigned2)

	if assigned1 == assigned2 {
		fmt.Println("[PASS] Affinity Router successfully isolated Stateful Session to single GPU.")
	} else {
		fmt.Println("[FAIL] Router split the stateful session across hardware!")
	}

	fmt.Println("\n--- Case 2: GPU Crash with Rebuild Policy ---")
	// The Watchdog isolated a freeze and SIGKILLs GPU_0. GPU_1 is now alone.
	
	activeWorker := assigned1 // Keep track of which one we had
	
	var remainingWorkers []string
	if activeWorker == "GPU_0" {
		remainingWorkers = []string{"GPU_1"}
	} else {
		remainingWorkers = []string{"GPU_0"}
	}
	
	arRebuild.UpdateWorkers(remainingWorkers) 

	// Request #3: Sees the pin is dead. Rebuilds on new live gear seamlessly.
	assigned3, err3 := arRebuild.RouteSession(sessionID)
	if err3 == nil {
		fmt.Printf("[PASS] Seamlessly failed over Stateful Session %s to new hardware: %s. (Client application sends full message context string)\n", sessionID, assigned3)
	} else {
		fmt.Printf("[FAIL] Expected seamless rebuild, threw error: %v\n", err3)
	}

	fmt.Println("\n--- Case 3: GPU Crash with Fail-Fast Error Policy ---")
	
	// Create strict policy for extremely sensitive financial sequence models
	arStrict := router.NewAffinityRouter(router.PolicyErrorSessionLost)
	arStrict.UpdateWorkers([]string{"GPU_A", "GPU_B"})
	
	sessionTrader := "sess-trade-loop-xyz"
	
	// Initial route
	assignedA, _ := arStrict.RouteSession(sessionTrader)
	
	// Kill the GPU holding the trader's sequential memory variables
	arStrict.UpdateWorkers([]string{"GPU_C"}) // All previous died
	
	_, err4 := arStrict.RouteSession(sessionTrader)
	
	if err4 == router.ErrSessionLost {
		fmt.Println("[PASS] Strict Policy triggered: Return HTTP 410 Gone. SDK strictly reset trade loop.")
	} else {
		fmt.Println("[FAIL] Strict Policy did not throw ErrSessionLost!")
	}
}
