package main

import (
	"encoding/json"
	"fmt"

	"d/startup-plan/infermesh/go/pkg/webhook"
)

func main() {
	fmt.Println("[INFO] TEST: Webhook Payload Parsing")

	// Case 1: Valid Deployment Commit
	fmt.Println("--- Case 1: Valid Payload ---")
	validJSON := `{
		"ref": "refs/heads/main",
		"repository": { "name": "models-repo" },
		"head_commit": { "message": "feat: Update weights. Deploy model v2.0.0 to production" }
	}`

	event, err := webhook.ParsePayload([]byte(validJSON))
	if err == nil {
		fmt.Printf("[PASS] Parsed Event: %+v\n", event)
		if event.ModelVersion == "v2.0.0" && event.Environment == "production" {
			fmt.Println("[PASS] Version and Env correctly extracted.")
		} else {
			fmt.Println("[FAIL] Metadata extraction incorrect.")
		}
	} else {
		fmt.Printf("[FAIL] Parser error: %v\n", err)
	}

	// Case 2: Wrong Branch (Ignore)
	fmt.Println("--- Case 2: Feature Branch (Should Ignore) ---")
	branchJSON := `{
		"ref": "refs/heads/feature/new-arch",
		"repository": { "name": "models-repo" },
		"head_commit": { "message": "Deploy model v3.0 to dev" }
	}`
	_, errBranch := webhook.ParsePayload([]byte(branchJSON))
	if errBranch != nil {
		fmt.Printf("[PASS] Correctly ignored non-main branch: %v\n", errBranch)
	} else {
		fmt.Println("[FAIL] Should have ignored feature branch!")
	}

	// Case 3: No Command in Message
	fmt.Println("--- Case 3: No Command ---")
	noCmdJSON := `{
		"ref": "refs/heads/main",
		"repository": { "name": "models-repo" },
		"head_commit": { "message": "Fix typo in readme" }
	}`
	_, errNoCmd := webhook.ParsePayload([]byte(noCmdJSON))
	if errNoCmd != nil {
		fmt.Printf("[PASS] Correctly ignored commit without deploy command: %v\n", errNoCmd)
	} else {
		fmt.Println("[FAIL] Should have ignored non-deploy commit!")
	}
}
