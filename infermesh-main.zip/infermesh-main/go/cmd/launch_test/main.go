package main

import (
	"context"
	"fmt"
	"os"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Worker Process Launch Logic")

	// 1. Setup Environment
	logDir := "./logs"
	os.MkdirAll(logDir, 0755)

	// In a real test, we might use a dummy script as the binary. 
	// echo 'echo "Starting worker..."; sleep 2; echo "Exiting..."' > dummy_worker.sh
	// chmod +x dummy_worker.sh
	
	// For cross-platform (Windows) testing in this environment, 
	// we'll use a simple command available (e.g., cmd.exe or powershell).
	// However, ProcessLauncher expects a binary path. 
	// We'll mock it by just launching 'cmd.exe /c echo running'.
	binary := "cmd.exe"
	if os.Getenv("OS") != "Windows_NT" { binary = "echo" } // Fallback

	launcher := worker.NewProcessLauncher(binary, "models/v1", logDir)

	// 2. Launch Worker
	cfg := worker.LaunchConfig{
		WorkerID: 101,
		GPUIndex: 0,
	}

	ctx := context.Background()
	proc, err := launcher.Launch(ctx, cfg)
	if err != nil {
		fmt.Printf("[FAIL] Launch error: %v\n", err)
		return
	}

	fmt.Printf("[PASS] Process PID: %d\n", proc.Cmd.Process.Pid)
	fmt.Printf("       Socket Path: %s\n", proc.SocketPath)

	// 3. Monitor Exit
	fmt.Println("       Waiting for exit signal...")
	
	// Wait on the channel
	select {
	case exitErr := <-proc.ExitChan:
		if exitErr != nil {
			fmt.Printf("[INFO] Process exited with error (expected for mock binary execution): %v\n", exitErr)
		} else {
			fmt.Println("[INFO] Process exited cleanly (0).")
		}
	case <-time.After(3 * time.Second):
		fmt.Println("[FAIL] Process hung or timeout waiting for exit.")
		proc.Cmd.Process.Kill()
	}

	// 4. Check Logs
	logFile := fmt.Sprintf("%s/worker_%d.log", logDir, cfg.WorkerID)
	if _, err := os.Stat(logFile); err == nil {
		fmt.Printf("[SUCCESS] Log file created at %s\n", logFile)
	} else {
		fmt.Printf("[FAIL] Log file missing: %s\n", logFile)
	}
}
