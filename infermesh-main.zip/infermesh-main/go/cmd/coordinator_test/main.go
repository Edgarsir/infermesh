package main

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"time"

	"d/startup-plan/infermesh/go/pkg/coordinator"
	"d/startup-plan/infermesh/go/pkg/observer"
	"d/startup-plan/infermesh/go/pkg/proxy"
	"d/startup-plan/infermesh/go/pkg/router"
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Full Request Logging Integration")

	// 1. Infrastructure Setup
	pool := worker.NewPool(worker.Config{})
	w1 := &worker.Worker{ID: 55, Healthy: true}
	pool.Workers = []*worker.Worker{w1}
	
	r := router.NewRouter(pool)
	r.InitializeStats()
	
	// Logger with buffer to capture output
	var logBuf bytes.Buffer
	logger := observer.NewAsyncLogger(&logBuf, 10)
	
	collector := observer.NewCollector(pool)

	handler := &coordinator.RequestHandler{
		Router:    r,
		Proxy:     &proxy.RequestProxy{},
		Logger:    logger,
		Collector: collector,
	}

	// 2. Execute Request
	fmt.Println("--- Processing Request ---")
	ctx := context.Background()
	_, err := handler.HandleRequest(ctx, "tenant-X", "req-uuid-999", "input_data")
	
	if err != nil {
		fmt.Printf("[FAIL] Request failed: %v\n", err)
		return
	}

	// 3. Verify Log Output
	// Allow async writer to finish
	logger.Close()
	
	output := logBuf.String()
	fmt.Printf("Log Output:\n%s\n", output)

	// Validation
	if strings.Contains(output, `"total_latency_ms":`) && strings.Contains(output, `"request_id":"req-uuid-999"`) {
		fmt.Println("[PASS] Log contains calculated latency and request context.")
	} else {
		fmt.Println("[FAIL] Log missing critical fields.")
	}

	if strings.Contains(output, `"internal_cpp_latency_ms":100`) {
		fmt.Println("[PASS] Captured C++ internal latency (Mocked).")
	}
}
