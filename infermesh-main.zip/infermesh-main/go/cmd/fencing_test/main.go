package main

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/deployment"
)

func main() {
	fmt.Println("[INFO] TEST: Split-Brain Fencing Token Topology (Network Partitions)")

	// 1. Setup the mock etcd cluster and the destination storage system
	consensus := deployment.NewMockConsensusStore()
	storageResource := deployment.NewStatefulResource()

	fmt.Println("--- Case 1: Standard Leader Election & Operation ---")
	// Go Instance A boots up, takes leader role, and issues a command
	tokenA, _ := consensus.AcquireLock("model_deploy", "Instance_A")
	
	err1 := storageResource.ApplyOperation(tokenA, "Instance_A", "Version 1.0")
	if err1 == nil && storageResource.State == "Version 1.0" {
		fmt.Println("[PASS] Instance A successfully mutated infrastructure as the valid Primary.")
	}

	fmt.Println("\n--- Case 2: Split-Brain Network Partition (Zombie Node) ---")
	// A network partition occurs!
	// Instance A is still alive and thinks it's still the leader (it built a massive payload and is slowly compiling VRAM).
	// However, the Consensus Cluster can't reach Instance A, so it declares A dead.
	// Instance B wakes up, realizes there's no leader, and claims the lock!
	fmt.Println(" [CLUSTER] Partition detected. Instance B claims isolated lock.")
	
	tokenB, _ := consensus.AcquireLock("model_deploy", "Instance_B")
	
	// Instance B immediately applies a fix
	err2 := storageResource.ApplyOperation(tokenB, "Instance_B", "Version 2.0")
	if err2 == nil && storageResource.State == "Version 2.0" {
		fmt.Println("[PASS] Instance B successfully mutated infrastructure with higher Fencing Token.")
	}

	fmt.Println("\n--- Case 3: The Zombie Node Strikes ---")
	// Instance A finally finishes its massive compilation step and tries to push its 
	// state to the Storage cluster, completely unaware that it was dethroned!
	// If this was a naive standard boolean lock, Instance A would blindly overwrite Instance B's work.
	
	fmt.Println(" [ZOMBIE] Instance A attempts to push stale artifact via old token...")
	
	err3 := storageResource.ApplyOperation(tokenA, "Instance_A", "Version 1.0_Stale")
	
	if err3 == deployment.ErrFencingTokenRejected {
		fmt.Println("[PASS] The Storage layer actively evaluated the tokens! ZOMBIE Instance A isolated and rejected.")
		
		if storageResource.State == "Version 2.0" {
			fmt.Println("[PASS] Physical system state remained perfectly intact and secure.")
		} else {
			fmt.Println("[FAIL] State corrupted!")
		}
	} else {
		fmt.Println("[FAIL] The Storage layer permitted a split-brain collision!")
	}
}
