package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/deployment"
)

// MockEnvironment fakes the real filesystem and Worker Pool
type MockEnvironment struct {
	CurrentCPP string
	CurrentModel string
	SimulateCrash bool
}

func (m *MockEnvironment) GetCurrentCppVersion() string {
	return m.CurrentCPP
}

func (m *MockEnvironment) DeployCppBinary(version string) error {
	m.CurrentCPP = version
	return nil
}

func (m *MockEnvironment) WaitForWorkerHealthy() bool {
	time.Sleep(500 * time.Millisecond) // Simulating restart time
	return !m.SimulateCrash
}

func (m *MockEnvironment) DeployModelWeights(version string) error {
	m.CurrentModel = version
	return nil
}

func main() {
	fmt.Println("[INFO] TEST: Deployment Dependency & Version Skew Logic")

	env := &MockEnvironment{
		CurrentCPP: "v1.0",
		CurrentModel: "v1.0",
		SimulateCrash: false,
	}

	orch := deployment.NewOrchestrator(env)

	// Case 1: Deploy model compatible with current Engine
	fmt.Println("--- Case 1: Weights Only deployment (Compatible Engines) ---")
	m1 := deployment.Manifest{
		ModelVersion: "v1.5",
		RequiredCppBinary: "v1.0",
	}
	
	err1 := orch.ExecuteDeployment(m1)
	if err1 == nil && env.CurrentCPP == "v1.0" && env.CurrentModel == "v1.5" {
		fmt.Println("[PASS] Deployed cleanly without touching infrastructure binaries.")
	} else {
		fmt.Println("[FAIL] Err in Case 1")
	}

	// Case 2: Deploy model requiring an Engine upgrade 
	fmt.Println("\n--- Case 2: DAG Deployment (Binary Upgrade followed by Model Push) ---")
	m2 := deployment.Manifest{
		ModelVersion: "v2.0",
		RequiredCppBinary: "v2.0", // Needs C++ engine upgrade first
	}

	err2 := orch.ExecuteDeployment(m2)
	if err2 == nil && env.CurrentCPP == "v2.0" && env.CurrentModel == "v2.0" {
		fmt.Println("[PASS] Detected mismatch. Safely upgraded underlying C++ Engine, evaluated Health Checks, then released Model floats.")
	} else {
		fmt.Println("[FAIL] Dependency sequence failed!")
	}

	// Case 3: Rollback Prevention on Binary Failure
	fmt.Println("\n--- Case 3: Failing Health Check Aborts Sequence ---")
	env.SimulateCrash = true // The new C++ binary has a Segfault!
	m3 := deployment.Manifest{
		ModelVersion: "v3.0",
		RequiredCppBinary: "v3.0",
	}

	err3 := orch.ExecuteDeployment(m3)
	// Because the Go orchestrator blocked on the health check, the data weights deployment phase is skipped.
	if err3 != nil && env.CurrentModel == "v2.0" { 
		fmt.Printf("[PASS] Safely aborted deployment midway. Error: %v\n", err3)
		fmt.Println("[PASS] Old 'v2.0' weights were perfectly preserved against the broken infrastructure.")
	} else {
		fmt.Println("[FAIL] Orchestrator suicidally pushed weights into a broken infrastructure layer!")
	}
}
