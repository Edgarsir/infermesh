package main

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
	"d/startup-plan/infermesh/go/sdk"
)

func main() {
	fmt.Println("[INFO] TEST: Billing Quota Enforcement & Cycle Anchoring Logic")

	store := gateway.NewMockQuotaStore()
	manager := gateway.NewQuotaManager(store)

	// Setup Tenant Context
	tenantID := "tenant-alpha"
	monthlyQuota := int64(3) // Tiny quota for testing
	
	// Tenant signed up on the 15th of some past month
	anchorDate := time.Date(2023, time.March, 15, 0, 0, 0, 0, time.UTC)
	
	// Simulate "Today"
	simulatedToday := time.Date(2026, time.February, 20, 10, 0, 0, 0, time.UTC)

	// Calculate what the period key should be.
	// Since today is Feb 20, and anchor is 15. The period is Feb 15 - Mar 15.
	expectedKey := "quota:tenant-alpha:2026-02-15"
	actualKey := manager.CalculateBillingPeriodKey(tenantID, anchorDate, simulatedToday)
	if actualKey == expectedKey {
		fmt.Printf("[PASS] Correctly anchored billing cycle mathematically: %s\n", actualKey)
	} else {
		fmt.Printf("[FAIL] Incorrect cycle anchor bounds. Expected %s, got %s\n", expectedKey, actualKey)
		return
	}

	// --- Case 1: Healthy Requests consuming Quota ---
	fmt.Println("\n--- Case 1: Consuming Healthy Monthly Quota ---")
	
	// Wrap quota manager logic into a mock API handler
	apiHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		err := manager.CheckAndIncrement(r.Context(), tenantID, anchorDate, monthlyQuota)
		
		if err == gateway.ErrQuotaExhausted {
			w.WriteHeader(http.StatusPaymentRequired) // 402 - Distinct from 429!
			w.Write([]byte("Monthly Billing Quota Exhausted. Upgrade plan."))
			return
		} else if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"signal": "BUY"}`))
	})

	server := httptest.NewServer(apiHandler)
	defer server.Close()

	// Fire 3 requests securely.
	for i := 1; i <= 3; i++ {
		req, _ := http.NewRequest("POST", server.URL, nil)
		resp, _ := http.DefaultClient.Do(req)
		
		if resp.StatusCode == http.StatusOK {
			fmt.Printf(" [OK] Request %d consumed successfully.\n", i)
		} else {
			fmt.Printf("[FAIL] Premature quota drop on request %d\n", i)
		}
		resp.Body.Close()
	}

	// --- Case 2: Quota Exhaustion (Hard HTTP 402, NOT 429) ---
	fmt.Println("\n--- Case 2: Monthly Exhausted Rejection (402 Payment Required) ---")
	req, _ := http.NewRequest("POST", server.URL, nil)
	resp, _ := http.DefaultClient.Do(req)
	
	if resp.StatusCode == http.StatusPaymentRequired {
		fmt.Println("[PASS] Request #4 correctly intercepted and blocked with HTTP 402!")
		fmt.Println("       Client SDK differentiates this rigidly from a 429 'Retrying' State.")
	} else {
		fmt.Printf("[FAIL] Expected Payment Required (402), got %d\n", resp.StatusCode)
	}
	resp.Body.Close()

	// --- Case 3: The Next Month Rolls Over ---
	fmt.Println("\n--- Case 3: Simulating Time Rollover ---")
	fmt.Println("       [Clock] Fast-forwarding time strictly across the 15th anchor boundary...")
	
	// In the manager we used time.Now(). Mocking the function call for the test by explicitly passing the new key.
	futureMonthDate := time.Date(2026, time.March, 16, 10, 0, 0, 0, time.UTC)
	futurePeriodKey := manager.CalculateBillingPeriodKey(tenantID, anchorDate, futureMonthDate)
	
	if futurePeriodKey == "quota:tenant-alpha:2026-03-15" {
		fmt.Println("[PASS] Period mathematically rolled over cleanly to the new cycle!")
		
		// If we pushed this directly to the DB, it essentially starts at 0 automatically
		// because the map key "quota:tenant-alpha:2026-03-15" doesn't exist yet!
		val, _ := store.Increment(context.Background(), futurePeriodKey)
		if val == 1 {
			fmt.Println("[PASS] Hardware correctly treats new boundary as an uninitialized 0-usage array.")
		} else {
			fmt.Println("[FAIL] Usage carried over illegally.")
		}
	} else {
		fmt.Println("[FAIL] Did not roll over correctly.")
	}
}
