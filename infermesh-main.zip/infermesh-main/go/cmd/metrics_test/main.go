package main

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"

	"d/startup-plan/infermesh/go/pkg/observer"
	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Prometheus Metrics Logic")

	// 1. Setup Mock Pool
	pool := worker.NewPool(worker.Config{})
	w1 := &worker.Worker{ID: 10, Healthy: true, ConsecutiveFailures: 0}
	w2 := &worker.Worker{ID: 11, Healthy: false, ConsecutiveFailures: 2} // Unhealthy
	pool.Workers = []*worker.Worker{w1, w2}

	collector := observer.NewCollector(pool)

	// 2. Simulate Traffic
	collector.RecordRequest(true, false) // Success
	collector.RecordRequest(true, false) // Success
	collector.RecordRequest(false, true) // Timeout Error

	// 3. Scrape Metrics
	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()

	collector.ServeMetrics(w, req)

	resp := w.Body.String()
	fmt.Println("--- Scraped Output ---")
	fmt.Println(resp)

	// 4. Verify Content
	if strings.Contains(resp, "infermesh_requests_total 3") {
		fmt.Println("[PASS] Total requests correct.")
	} else {
		fmt.Println("[FAIL] Request count incorrect.")
	}

	if strings.Contains(resp, "infermesh_timeouts_total 1") {
		fmt.Println("[PASS] Timeout count correct.")
	}

	if strings.Contains(resp, `infermesh_worker_up{worker_id="10"} 1`) &&
	   strings.Contains(resp, `infermesh_worker_up{worker_id="11"} 0`) {
		fmt.Println("[PASS] Worker health status exported correctly.")
	} else {
		fmt.Println("[FAIL] Worker status missing or wrong.")
	}
}
