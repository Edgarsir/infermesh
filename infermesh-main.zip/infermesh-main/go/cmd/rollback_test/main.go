package main

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"d/startup-plan/infermesh/go/pkg/deployment"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// Re-use Dummy Mocks
type MockLock struct{}
func (m *MockLock) Acquire() error { return nil }
func (m *MockLock) Release() error { return nil }

type MockMetrics struct{ TriggerSpike bool }
func (m *MockMetrics) GetErrorRate(tenantID, version string) float64 {
	if m.TriggerSpike {
		return 0.30 // 30% Err -> Triggers Auto Rollback
	}
	return 0.01
}
func (m *MockMetrics) GetP99Latency(t, v string) float64 { return 0.0 }

func main() {
	fmt.Println("[INFO] TEST: Rollback API and Automatic Triggers")

	baseDir := "./rollback_test_zone"
	os.RemoveAll(baseDir)
	os.MkdirAll(baseDir, 0755)

	// Create 'current' (Bad V2)
	currentDir := filepath.Join(baseDir, "current")
	os.Mkdir(currentDir, 0755)
	os.WriteFile(filepath.Join(currentDir, "m.bin"), []byte("V2_BAD"), 0644)

	// Create 'previous' (Good V1 Backup)
	prevDir := filepath.Join(baseDir, "previous")
	os.Mkdir(prevDir, 0755)
	os.WriteFile(filepath.Join(prevDir, "m.bin"), []byte("V1_GOOD"), 0644)

	swapper := &deployment.ModelSwapper{Lock: &MockLock{}}
	pool := worker.NewPool(worker.Config{})
	metrics := &MockMetrics{}

	// Case 1: Manual Rollback
	fmt.Println("--- Case 1: Manual Rollback Trigger ---")
	manualManager := deployment.NewRollbackManager(swapper, pool, deployment.PolicyManualOnly, metrics)
	
	err := manualManager.TriggerRollback(baseDir, "tenant_foo")
	if err == nil {
		fmt.Println("[PASS] Rollback Execute returned cleanly.")
		
		// Verify File System
		content, _ := os.ReadFile(filepath.Join(currentDir, "m.bin"))
		if string(content) == "V1_GOOD" {
			fmt.Println("[PASS] File system successfully reverted to V1_GOOD.")
		} else {
			fmt.Printf("[FAIL] Content is currently %s\n", string(content))
		}
	} else {
		fmt.Printf("[FAIL] Rollback threw error: %v\n", err)
	}

	// Reset for Case 2
	os.RemoveAll(baseDir)
	os.Mkdir(baseDir, 0755)
	os.Mkdir(currentDir, 0755)
	os.WriteFile(filepath.Join(currentDir, "m.bin"), []byte("V3_BAD"), 0644)
	os.Mkdir(prevDir, 0755)
	os.WriteFile(filepath.Join(prevDir, "m.bin"), []byte("V2_GOOD"), 0644)

	// Case 2: Automatic Rollback
	fmt.Println("--- Case 2: Automatic Rollback on Threshold ---")
	autoManager := deployment.NewRollbackManager(swapper, pool, deployment.PolicyAutomatic, metrics)
	
	// Start monitoring with safe metrics
	metrics.TriggerSpike = false
	go autoManager.MonitorAutoRollback(baseDir, "tenant_bar", "V3_BAD")
	time.Sleep(50 * time.Millisecond)
	
	// Spike the errors causing the loop to trigger
	metrics.TriggerSpike = true
	time.Sleep(12 * time.Second) // wait for MonitorAutoRollback tick
	
	// Check results
	content, _ := os.ReadFile(filepath.Join(currentDir, "m.bin"))
	if string(content) == "V2_GOOD" {
		fmt.Println("[PASS] Auto-rollback cleanly detected spike and reverted.")
	} else {
		fmt.Println("[FAIL] Auto-rollback failed to execute.")
	}
}
