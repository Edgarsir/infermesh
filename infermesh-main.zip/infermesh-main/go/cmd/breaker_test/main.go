package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/router"
)

func main() {
	fmt.Println("[INFO] TEST: Circuit Breaker Logic (Soft Failure Isolation)")

	// 10% threshold, min 10 requests, 1-second timeout (for fast testing)
	cb := router.NewCircuitBreaker(0.10, 10, 1*time.Second)

	// Case 1: Healthy Operation (Closed)
	fmt.Println("--- Case 1: Normal Traffic ---")
	for i := 0; i < 8; i++ {
		if cb.AllowRequest() {
			cb.RecordResult(false) // Success
		}
	}
	fmt.Println("[PASS] Processed healthy traffic successfully.")

	// Case 2: Sub-health Anomaly (Tripping the Breaker)
	fmt.Println("--- Case 2: Elevated Error Rate (Trip to OPEN) ---")
	// Out of the next 2 requests (making total 10), we hit 2 errors (20% total error rate)
	cb.RecordResult(true)
	cb.RecordResult(true)
	
	// Circuit should now be OPEN
	if !cb.AllowRequest() {
		fmt.Println("[PASS] Circuit successfully TRIPPED! Requests are blocked.")
	} else {
		fmt.Println("[FAIL] Circuit remains closed despite errors!")
	}

	// Case 3: Timeout to Half-Open
	fmt.Println("--- Case 3: Cooldown and Half-Open ---")
	// Attempt request immediately -> blocked
	if !cb.AllowRequest() {
		fmt.Println("    Immediate request blocked (Circuit Open).")
	}

	// Wait for the timeout to pass
	fmt.Println("    Waiting for 1-second timeout...")
	time.Sleep(1200 * time.Millisecond)

	// Attempt request again -> should transition to Half-Open and allow
	if cb.AllowRequest() {
		fmt.Println("[PASS] Timeout elapsed. Circuit transitioned to HALF-OPEN. Request allowed.")
		
		// Case 4: Failing the Half-Open test
		fmt.Println("--- Case 4: Half-Open Test Fails (Back to OPEN) ---")
		cb.RecordResult(true) // The test request failed!
		
		if !cb.AllowRequest() {
			fmt.Println("[PASS] Test failed. Circuit instantly slammed shut back to OPEN.")
		} else {
			fmt.Println("[FAIL] Circuit remained open after test failure!")
		}
	} else {
		fmt.Println("[FAIL] Circuit did not transition to Half-Open after timeout!")
	}

	// Case 5: Success Recovery
	fmt.Println("--- Case 5: Recovery (Back to CLOSED) ---")
	time.Sleep(1200 * time.Millisecond) // Wait for timeout again
	
	if cb.AllowRequest() {
		cb.RecordResult(false) // The test request succeeded!
		
		// Circuit should be CLOSED
		if cb.AllowRequest() {
			fmt.Println("[PASS] Test succeeded! Circuit fully restored to CLOSED. Normal traffic resumed.")
		} else {
			fmt.Println("[FAIL] Circuit remained open despite successful test!")
		}
	}
}
