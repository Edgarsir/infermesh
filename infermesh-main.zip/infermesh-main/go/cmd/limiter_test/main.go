package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Token Bucket Rate Limiting")

	tl := gateway.NewTenantLimiter()
	tenant := "t-bursty"
	rps := 2
	burst := 5 // Allow burst of 5

	// Case 1: Burst usage
	// We should be able to send 5 requests instantly, despite RPS being 2.
	fmt.Println("--- Case 1: Burst Handling ---")
	
	for i := 1; i <= 5; i++ {
		if tl.Allow(tenant, rps, burst) {
			fmt.Printf("Req %d: Allowed (Burst)\n", i)
		} else {
			fmt.Printf("Req %d: REJECTED (Fail)\n", i)
		}
	}

	// 6th Request -> Should be rejected (Bucket Empty)
	if !tl.Allow(tenant, rps, burst) {
		fmt.Println("Req 6: REJECTED (Correct - Bucket Empty)")
	} else {
		fmt.Println("Req 6: ALLOWED (Fail - Limit broken)")
	}

	// Case 2: Refill
	// Wait 0.5s (Refills 1 token at 2 RPS)
	time.Sleep(500 * time.Millisecond)
	
	if tl.Allow(tenant, rps, burst) {
		fmt.Println("Req 7: Allowed (Refill Success)")
	} else {
		fmt.Println("Req 7: Rejected (Refill Fail)")
	}
}
