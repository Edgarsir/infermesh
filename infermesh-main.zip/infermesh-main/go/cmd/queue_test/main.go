package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

func main() {
	fmt.Println("[INFO] TEST: Request Queuing Logic")

	// 1. Setup Queue (Size 2)
	q := worker.NewQueue(2)

	// Case 1: Successful Dequeue
	fmt.Println("--- Case 1: Enqueue & Dequeue ---")
	ctx := context.Background()         
	
	// Launch a consumer
	go func() {
		time.Sleep(50 * time.Millisecond)
		req := q.TryDequeue()
		if req != nil {
			req.ResultCh <- &worker.Worker{ID: 101}
		}
	}()

	w, err := q.Enqueue(ctx, "t1")
	if err == nil {
		fmt.Printf("[PASS] Dequeued successfully. Worker: %d\n", w.ID)
	} else {
		fmt.Printf("[FAIL] Enqueue error: %v\n", err)
	}

	// Case 2: Load Shedding (Queue Full)
	fmt.Println("--- Case 2: Load Shedding ---")
    // Fill the queue
    q.Enqueue(context.Background(), "blocker1") // Takes slot 1
    // Oops Enqueue blocks until done. We need async fillers.
    
    // Reset Queue for clean slate
    qFull := worker.NewQueue(1) 
    
    // Fill it
    go func() { qFull.Enqueue(context.Background(), "filling_1") }()
    time.Sleep(10 * time.Millisecond) // Let it fill
    
    // Try to add when full
    _, errFull := qFull.Enqueue(context.Background(), "overflow")
    
    if errFull == worker.ErrQueueFull {
        fmt.Println("[PASS] Rejected with ErrQueueFull.")
    } else {
        fmt.Printf("[FAIL] Expected QueueFull, got: %v\n", errFull)
    }

	// Case 3: Deadline Expiry
	fmt.Println("--- Case 3: Timeout in Queue ---")
	qTimeout := worker.NewQueue(1)
	
	// Enqueue with short deadline
	shortCtx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	
	start := time.Now()
	_, errTime := qTimeout.Enqueue(shortCtx, "t_late")
	elapsed := time.Since(start)
	
	if elapsed >= 20*time.Millisecond && errTime != nil {
		fmt.Printf("[PASS] Timed out in %v (Error: %v)\n", elapsed, errTime)
	} else {
		fmt.Printf("[FAIL] Did not timeout correctly. Err: %v\n", errTime)
	}
}
