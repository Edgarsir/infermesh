package main

import (
	"fmt"
	"os"
	"path/filepath"
	
	"d/startup-plan/infermesh/go/pkg/deployment"
	"d/startup-plan/infermesh/go/pkg/registry"
)

// MockLock (reused)
type MockLock struct{}
func (m *MockLock) Acquire() error { return nil }
func (m *MockLock) Release() error { return nil }

func main() {
	fmt.Println("[INFO] TEST: Atomic Registry+File Transaction")

	// 1. Setup
	reg := registry.NewRegistry()
	
	// Initial State
	oldCfg := registry.TenantConfig{TenantID: "t1", ModelVersion: "v1", ModelHash: "hash_v1"}
	reg.UpdateTenant(oldCfg)
	
	// Files
	baseDir := "./tx_test"
	os.RemoveAll(baseDir)
	os.MkdirAll(baseDir, 0755)
	
	staging := filepath.Join(baseDir, "staging") // Empty, will cause Swap error if not created
	current := filepath.Join(baseDir, "current")
	os.Mkdir(current, 0755)

	tm := &deployment.TransactionManager{
		Registry: reg,
		Swapper: &deployment.ModelSwapper{Lock: &MockLock{}},
	}

	// 2. Case: Failure & Rollback
	// Staging dir does not contain model file? Or purely missing dir?
	// os.Rename fails if source missing.
	
	newCfg := registry.TenantConfig{TenantID: "t1", ModelVersion: "v2", ModelHash: "hash_v2"}
	
	fmt.Println("--- Case 1: Swap Failure (Rollback) ---")
	err := tm.DeployAtomic(newCfg, staging, current)
	
	if err != nil {
		fmt.Printf("[PASS] Correctly returned error: %v\n", err)
		
		// Verify Rollback
		finalCfg := reg.GetTenant("t1")
		if finalCfg.ModelVersion == "v1" {
			fmt.Println("[PASS] Registry rolled back to v1.")
		} else {
			fmt.Printf("[FAIL] Registry stuck on v2! Ver=%s\n", finalCfg.ModelVersion)
		}
	} else {
		fmt.Println("[FAIL] Expected error but succeeded?")
	}

	// 3. Case: Success
	fmt.Println("--- Case 2: Success ---")
	os.Mkdir(staging, 0755) // Create valid source
	
	errSuccess := tm.DeployAtomic(newCfg, staging, current)
	if errSuccess == nil {
		finalCfg := reg.GetTenant("t1")
		if finalCfg.ModelVersion == "v2" {
			fmt.Println("[PASS] Registry updated to v2.")
		}
	} else {
		fmt.Printf("[FAIL] Logical success failed: %v\n", errSuccess)
	}
}
