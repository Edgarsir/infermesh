package main

import (
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/router"
)

func main() {
	fmt.Println("[INFO] TEST: Propagated Backpressure Signaling (Dynamic Load Shedding Header)")

	tracker := router.NewBackpressureTracker()

	// 1. Initial State Setup
	//   10 workers processing requests averaging 20ms each
	fmt.Println("--- Case 1: Thundering Herd Load Calculation ---")
	tracker.SetActiveWorkers(10)
	tracker.SetQueueDepth(1000)

	// Since EWMA initializes at 20ms, calculation:
	// 1000 items * 20ms = 20000ms total compute work
	// 20000ms / 10 workers = 2000ms (2 Seconds)
	retry1 := tracker.CalculateRetryAfterSeconds()

	if retry1 == 2 {
		fmt.Printf("[PASS] Correctly signaled 'Retry-After: %d' for 1000-deep queue.\n", retry1)
	} else {
		fmt.Printf("[FAIL] Expected 2 seconds, got %d\n", retry1)
	}

	// 2. State Mutation: Half the GPUs die (Simulating node crashes or DEGRADED signaling)
	fmt.Println("\n--- Case 2: Pool Degradation (Fewer GPUs active) ---")
	tracker.SetActiveWorkers(5)
	
	// Now equation: 20000ms / 5 workers = 4 Seconds
	retry2 := tracker.CalculateRetryAfterSeconds()
	if retry2 == 4 {
		fmt.Printf("[PASS] Correctly lengthened backoff to 'Retry-After: %d' after 50%% hardware failure.\n", retry2)
	} else {
		fmt.Printf("[FAIL] Expected 4 seconds, got %d\n", retry2)
	}

	// 3. EWMA Latency Shift
	fmt.Println("\n--- Case 3: EWMA Smoothing on Slow Inferences ---")
	// Suppose a new model version deployed that is 2x larger inside VRAM.
	// It's taking 100ms per batch instead of 20ms. The EWMA must adapt smoothly over time.
	for i := 0; i < 30; i++ {
		// Log 30 individual 100ms slow requests. EWMA should drift up.
		tracker.RecordLatency(100 * time.Millisecond)
	}
	
	// The new Math: 1000 items * ~100ms avg = 100,000ms work / 5 workers = 20,000ms (20 seconds!)
	retry3 := tracker.CalculateRetryAfterSeconds()
	
	if retry3 > 15 && retry3 <= 20 {
		fmt.Printf("[PASS] EWMA successfully dragged the average up. Client backoff extended dramatically to %ds!\n", retry3)
	} else {
		fmt.Printf("[FAIL] Expected EWMA adaptation towards 20s, got %d\n", retry3)
	}

	// 4. Maximum System Death
	fmt.Println("\n--- Case 4: GPU Cluster Total Failure (0 Workers) ---")
	tracker.SetActiveWorkers(0)
	retry4 := tracker.CalculateRetryAfterSeconds()
	
	if retry4 == 5 {
		fmt.Printf("[PASS] Defaulted safely to 'Retry-After: 5' integer failsafe!\n")
	} else {
		fmt.Printf("[FAIL] Did not default 5\n")
	}

}
