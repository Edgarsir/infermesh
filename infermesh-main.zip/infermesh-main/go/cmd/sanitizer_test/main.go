package main

import (
	"fmt"
	"math"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Input Sanitization Logic")

	sanitizer := &gateway.InputSanitizer{}
	expectedDim := 3

	// Helper to run test
	runTest := func(name string, jsonStr string, expectedPass bool) {
		_, err := sanitizer.ValidatePayload([]byte(jsonStr), expectedDim)
		if expectedPass {
			if err == nil {
				fmt.Printf("[PASS] %s\n", name)
			} else {
				fmt.Printf("[FAIL] %s: Expected success, got error: %v\n", name, err)
			}
		} else {
			if err != nil {
				fmt.Printf("[PASS] %s: Correctly rejected -> %v\n", name, err)
			} else {
				fmt.Printf("[FAIL] %s: Expected rejection, but it passed!\n", name)
			}
		}
	}

	// Case 1: Valid Input
	runTest("Valid Payload", `{"feature_dim": 3, "features": [1.5, -2.0, 0.0]}`, true)

	// Case 2: Dimension Mismatch (Declared vs Expected)
	runTest("Declared Dim mismatch with Model", `{"feature_dim": 2, "features": [1.5, -2.0]}`, false)

	// Case 3: Length Mismatch (Array vs Declared)
	runTest("Array length mismatch", `{"feature_dim": 3, "features": [1.5, -2.0]}`, false)

	// Case 4: NaN Injection
	// Note: Standard json.Unmarshal usually fails on raw 'NaN' strings unless custom logic is used. 
	// To strictly test the math.IsNaN logic, we simulate parsing a payload containing it.
	// We'll test the error handling here. 
	// Since standard JSON doesn't support NaN natively, "NaN" usually fails at Unmarshal.
	// But some lenient decoders (or different formats) might let it through. 
	runTest("NaN in features (Unmarshal catches this usually)", `{"feature_dim": 3, "features": [1.5, NaN, 2.0]}`, false)

	// Direct struct test to prove IsNaN/IsInf logic
	fmt.Println("--- Direct Struct Edge Cases ---")
	payload := []byte(`{"feature_dim": 3, "features": [0.0, 0.0, 0.0]}`)
	parsed, _ := sanitizer.ValidatePayload(payload, 3)
	
	parsed.Features[1] = math.NaN()
	// Re-verify the loop logic directly
	errNaN := validateFloats(parsed.Features)
	if errNaN != nil {
		fmt.Printf("[PASS] Caught NaN directly: %v\n", errNaN)
	}

	parsed.Features[1] = math.Inf(1)
	errInf := validateFloats(parsed.Features)
	if errInf != nil {
		fmt.Printf("[PASS] Caught Infinity directly: %v\n", errInf)
	}

}

// Helper duplicating the loop for direct struct testing
func validateFloats(features []float64) error {
	for i, val := range features {
		if math.IsNaN(val) {
			return fmt.Errorf("invalid float at index %d: NaN", i)
		}
		if math.IsInf(val, 0) {
			return fmt.Errorf("invalid float at index %d: Infinity", i)
		}
	}
	return nil
}
