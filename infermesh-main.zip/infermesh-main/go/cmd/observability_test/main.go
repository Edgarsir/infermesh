package main

import (
	"fmt"
	"math/rand"
	"sync/atomic"
	"time"

	"d/startup-plan/infermesh/go/pkg/gateway"
)

func main() {
	fmt.Println("[INFO] TEST: Observability Cardinality Control Logic")

	// 1. Prometheus Structure (Low Cardinality)
	// ONLY labels that have a strictly bounded total permutation size (e.g. 10 workers * 3 models * 4 errors = 120 TSDB Series max)
	promMetrics := gateway.NewLowCardinalityMetrics()

	// 2. Specialized Database Aggregator (High Cardinality)
	// E.g. 10,000 Tenants * 60 seconds. Flushed locally in memory to save network.
	aggregator := gateway.NewHighCardinalityAggregator(1 * time.Second) // Fast flush for testing
	
	var totalPushes int32
	aggregator.FlushHook = func(snapshot map[string]int64) {
		atomic.AddInt32(&totalPushes, 1)
		fmt.Printf(" [TSDB PUSH] Aggregated tenant counters sent. (Unique Tenants Batched: %d)\n", len(snapshot))
		for k, v := range snapshot {
			fmt.Printf("             -> %s: %d reqs\n", k, v)
		}
	}
	
	aggregator.Start()
	defer aggregator.Stop()

	// --- Case 1: 10,000 High-Frequency Requests ---
	fmt.Println("--- Case 1: Thundering Data Ingestion (Simulating Scale) ---")
	
	// Simulating 50 physical concurrent threads hammering the observer
	done := make(chan bool)
	for i := 0; i < 50; i++ {
		go func(workerID int) {
			for j := 0; j < 200; j++ {
				tenant := fmt.Sprintf("tenant_%d", rand.Intn(100)) // 100 unique tenants in test
				
				// 1. Log real-time low-cardinality label correctly.
				wLabel := fmt.Sprintf("gpu_worker_%d", workerID%5)
				promMetrics.RecordRequest(wLabel, "v1.2", "none")
				
				// 2. Log ultra-high cardinality label to the delayed aggregator (Zero tenant_ids in Prometheus).
				aggregator.RecordTenantUsage(tenant)
				
				time.Sleep(1 * time.Millisecond) // micro-delay
			}
			done <- true
		}(i)
	}

	// Wait for the 10,000 reqs completely.
	for i := 0; i < 50; i++ {
		<-done
	}
	fmt.Println("[PASS] 10,000 inferences successfully processed natively through observation gates.")

	// --- Check Prometheus Limits ---
	fmt.Println("\n--- Case 2: Zero TSDB Poisoning Validation ---")
	snap := promMetrics.GetSnapshot()
	
	// With 5 active workers * 1 model * 1 error type -> There should be precisely 5 TSDB entries regardless of 10,000 permutations.
	if len(snap) <= 5 {
		fmt.Printf("[PASS] Local Prometheus limits strictly protected. TSDB Cardinality bounded safely to %d active time series.\n", len(snap))
	} else {
		fmt.Printf("[FAIL] Prometheus Poisoned! TSDB Series Cardinality exploded to %d permutations!\n", len(snap))
		return
	}

	// --- Check Aggregator Flush ---
	fmt.Println("\n--- Case 3: High-Cardinality Batching Architecture ---")
	fmt.Println("           [Waiting 2 seconds for aggressive background ticker memory release...]")
	time.Sleep(2 * time.Second)

	pushes := atomic.LoadInt32(&totalPushes)
	if pushes >= 1 {
		fmt.Println("[PASS] Successfully compressed distinct high-cardinality logs in RAM, flushing accurately to external TSDB via periodic hooks, completely bypassing Prometheus Series pollution.")
	} else {
		fmt.Println("[FAIL] Background flush tracker completely stalled.")
	}
}
