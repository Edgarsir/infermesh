package main

import (
	"bytes"
	"fmt"
	"strings"
	"time"

	"d/startup-plan/infermesh/go/pkg/observer"
)

func main() {
	fmt.Println("[INFO] TEST: Async JSON Logging Logic")

	// 1. Setup (using buffer to capture output)
	var logBuffer bytes.Buffer
	logger := observer.NewAsyncLogger(&logBuffer, 10)

	// 2. Build Log Entry
	entry := observer.AccessLogEntry{
		RequestID:       "req-123",
		TenantID:        "tenant-A",
		WorkerID:        5,
		TotalLatencyMs:  150,
		InternalLatency: 120,
		ResultSignal:    "BUY",
		Confidence:      0.95,
		Success:         true,
	}

	// 3. Log Async
	fmt.Println("--- Logging Request ---")
	start := time.Now()
	logger.LogRequest(entry)
	duration := time.Since(start)
	
	fmt.Printf("[PASS] Log function returned in %v (Should be immediate)\n", duration)

	// 4. Verify Output (Wait for flush)
	logger.Close() // Flushes channel
	
	output := logBuffer.String()
	fmt.Printf("Buffer Content:\n%s\n", output)

	if strings.Contains(output, `"request_id":"req-123"`) && strings.Contains(output, `"confidence":0.95`) {
		fmt.Println("[PASS] JSON structure valid.")
	} else {
		fmt.Println("[FAIL] Missing fields in log output.")
	}
}
