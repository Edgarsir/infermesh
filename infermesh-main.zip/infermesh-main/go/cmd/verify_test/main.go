package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"

	"d/startup-plan/infermesh/go/pkg/artifact"
)

func main() {
	fmt.Println("[INFO] TEST: File Integrity Verification Logic")

	// 1. Create a dummy model file
	filePath := "test_model_verify.bin"
	content := []byte("secret-model-weights")
	os.WriteFile(filePath, content, 0644)
	defer os.Remove(filePath) // Cleanup if test passes

	// Compute expected hash
	h := sha256.New()
	h.Write(content)
	correctHash := hex.EncodeToString(h.Sum(nil))
	wrongHash := "badhash1234567890"

	verifier := &artifact.Verifier{}

	// Case 1: Success
	fmt.Println("--- Case 1: Matching Hash ---")
	if err := verifier.VerifyHash(filePath, correctHash); err == nil {
		fmt.Println("[PASS] Correct hash accepted.")
	} else {
		fmt.Printf("[FAIL] Valid hash rejected: %v\n", err)
	}

	// Case 2: Mismatch (Should Delete File)
	fmt.Println("--- Case 2: Mismatch & Delete ---")
	
	// Re-create file because previous verify might have closed/opened it
	os.WriteFile(filePath, content, 0644)
	
	err := verifier.VerifyHash(filePath, wrongHash)
	if err == nil {
		fmt.Println("[FAIL] Invalid hash accepted!")
		return
	}
	
	fmt.Printf("[PASS] Detected mismatch: %v\n", err)

	// Verify Deletion
	if _, statErr := os.Stat(filePath); os.IsNotExist(statErr) {
		fmt.Println("[PASS] Corrupted file was deleted successfully.")
	} else {
		fmt.Println("[FAIL] Corrupted file STILL EXISTS.")
	}
}
