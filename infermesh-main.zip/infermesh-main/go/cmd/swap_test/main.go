package main

import (
	"fmt"
	"os"
	"path/filepath"
	"io/ioutil"

	"d/startup-plan/infermesh/go/pkg/deployment"
)

// MockLock implements deployment.DistributedLock
type MockLock struct {
	Captured bool
}
func (m *MockLock) Acquire() error { 
	m.Captured = true
	fmt.Println("[LOCK] Acquired.")
	return nil 
}
func (m *MockLock) Release() error { 
	m.Captured = false 
	fmt.Println("[LOCK] Released.")
	return nil 
}

func main() {
	fmt.Println("[INFO] TEST: Atomic Model Swap Logic")

	// 1. Setup Test Env
	baseDir := "./test_deploy"
	os.RemoveAll(baseDir)
	os.MkdirAll(baseDir, 0755)

	staging := filepath.Join(baseDir, "staging_v2")
	current := filepath.Join(baseDir, "current")

	// Create Staging
	os.MkdirAll(staging, 0755)
	ioutil.WriteFile(filepath.Join(staging, "model.bin"), []byte("v2_data"), 0644)

	// Create Current (Existing v1)
	os.MkdirAll(current, 0755)
	ioutil.WriteFile(filepath.Join(current, "model.bin"), []byte("v1_data"), 0644)

	swapper := &deployment.ModelSwapper{
		Lock: &MockLock{},
	}

	// 2. Perform Swap
	fmt.Println("--- Executing Swap ---")
	err := swapper.Swap(staging, current)
	if err != nil {
		fmt.Printf("[FAIL] Swap error: %v\n", err)
		return
	}

	// 3. Verify
	// Current should now contain v2_data
    content, _ := ioutil.ReadFile(filepath.Join(current, "model.bin"))
	if string(content) == "v2_data" {
		fmt.Println("[PASS] Current directory updated to v2.")
	} else {
		fmt.Printf("[FAIL] Content Mismatch. Expected v2_data, got %s\n", string(content))
	}

	// Backup should be gone
	if _, err := os.Stat(current + ".old"); os.IsNotExist(err) {
		fmt.Println("[PASS] Backup cleaned up.")
	} else {
		fmt.Println("[FAIL] Backup directory still exists.")
	}

	// Staging original path should be gone (moved)
	if _, err := os.Stat(staging); os.IsNotExist(err) {
		fmt.Println("[PASS] Staging directory consumed.")
	} else {
		fmt.Println("[FAIL] Staging directory still exists (should be moved).")
	}
}
