package main

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// MockClient simulates the gRPC client
type MockClient struct {
	Hash        string
	Mem         uint64
	Delay       time.Duration
	ShouldError bool
}

func (m *MockClient) CheckHealth(ctx context.Context) (string, uint64, error) {
	select {
	case <-time.After(m.Delay):
	case <-ctx.Done():
		return "", 0, ctx.Err()
	}

	if m.ShouldError {
		return "", 0, fmt.Errorf("connection refused")
	}
	return m.Hash, m.Mem, nil
}

func main() {
	fmt.Println("[INFO] TEST: Health Check Logic")

	// Setup Worker
	w := &worker.Worker{
		ID:                1,
		State:             "HEALTHY",
		ExpectedModelHash: "abc-123",
		ConsecutiveFailures: 0,
	}

	// Case 1: Success
	fmt.Println("--- Case 1: Healthy Response ---")
	w.HealthClient = &MockClient{Hash: "abc-123", Mem: 1024, Delay: 10 * time.Millisecond}
	isHealthy := w.PerformHealthCheck(context.Background())
	if isHealthy && w.ConsecutiveFailures == 0 {
		fmt.Println("[PASS] Worker healthy.")
	} else {
		fmt.Printf("[FAIL] Worker marked unhealthy unexpectedly. Failures: %d\n", w.ConsecutiveFailures)
	}

	// Case 2: Timeout
	fmt.Println("--- Case 2: Timeout (Delay > 300ms) ---")
	w.HealthClient = &MockClient{Hash: "abc-123", Delay: 400 * time.Millisecond}
	w.PerformHealthCheck(context.Background())
	if w.ConsecutiveFailures == 1 {
		fmt.Printf("[PASS] Timeout detected. Failures: %d\n", w.ConsecutiveFailures)
	} else {
		fmt.Printf("[FAIL] Timeout ignored? Failures: %d\n", w.ConsecutiveFailures)
	}

	// Case 3: Hash Mismatch
	fmt.Println("--- Case 3: Hash Mismatch ---")
	w.HealthClient = &MockClient{Hash: "wrong-hash", Delay: 10 * time.Millisecond}
	w.PerformHealthCheck(context.Background()) // Fail 2
	w.PerformHealthCheck(context.Background()) // Fail 3 -> DEAD

	if w.State == "DEAD" {
		fmt.Printf("[PASS] Worker marked DEAD after 3 failures.\n")
	} else {
		fmt.Printf("[FAIL] Worker state is %s (Expected DEAD). Failures: %d\n", w.State, w.ConsecutiveFailures)
	}
}
