package main

import (
	"fmt"
	"math/rand"
	"time"

	"d/startup-plan/infermesh/go/pkg/chaos"
)

func main() {
	rand.Seed(time.Now().UnixNano())
	fmt.Println("[INFO] TEST: Chaos Engineering Injection Logic")

	target := chaos.NewMockTargetSystem()

	fmt.Println("--- Case 1: Testing Production Configuration (Chaos Disabled) ---")
	// By default or in generic environments, the flag must mathematically prevent injection.
	cfgProduction := chaos.Config{
		EnableChaosAPI: false,
	}

	apiProd := chaos.NewAPI(cfgProduction, target)
	
	errProd := apiProd.TriggerRandomWorkerKill()
	if errProd == chaos.ErrChaosDisabled {
		fmt.Println("[PASS] Production API strictly refused to execute Chaos Logic.")
	} else {
		fmt.Println("[FAIL] API suicidally executed a worker kill command inside a protected environment!")
		return
	}

	fmt.Println("\n--- Case 2: Development/Staging Setup (Chaos Enabled) ---")
	cfgDev := chaos.Config{
		EnableChaosAPI: true,
	}

	apiDev := chaos.NewAPI(cfgDev, target)

	// 2.A Kill a Random GPU
	fmt.Println("\n [INJECTION 1] Target: Physical GPU Pool (Simulating Kernel crashes)")
	fmt.Printf("               Workers Before Execution: %v\n", target.GetActiveWorkers())
	
	errDevKill := apiDev.TriggerRandomWorkerKill()
	
	if errDevKill == nil && len(target.GetActiveWorkers()) == 3 {
		fmt.Println("[PASS] Orchestrator successfully identified and segregated a random cluster node via SIGKILL.")
		fmt.Printf("               Workers Remaining: %v\n", target.GetActiveWorkers())
	} else {
		fmt.Println("[FAIL] Injection command completely ignored by underlying systems.")
		return
	}

	// 2.B Throttle Unix Socket Iterations
	fmt.Println("\n [INJECTION 2] Target: Unix Domain Socket API (Simulating Memory Contention/Disk Thrashing)")
	errSocket := apiDev.TriggerSocketLatency(500)
	
	if errSocket == nil && target.SocketLatency == 500*time.Millisecond {
		fmt.Printf("[PASS] System mathematically degraded IPC mapping by exactly 500ms permanently.\n")
	}

	// 2.C Thunder the Message Queue entirely full
	fmt.Println("\n [INJECTION 3] Target: Dispatch Queue Channels (Simulating API Flood)")
	errSpike := apiDev.TriggerQueueSpike(10000)
	
	if errSpike == nil && target.QueueDepth == 10000 {
		fmt.Printf("[PASS] Queue channel instantly loaded via simulated integer mapping, intentionally triggering 503 load-shed backpressure boundaries.\n")
	}

	// 2.D Disconnect Global AWS Backend storage completely
	fmt.Println("\n [INJECTION 4] Target: Cross-Continent Storage Layer (Simulating us-east-1 S3 Death)")
	errS3 := apiDev.TriggerS3Failure(true)
	
	if errS3 == nil && target.S3Failing {
		fmt.Printf("[PASS] API permanently flagged all background storage network requests to inherently panic, validating 504 Timeout Rescue routing.\n")
	}

	fmt.Println("\n[CONCLUSION] 100% of the simulated catastrophic endpoints integrated perfectly, allowing us to violently shake our architecture securely on demand.")
}
