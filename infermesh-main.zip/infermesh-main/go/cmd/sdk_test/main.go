package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"time"

	"d/startup-plan/infermesh/go/sdk"
)

func main() {
	fmt.Println("[INFO] TEST: Client SDK Auto-Retry & Jitter Logic")

	var requestCount int
	// Define a mock HTTP server simulating a loaded gateway
	mockServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestCount++
		
		// Set Trace Headers
		w.Header().Set("X-Request-Id", fmt.Sprintf("req-trace-uuid-%d", requestCount))
		w.Header().Set("X-Server-Timestamp", "999999999999") // Fast forward offset

		// Route based on query mapping to mock different scenarios
		mode := r.URL.Query().Get("mode")
		
		switch mode {
		case "bad_payload":
			w.WriteHeader(http.StatusBadRequest) // 400
			
		case "auth_fail":
			w.WriteHeader(http.StatusUnauthorized) // 401
			
		case "transient_fail":
			if requestCount < 3 {
				// Simulating 503 load shedding for first two attempts
				w.WriteHeader(http.StatusServiceUnavailable) 
			} else {
				// Recovers on third attempt!
				w.WriteHeader(http.StatusOK)
				resp := sdk.PredictResponse{
					Signal: "BUY",
					Confidence: 0.95,
				}
				json.NewEncoder(w).Encode(resp)
			}
			
		case "rate_limited":
			w.WriteHeader(http.StatusTooManyRequests) // 429 constantly
		}
	}))
	defer mockServer.Close()

	client := sdk.NewClient(sdk.Config{
		Endpoint:   mockServer.URL,
		Token:      "eyJhbG...",
		MaxRetries: 3,
		BaseDelay:  50 * time.Millisecond, // Hyper accelerated for testing
		MaxDelay:   200 * time.Millisecond,
	})

	// Case 1: 400 Bad Request
	fmt.Println("--- Case 1: Bad Request (400) ---")
	requestCount = 0
	client.config.Endpoint = mockServer.URL + "?mode=bad_payload"
	_, err := client.Predict([]float64{1.0})
	if err != nil && requestCount == 1 {
		fmt.Printf("[PASS] Instantly failed fast on Client Bug without retrying -> %v\n", err)
	} else {
		fmt.Printf("[FAIL] Client incorrectly retried a 400 status. Total attempts: %d\n", requestCount)
	}

	// Case 2: 401 Unauthorized
	fmt.Println("--- Case 2: Bad Auth (401) ---")
	requestCount = 0
	client.config.Endpoint = mockServer.URL + "?mode=auth_fail"
	_, err2 := client.Predict([]float64{1.0})
	if err2 != nil && requestCount == 1 {
		fmt.Printf("[PASS] Instantly threw Credential Error without retrying -> %v\n", err2)
	} else {
		fmt.Println("[FAIL] Client retried an explicit Auth drop.")
	}

	// Case 3: 503 Transient Recovery
	fmt.Println("\n--- Case 3: Transient Overload & Exponential Recovery (503 -> 200) ---")
	requestCount = 0
	client.config.Endpoint = mockServer.URL + "?mode=transient_fail"
	resp3, err3 := client.Predict([]float64{1.0})
	
	if err3 == nil && requestCount == 3 {
		fmt.Printf("[PASS] Successfully recovered! Took %d attempts. Answer: %s. Trace: %s\n", 
			requestCount, resp3.Signal, resp3.RequestID)
	} else {
		fmt.Printf("[FAIL] Retry mechanics failed to land success. Error: %v\n", err3)
	}

	// Case 4: 429 Exhaustion
	fmt.Println("\n--- Case 4: Saturated Rate Limit Exhaustion (429) ---")
	requestCount = 0
	client.config.Endpoint = mockServer.URL + "?mode=rate_limited"
	_, err4 := client.Predict([]float64{1.0})
	if requestCount == 4 { // Initial + 3 Retries
		fmt.Printf("[PASS] Gracefully exhausted all jittered backoff attempts! Ended with: %v\n", err4)
	} else {
		fmt.Printf("[FAIL] Expected exactly 4 attempts. Executed: %d\n", requestCount)
	}
}
