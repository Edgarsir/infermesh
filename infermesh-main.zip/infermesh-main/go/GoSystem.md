# Go Coordinator System

1. **Gateway Logic**: Pipeline handling for TLS, Rate Limiting, and Auth (`pkg/gateway`).
2. **Worker Pool**: Core lifecycle management (`pkg/worker/pool.go`, `launcher.go`, `scaler.go`).
3. **Router**: Least-connections load balancing (`pkg/router`).
4. **Health System**: gRPC-based health checks and crash detection (`pkg/worker/health.go`, `watcher.go`).
5. **Artifact Fetcher**: Resumable, streaming S3 downloads (`pkg/artifact`).

## Critical Flows

### 1. Request Lifecycle
Gate -> Pipeline -> Enqueue -> Router -> Worker(Pull) -> Proxy -> C++

### 2. Auto-Scaling
Scaler(QueueDepth) -> Trigger(Up/Down) -> Pool(Add/Remove)

### 3. Healing
Monitor(Interval) -> Detect(Failure/Crash) -> Mark(Dead) -> Replace(Async)
