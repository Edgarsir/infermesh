package proxy

import (
	"context"
	"fmt"
	"time"

	"google.golang.org/grpc"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// RequestProxy manages the lifecycle of a request flowing to C++.
// It wraps the gRPC client logic, deadlines, and error translation.
type RequestProxy struct {}

// Execute makes the call to the worker, handling timeouts logic.
func (p *RequestProxy) Execute(ctx context.Context, w *worker.Worker, payload interface{}) (interface{}, error) {
	// 1. Establish Deadline for gRPC
	// CRITICAL INTEGRATION POINT: Go's gRPC deadline MUST be strictly longer than
	// C++'s internal inference timeout. If C++ aborts at 200ms and Go's deadline
	// is also 200ms, the network connection might close before C++ can send back
	// a structured timeout error response.
	// We assume C++ internal timeout is 200ms, so we give Go 250ms (50ms buffer).
	cppInternalTimeout := 200 * time.Millisecond
	goGrpcDeadline := cppInternalTimeout + (50 * time.Millisecond)

	callCtx, cancel := context.WithTimeout(ctx, goGrpcDeadline)
	defer cancel()

	// 2. Invoke C++ (Mocked gRPC)
	// In reality: client := pb.NewInferenceServiceClient(w.Conn)
	// resp, err := client.Predict(callCtx, payload)
	
	// MOCK Logic
	resp, err := mockGrpcCall(callCtx, w, payload)

	// 3. Handle Result
	if err != nil {
		// 3a. Timeout Logic
		if err == context.DeadlineExceeded || err.Error() == "rpc error: code = DeadlineExceeded" {
			fmt.Printf("[PROXY] Timeout executing on Worker %d. Marking failure.\n", w.ID)
			
			// Mark failure on worker health (As requested)
			// Ideally this is thread-safe or callback driven to avoid direct access
			// w.RecordFailure("timeout") -> Exposed method ideally
			w.ConsecutiveFailures++ 
			
			return nil, fmt.Errorf("upstream timeout from inference worker")
		}
		
		return nil, err
	}

	return resp, nil
}

func mockGrpcCall(ctx context.Context, w *worker.Worker, payload interface{}) (interface{}, error) {
	// Check deadline
	select {
	case <-time.After(50 * time.Millisecond): // Simulate fast inference
		return "success_result", nil
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}
