package proxy

import (
	"context"
	"fmt"
	"sync"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// BatchRequest holds an individual request waiting to be batched.
type BatchRequest struct {
	RequestID string
	Features  []float64
	ResultCh  chan BatchResult
}

// BatchResult wraps the output for an individual request.
type BatchResult struct {
	Signal     string
	Confidence float64
	Error      error
}

// DynamicBatcher groups individual requests into a single tensor payload for the C++ worker.
type DynamicBatcher struct {
	Worker       *worker.Worker
	Proxy        *RequestProxy // Reused for the actual dispatch
	reqChannel   chan BatchRequest
	
	MaxBatchSize int
	MaxWaitMs    int
	
	Adaptive     bool // Flag to enable shrinking window on light traffic
}

func NewDynamicBatcher(w *worker.Worker, maxBatch, maxWaitMs int) *DynamicBatcher {
	b := &DynamicBatcher{
		Worker:       w,
		Proxy:        &RequestProxy{},
		reqChannel:   make(chan BatchRequest, 1000),
		MaxBatchSize: maxBatch,
		MaxWaitMs:    maxWaitMs,
		Adaptive:     true,
	}
	
	// Start the background batching loop
	go b.batchLoop()
	return b
}

// Enqueue adds a request to the batching queue and returns a future (channel).
func (b *DynamicBatcher) Enqueue(reqID string, features []float64) <-chan BatchResult {
	resCh := make(chan BatchResult, 1)
	
	select {
	case b.reqChannel <- BatchRequest{RequestID: reqID, Features: features, ResultCh: resCh}:
		// Successfully queued
	default:
		// Queue saturated 
		resCh <- BatchResult{Error: fmt.Errorf("node-level batch queue full")}
	}
	
	return resCh
}

// batchLoop continuously groups incoming requests and dispatches them.
func (b *DynamicBatcher) batchLoop() {
	for {
		// Wait for the FIRST request of the next batch
		firstReq := <-b.reqChannel
		
		batch := []BatchRequest{firstReq}
		
		// Adaptive logic: If traffic is very light (queue is empty after reading firstReq),
		// we shrink the wait time to 0 to avoid artificial penalties.
		// If there are already items waiting in the channel, we use the MaxWait window to gather them.
		waitDuration := time.Duration(b.MaxWaitMs) * time.Millisecond
		if b.Adaptive && len(b.reqChannel) == 0 {
			waitDuration = 1 * time.Millisecond // Shrink window significantly for light traffic
		}

		timeout := time.After(waitDuration)

	GatherLoop:
		for len(batch) < b.MaxBatchSize {
			select {
			case req := <-b.reqChannel:
				batch = append(batch, req)
			case <-timeout:
				break GatherLoop
			}
		}

		// Dispatch the gathered batch
		go b.dispatchBatch(batch)
	}
}

// dispatchBatch flattens the arrays and sends to C++
func (b *DynamicBatcher) dispatchBatch(batch []BatchRequest) {
	fmt.Printf("[BATCHER] Dispatching batch of size %d to Worker %d\n", len(batch), b.Worker.ID)
	
	// Note: In reality, we'd build the PredictBatchRequest Protobuf here:
	// 1. Array of request_ids
	// 2. Flattened array of features [req1_f1, req1_f2, req2_f1, req2_f2]
	// 3. Send over gRPC
	// 4. Parse PredictBatchResponse and map results back to ResultCh

	// Simulating the network call taking ~20ms
	time.Sleep(20 * time.Millisecond)

	// Demultiplexing mock results back to callers
	for i, req := range batch {
		req.ResultCh <- BatchResult{
			Signal:     "BUY",
			Confidence: 0.99 - (float64(i) * 0.01), // mock varying confidence
			Error:      nil,
		}
	}
}
