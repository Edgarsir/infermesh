package webhook

import (
	"encoding/json"
	"fmt"
	"strings"
)

// DeploymentEvent represents the parsed information needed for deployment.
type DeploymentEvent struct {
	RepoName     string
	Branch       string
	ModelVersion string
	Environment  string // e.g. "production", "staging"
}

// GitHubPushPayload (Simplified) matching GitHub's webhook structure.
type GitHubPushPayload struct {
	Ref        string `json:"ref"`
	Repository struct {
		Name string `json:"name"`
	} `json:"repository"`
	HeadCommit struct {
		Message string `json:"message"` // e.g. "Deploy model v2.1 to prod"
	} `json:"head_commit"`
}

// ParsePayload extracts deployment metadata from the raw JSON bytes.
// It applies business rules: only "main" branch, specific commit message format.
func ParsePayload(body []byte) (*DeploymentEvent, error) {
	var payload GitHubPushPayload
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil, fmt.Errorf("invalid json: %w", err)
	}

	// 1. Branch Check (Only deploy main)
	if payload.Ref != "refs/heads/main" {
		return nil, fmt.Errorf("ignoring push to non-main branch: %s", payload.Ref)
	}

	// 2. Extract Deployment Metadata from Commit Message
	// Convention: "Deploy model <version> to <env>"
	// Example: "Deploy model v1.5.0 to production"
	msg := payload.HeadCommit.Message
	version, env := extractDeployInfo(msg)
	
	if version == "" {
		return nil, fmt.Errorf("no deployment instruction found in commit message")
	}

	return &DeploymentEvent{
		RepoName:     payload.Repository.Name,
		Branch:       "main",
		ModelVersion: version,
		Environment:  env,
	}, nil
}

// extractDeployInfo parses commit messages for deployment commands.
// Returns (version, env) or empty strings.
func extractDeployInfo(message string) (string, string) {
	// Simple keyword parsing for prototype
	// Ideally use regex: `Deploy model (v[\d\.]+) to (\w+)`
	lowerMsg := strings.ToLower(message)
	if !strings.Contains(lowerMsg, "deploy model") {
		return "", ""
	}

	parts := strings.Fields(message)
	// Expecting: [Deploy, model, v1.0, to, production]
	// Very naive implementation for demonstration
	for i, word := range parts {
		if strings.ToLower(word) == "model" && i+1 < len(parts) {
			version := parts[i+1]
			env := "staging" // Default
			
			// Look for "to <env>"
			if i+3 < len(parts) && strings.ToLower(parts[i+2]) == "to" {
				env = parts[i+3]
			}
			return version, env
		}
	}
	return "", ""
}
