package webhook

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
)

// WebhookHandler encapsulates logic for validating and parsing CI/CD webhooks.
type WebhookHandler struct {
	SecretKey []byte
}

func NewWebhookHandler(secret string) *WebhookHandler {
	return &WebhookHandler{
		SecretKey: []byte(secret),
	}
}

// HandlerFunc implements http.HandlerFunc
func (h *WebhookHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// 1. Read Payload
	payload, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Error reading body", http.StatusInternalServerError)
		return
	}

	// 2. Extract Signature
	signature := r.Header.Get("X-Hub-Signature-256")
	if signature == "" {
		http.Error(w, "Missing signature header", http.StatusUnauthorized)
		return
	}

	// 3. Verify Signature
	if ok, err := h.ValidateSignature(payload, signature); !ok || err != nil {
		fmt.Printf("[WEBHOOK] Invalid signature from %s: %v\n", r.RemoteAddr, err)
		http.Error(w, "Invalid signature", http.StatusUnauthorized)
		return
	}

	// 4. Process Event (Mock: Just log success)
	fmt.Println("[WEBHOOK] Valid payload received. Triggering deployment pipeline...")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Deployment Triggered"))
}

// ValidateSignature performs HMAC-SHA256 verification using constant time comparison.
func (h *WebhookHandler) ValidateSignature(payload []byte, signatureHeader string) (bool, error) {
	// Header format: sha256=<hex_digest>
	parts := strings.SplitN(signatureHeader, "=", 2)
	if len(parts) != 2 || parts[0] != "sha256" {
		return false, errors.New("invalid signature format")
	}

	expectedMAC := h.ComputeHMAC(payload)
	providedMAC, err := hex.DecodeString(parts[1])
	if err != nil {
		return false, fmt.Errorf("hex decode error: %w", err)
	}

	// Constant Time Compare
	// This prevents timing attacks by always checking all bytes.
	return hmac.Equal(expectedMAC, providedMAC), nil
}

func (h *WebhookHandler) ComputeHMAC(message []byte) []byte {
	mac := hmac.New(sha256.New, h.SecretKey)
	mac.Write(message)
	return mac.Sum(nil)
}
