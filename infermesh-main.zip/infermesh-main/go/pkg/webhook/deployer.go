package webhook

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// DeployManager handles the asynchronous execution of deployment jobs.
// It enforces ordering: 1 Active, 1 Pending (Latest only).
type DeployManager struct {
	// Channels
	jobQueue chan *DeploymentEvent
	
	// Locks for queue management
	mu sync.Mutex
	
	// Active status
	isDeploying bool
}

func NewDeployManager() *DeployManager {
	dm := &DeployManager{
		// Buffered channel of size 1 allows "1 pending" slot.
		jobQueue: make(chan *DeploymentEvent, 1),
	}
	
	// Start the worker loop immediately
	go dm.processLoop()
	return dm
}

// QueueDeployment handles incoming requests.
// Returns true if queued or started, false if dropped (but technically irrelevant to GitHub).
func (dm *DeployManager) QueueDeployment(event *DeploymentEvent) {
	dm.mu.Lock()
	defer dm.mu.Unlock()

	// Logic:
	// If channel is full, drain it (drop old pending job) and push new one.
	// This ensures we always have the LATEST pending deployment.
	
	select {
	case dm.jobQueue <- event:
		fmt.Printf("[DEPLOY] Queued deployment for %s\n", event.ModelVersion)
	default:
		// Queue is full. Drain old item.
		old := <-dm.jobQueue
		fmt.Printf("[DEPLOY] Dropped pending deployment %s in favor of %s\n", old.ModelVersion, event.ModelVersion)
		
		// Push new one
		dm.jobQueue <- event
	}
}

// processLoop runs in background, executing jobs one by one.
func (dm *DeployManager) processLoop() {
	for event := range dm.jobQueue {
		dm.executeDeployment(event)
	}
}

// executeDeployment is the heavy lifting function (Downloads, Verifies, Swaps).
func (dm *DeployManager) executeDeployment(event *DeploymentEvent) {
	fmt.Printf("[DEPLOY] STARTING deployment: %s to %s\n", event.ModelVersion, event.Environment)
	
	// Simulate long running process (Download -> Verify -> Swap)
	time.Sleep(100 * time.Millisecond) 
	
	fmt.Printf("[DEPLOY] COMPLETED deployment: %s\n", event.ModelVersion)
}
