package deployment

import (
	"fmt"

	"d/startup-plan/infermesh/go/pkg/registry"
)

// TransactionManager coordinates Registry updates and File swaps.
type TransactionManager struct {
	Registry *registry.Registry
	Swapper  *ModelSwapper
}

// DeployAtomic orchestrates the Safe Deployment Transaction.
func (tm *TransactionManager) DeployAtomic(newConfig registry.TenantConfig, stagingPath, currentPath string) error {
	// 1. Snapshot Old Registry State (For Rollback)
	oldConfig := tm.Registry.GetTenant(newConfig.TenantID)
	
	if oldConfig == nil {
		// New Tenant? Just create.
		// If fails later, we can delete.
	} else {
		// Copy strictly
		fmt.Printf("[DEPLOY] Snapshotting old config (Ver: %s)\n", oldConfig.ModelVersion)
	}

	// 2. Update Registry FIRST (Optimistic)
	// Why first? Because if swap happens and registry update fails, 
	// workers might load new model file but validate against OLD hash -> Crash loop.
	// Updating registry first means they expect NEW hash. If they load OLD file (race), 
	// hash check fails -> they restart -> eventually file swap happens.
	// This is safer than the reverse.
	
	tm.Registry.UpdateTenant(newConfig)
	fmt.Printf("[DEPLOY] Registry updated to %s (Hash: %s)\n", newConfig.ModelVersion, newConfig.ModelHash)

	// 3. Perform Atomic File Swap
	if err := tm.Swapper.Swap(stagingPath, currentPath); err != nil {
		// CRITICAL FAILURE: File swap failed.
		// ROLLBACK REGISTRY immediately.
		fmt.Printf("[DEPLOY] File swap failed! Rolling back registry.\n")
		
		if oldConfig != nil {
			tm.Registry.UpdateTenant(*oldConfig)
		} else {
			tm.Registry.RemoveTenant(newConfig.TenantID)
		}
		
		return fmt.Errorf("deployment transaction failed: %w", err)
	}

	fmt.Println("[DEPLOY] Transaction Committed Successfully.")
	return nil
}
