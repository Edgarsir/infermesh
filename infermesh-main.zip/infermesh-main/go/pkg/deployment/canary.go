package deployment

import (
	"errors"
	"fmt"
	"math"
	"sort"
	"sync"
	"time"
)

var (
	ErrPerformanceRegression = errors.New("performance regression detected: canary latency exceeds baseline threshold")
)

// LatencyTracker records request durations for a specific version.
type LatencyTracker struct {
	mu           sync.RWMutex
	measurements []time.Duration
	maxSamples   int
}

func NewLatencyTracker(maxSamples int) *LatencyTracker {
	return &LatencyTracker{
		measurements: make([]time.Duration, 0, maxSamples),
		maxSamples:   maxSamples,
	}
}

func (lt *LatencyTracker) Record(d time.Duration) {
	lt.mu.Lock()
	defer lt.mu.Unlock()
	
	if len(lt.measurements) >= lt.maxSamples {
		// Simple ring buffer logic or just reset for a new window
		// Given canary windows are short, we'll just keep the latest maxSamples
		lt.measurements = lt.measurements[1:]
	}
	lt.measurements = append(lt.measurements, d)
}

func (lt *LatencyTracker) P99() time.Duration {
	lt.mu.RLock()
	defer lt.mu.RUnlock()
	
	n := len(lt.measurements)
	if n == 0 {
		return 0
	}
	
	// Clone to sort
	sorted := make([]time.Duration, n)
	copy(sorted, lt.measurements)
	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i] < sorted[j]
	})
	
	idx := int(math.Ceil(float64(n)*0.99)) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= n {
		idx = n - 1
	}
	return sorted[idx]
}

// CanaryDeployment oversees the rollout of a new model version, monitoring for accuracy and latency regressions.
type CanaryDeployment struct {
	TenantID            string
	BaselineVersion     string
	CanaryVersion       string
	
	BaselineTracker     *LatencyTracker
	CanaryTracker       *LatencyTracker
	
	LatencyThresholdPct float64 // e.g., 20.0 for 20% degradation allowed
	MinSamples          int     // Minimum requests before evaluating
	
	OverrideToken       string  // Token to acknowledge and bypass regression
}

func NewCanaryDeployment(tenantID, v1, v2 string, thresholdPct float64, minSamples int, override string) *CanaryDeployment {
	return &CanaryDeployment{
		TenantID:            tenantID,
		BaselineVersion:     v1,
		CanaryVersion:       v2,
		BaselineTracker:     NewLatencyTracker(1000),
		CanaryTracker:       NewLatencyTracker(1000),
		LatencyThresholdPct: thresholdPct,
		MinSamples:          minSamples,
		OverrideToken:       override,
	}
}

// Evaluate checks if the canary is performing within the acceptable latency threshold relative to the baseline.
// It returns an error if a performance regression is detected, halting the deployment.
func (cd *CanaryDeployment) Evaluate(overrideToken string) error {
	baselineP99 := cd.BaselineTracker.P99()
	canaryP99 := cd.CanaryTracker.P99()

	// Need enough samples to make a statistically sound decision
	cd.BaselineTracker.mu.RLock()
	bLen := len(cd.BaselineTracker.measurements)
	cd.BaselineTracker.mu.RUnlock()
	
	cd.CanaryTracker.mu.RLock()
	cLen := len(cd.CanaryTracker.measurements)
	cd.CanaryTracker.mu.RUnlock()

	if bLen < cd.MinSamples || cLen < cd.MinSamples {
		// Not enough data yet, allow it to continue gathering
		return nil
	}

	// Calculate percentage degradation
	// e.g. Baseline = 100ms, Canary = 130ms -> (130-100)/100 = 30% degradation
	var degradation float64
	if baselineP99 > 0 {
		degradation = float64(canaryP99-baselineP99) / float64(baselineP99) * 100.0
	}

	if degradation > cd.LatencyThresholdPct {
		// A regression is detected!
		if overrideToken == cd.OverrideToken && overrideToken != "" {
			fmt.Printf("[CANARY] ⚠️ Performance Regression OVERRIDDEN for %s (V2 vs V1: +%.2f%%). Operator accepted latency hit.\n", cd.TenantID, degradation)
			return nil
		}
		
		fmt.Printf("[CANARY] 🚨 PERFORMANCE REGRESSION DETECTED on %s! Canary p99: %v, Baseline p99: %v (+%.2f%% degradation).\n", 
			cd.TenantID, canaryP99, baselineP99, degradation)
		fmt.Printf("         Rollout HALTED mathematically to protect SLA.\n")
		return ErrPerformanceRegression
	}

	fmt.Printf("[CANARY] Performance is healthy for %s (Degradation: %.2f%% <= %.2f%%). Continuing rollout...\n", cd.TenantID, degradation, cd.LatencyThresholdPct)
	return nil
}
