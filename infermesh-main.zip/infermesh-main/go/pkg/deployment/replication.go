package deployment

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// Region simulates a distinct geographical data center presence (e.g., us-east-1, eu-west-1).
type Region struct {
	Name string
}

// ArtifactStorage abstracts the cross-region file system (like AWS S3 Cross-Region Replication or custom grpc blobs).
type ArtifactStorage interface {
	CopyArtifact(ctx context.Context, modelVersion string, sourceRegion, destRegion Region) error
	CheckArtifactPresent(modelVersion string, region Region) bool
}

// MockS3 implements the ArtifactStorage interface for testing
type MockS3 struct {
	mu        sync.RWMutex
	// map of RegionName -> Set of modelVersions
	artifacts map[string]map[string]bool
}

func NewMockS3() *MockS3 {
	return &MockS3{
		artifacts: make(map[string]map[string]bool),
	}
}

func (s *MockS3) SeedArtifact(modelVersion string, region Region) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.artifacts[region.Name] == nil {
		s.artifacts[region.Name] = make(map[string]bool)
	}
	s.artifacts[region.Name][modelVersion] = true
}

func (s *MockS3) CopyArtifact(ctx context.Context, modelVersion string, sourceRegion, destRegion Region) error {
	s.mu.RLock()
	hasSource := s.artifacts[sourceRegion.Name][modelVersion]
	s.mu.RUnlock()

	if !hasSource {
		return fmt.Errorf("artifact %s not found in source region %s", modelVersion, sourceRegion.Name)
	}

	// Simulate heavy 10GB network transfer latency across continents
	select {
	case <-time.After(2 * time.Second): // Network transfer time
	case <-ctx.Done():
		return ctx.Err()
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	if s.artifacts[destRegion.Name] == nil {
		s.artifacts[destRegion.Name] = make(map[string]bool)
	}
	s.artifacts[destRegion.Name][modelVersion] = true
	fmt.Printf("[NETWORK] Successfully transferred 10GB artifact '%s' from %s -> %s\n", modelVersion, sourceRegion.Name, destRegion.Name)
	return nil
}

func (s *MockS3) CheckArtifactPresent(modelVersion string, region Region) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if s.artifacts[region.Name] == nil {
		return false
	}
	return s.artifacts[region.Name][modelVersion]
}

// AsyncReplicator ensures that Secondary regions securely mirror the Primary's mathematical tensors 
// continuously in the background to achieve zero-download Failovers when a region dies.
type AsyncReplicator struct {
	PrimaryRegion    Region
	SecondaryRegions []Region
	Storage          ArtifactStorage
	wg               sync.WaitGroup
}

func NewAsyncReplicator(primary Region, secondaries []Region, storage ArtifactStorage) *AsyncReplicator {
	return &AsyncReplicator{
		PrimaryRegion:    primary,
		SecondaryRegions: secondaries,
		Storage:          storage,
	}
}

// TriggerReplication is called dynamically by the Orchestrator IMMEDIATELY after deploying a new artifact in the Primary.
// It fires async cross-continent transfers natively without blocking the active HTTP Router threads.
func (ar *AsyncReplicator) TriggerReplication(modelVersion string) {
	fmt.Printf("[REPLICATOR] Primary '%s' deployed %s. Initiating Async Replication to %d secondary arrays...\n", 
		ar.PrimaryRegion.Name, modelVersion, len(ar.SecondaryRegions))

	for _, secRegion := range ar.SecondaryRegions {
		ar.wg.Add(1)
		go func(dest Region) {
			defer ar.wg.Done()
			
			// Background context without a timeout (could take minutes for a huge model)
			ctx := context.Background()
			
			err := ar.Storage.CopyArtifact(ctx, modelVersion, ar.PrimaryRegion, dest)
			if err != nil {
				fmt.Printf("[ALERT] Cross-Region Replication Failed for %s -> %s: %v\n", ar.PrimaryRegion.Name, dest.Name, err)
				// In reality, this would trigger an infinite retry queue backed by Kafka/RabbitMQ
			} else {
				fmt.Printf("[REPLICATOR] Warm Standby achieved in Region: '%s' for model '%s'. Cold-Boot Failovers securely avoided!\n", dest.Name, modelVersion)
			}
		}(secRegion)
	}
}

// Wait blocks until all async transfers finish (useful for graceful shutdown or tests)
func (ar *AsyncReplicator) Wait() {
	ar.wg.Wait()
}
