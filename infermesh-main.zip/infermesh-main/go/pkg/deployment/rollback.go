package deployment

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// RollbackPolicy defines the operating mode for triggering rollbacks.
type RollbackPolicy int

const (
	PolicyManualOnly RollbackPolicy = iota
	PolicyAutomatic
)

// RollbackManager handles emergency reversion to the previously deployed state.
type RollbackManager struct {
	Swapper *ModelSwapper
	Pool    *worker.Pool
	Policy  RollbackPolicy
	Metrics MetricProvider
}

func NewRollbackManager(s *ModelSwapper, p *worker.Pool, pol RollbackPolicy, m MetricProvider) *RollbackManager {
	return &RollbackManager{
		Swapper: s,
		Pool:    p,
		Policy:  pol,
		Metrics: m,
	}
}

// TriggerRollback performs the atomic switch: current -> discard, previous -> current.
// It relies on workers dynamically reloading or being gracefully restarted.
func (rm *RollbackManager) TriggerRollback(baseDir string, tenantID string) error {
	currentDir := filepath.Join(baseDir, "current")
	previousDir := filepath.Join(baseDir, "previous")
	discardDir := filepath.Join(baseDir, fmt.Sprintf("discarded_%d", time.Now().Unix()))

	fmt.Printf("[ROLLBACK] Initiating rollback for tenant %s...\n", tenantID)

	// 1. Verify 'previous' exists
	if _, err := os.Stat(previousDir); os.IsNotExist(err) {
		return fmt.Errorf("rollback failed: no previous model found at %s", previousDir)
	}

	// 2. Critical Section lock (Acquire from swapper conceptually)
	if err := rm.Swapper.Lock.Acquire(); err != nil {
		return err
	}
	defer rm.Swapper.Lock.Release()

	// 3. Move 'current' out of the way (Atomic rename)
	if _, err := os.Stat(currentDir); err == nil {
		if renErr := os.Rename(currentDir, discardDir); renErr != nil {
			return fmt.Errorf("rollback failed to quarantine current model: %w", renErr)
		}
	}

	// 4. Promote 'previous' -> 'current'
	if renErr := os.Rename(previousDir, currentDir); renErr != nil {
		// Panic state: We moved current out, but failed to put previous in. 
		// Try extremely aggressive undo.
		os.Rename(discardDir, currentDir)
		return fmt.Errorf("critical rollback failure during promote: %w", renErr)
	}

	fmt.Println("[ROLLBACK] File system successfully reverted.")

	// 5. Restart Workers
	// Go must instruct the C++ workers handling this tenant to restart and reload the model.
	// We iterate the pool and gracefully drain or hard-kill.
	// For simulation, we log the restart command.
	rm.RestartTenantWorkers(tenantID)

	fmt.Printf("[ROLLBACK] Reversion complete for %s.\n", tenantID)
	return nil
}

// RestartTenantWorkers triggers a rolling restart or immediate kill of worker processes.
func (rm *RollbackManager) RestartTenantWorkers(tenantID string) {
	fmt.Printf("[ROLLBACK] Restarting all workers for %s to force model reload...\n", tenantID)
	// Example logical loop:
	// for _, w := range rm.Pool.Workers {
	//    if w.TenantID == tenantID {
	//        rm.Pool.KillWorker(w.ID)
	//        // ProcessWatcher auto-recovers it with the reverted 'current' model.
	//    }
	// }
}

// MonitorAutoRollback is a background loop that watches for catastrophic thresholds
// if the Policy is Automatic.
func (rm *RollbackManager) MonitorAutoRollback(baseDir, tenantID, currentVersion string) {
	if rm.Policy != PolicyAutomatic {
		return
	}

	// Simplistic threshold logic
	errorThreshold := 0.20 // 20% errors across 5 minutes
	
	for {
		time.Sleep(10 * time.Second) // Check interval
		
		errRate := rm.Metrics.GetErrorRate(tenantID, currentVersion)
		if errRate > errorThreshold {
			fmt.Printf("[AUTO-ROLLBACK] Error rate %.2f%% exceeded threshold! Triggering emergency rollback.\n", errRate*100)
			
			if err := rm.TriggerRollback(baseDir, tenantID); err != nil {
				fmt.Printf("[CRITICAL] Auto-rollback failed: %v\n", err)
			}
			return // Stop monitoring this version
		}
	}
}
