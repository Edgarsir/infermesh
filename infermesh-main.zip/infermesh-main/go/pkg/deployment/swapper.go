package deployment

import (
	"fmt"
	"os"
)

// DistributedLock abstracts the locking mechanism (Redis, Etcd, FileLock).
type DistributedLock interface {
	Acquire() error
	Release() error
}

// ModelSwapper handles the atomic promotion of model artifacts.
type ModelSwapper struct {
	Lock DistributedLock
}

// Swap promotes stagingPath to currentPath safely.
// It backs up the existing currentPath, moves staging, and then cleans up.
func (s *ModelSwapper) Swap(stagingPath, currentPath string) error {
	// 1. Critical Section Start
	if err := s.Lock.Acquire(); err != nil {
		return fmt.Errorf("failed to acquire lock: %w", err)
	}
	defer s.Lock.Release()

	// 2. Validate Inputs
	if _, err := os.Stat(stagingPath); os.IsNotExist(err) {
		return fmt.Errorf("staging deployment not found at %s", stagingPath)
	}

	// 3. Backup Existing Deployment (if any)
	// We rename 'current' -> 'current.old'
	// Note: On Linux os.Rename is atomic replacement. On Windows it fails if dest exists.
	// We use the safer Backup-Rename pattern for cross-platform robustness and rollback capability.
	backupPath := currentPath + ".old"
	hasCurrent := false
	
	if _, err := os.Stat(currentPath); err == nil {
		hasCurrent = true
		// Ensure any previous junk backup is gone
		os.RemoveAll(backupPath)
		
		fmt.Printf("[SWAP] Backing up current -> %s\n", backupPath)
		if err := os.Rename(currentPath, backupPath); err != nil {
			return fmt.Errorf("failed to backup current deployment: %w", err)
		}
	}

	// 4. Perform Swap (Staging -> Current)
	fmt.Printf("[SWAP] Promoting %s -> %s\n", stagingPath, currentPath)
	if err := os.Rename(stagingPath, currentPath); err != nil {
		// ROLLBACK
		fmt.Printf("[SWAP] FAILED! Rolling back...\n")
		if hasCurrent {
			os.Rename(backupPath, currentPath) // Best effort restore
		}
		return fmt.Errorf("swap failed: %w", err)
	}

	// 5. Persist Previous Version (For Rollback)
	// Instead of deleting the backup, we keep it as the strict 'previous' fallback.
	if hasCurrent {
		previousPath := currentPath[:len(currentPath)-len("current")] + "previous" 
		
		fmt.Printf("[SWAP] Keeping previous version for fast rollback at: %s\n", previousPath)
		
		// Remove any existing 'previous'
		os.RemoveAll(previousPath)
		
		if err := os.Rename(backupPath, previousPath); err != nil {
			fmt.Printf("[WARN] Failed to persist previous rollback state: %v\n", err)
		}
	}

	return nil
}
