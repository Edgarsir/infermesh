package deployment

import (
	"fmt"
	"strings"
	"time"
)

// Manifest represents the atomic pairing of required infrastructure dependencies.
// A model cannot exist independently of its compiled mathematical boundaries.
type Manifest struct {
	ModelVersion      string `json:"model_version"`
	RequiredCppBinary string `json:"required_cpp_binary_version"` // Minimum or explicit version "v2.0"
}

// Environment defines the components managed by the Orchestrator.
type Environment interface {
	GetCurrentCppVersion() string
	DeployCppBinary(targetVersion string) error
	WaitForWorkerHealthy() bool
	DeployModelWeights(targetVersion string) error
}

// Orchestrator safely schedules and executes deployment DAGs based on topological dependencies.
type Orchestrator struct {
	env Environment
}

func NewOrchestrator(env Environment) *Orchestrator {
	return &Orchestrator{env: env}
}

// ExecuteDeployment applies the rules of deterministic dependency resolution.
func (o *Orchestrator) ExecuteDeployment(manifest Manifest) error {
	fmt.Printf("[DEPLOYMENT] Received manifest for Model %s (Requires C++ Engine >= %s)\n", manifest.ModelVersion, manifest.RequiredCppBinary)

	currentCpp := o.env.GetCurrentCppVersion()
	
	// Phase 1: Dependency Check
	if !o.isCppVersionCompatible(currentCpp, manifest.RequiredCppBinary) {
		fmt.Printf("   -> Dependency Mismatch: Current Engine %s < Required Engine %s\n", currentCpp, manifest.RequiredCppBinary)
		
		fmt.Println("   -> [STEP 1] Suspending Traffic and Deploying new C++ Binary...")
		if err := o.env.DeployCppBinary(manifest.RequiredCppBinary); err != nil {
			return fmt.Errorf("failed C++ deployment: %w", err)
		}

		fmt.Println("   -> [STEP 2] Waiting for GPUs to restart and pass health checks...")
		if !o.env.WaitForWorkerHealthy() {
			return fmt.Errorf("infrastructure deployment failed! C++ binary %s crashed on launch. Reverting...", manifest.RequiredCppBinary)
		}
		
		fmt.Printf("   -> Engine successfully upgraded to %s.\n", manifest.RequiredCppBinary)
		
	} else {
		fmt.Printf("   -> Engine dependency met (Current %s >= Required %s). Proceeding directly to model swap.\n", currentCpp, manifest.RequiredCppBinary)
	}

	// Phase 2: Atomic Deployment of Data Weights
	fmt.Printf("   -> [STEP 3] Hot-swapping atomic Tensor Weights across active GPU pool (Model %s)...\n", manifest.ModelVersion)
	if err := o.env.DeployModelWeights(manifest.ModelVersion); err != nil {
		return fmt.Errorf("failed model weights deployment: %w", err)
	}

	fmt.Println("[DEPLOYMENT] Successful completion of dependency graph!")
	return nil
}

// Mock version comparison (e.g. "v1.0" < "v2.0")
func (o *Orchestrator) isCppVersionCompatible(current, required string) bool {
	// Stripping "v" for basic lexical numeric comparison.
	// In reality this would use Hashicorp go-version.
	c := strings.TrimPrefix(current, "v")
	r := strings.TrimPrefix(required, "v")
	return c >= r 
}
