package deployment

import (
	"errors"
	"fmt"
	"sync"
)

var (
	ErrLockNotAcquired      = errors.New("failed to acquire distributed lock")
	ErrFencingTokenRejected = errors.New("fencing token rejected: stale operation from dethroned primary")
)

// FencingLockManager abstracts a consensus system like etcd or ZooKeeper.
// Instead of a simple boolean lock, it returns a monotonically increasing token.
type FencingLockManager interface {
	// AcquireLock attempts to gain primary status and returns a unique fencing token.
	AcquireLock(resourceID string, holderID string) (int64, error)
	// ReleaseLock releases the lock for a given resource.
	ReleaseLock(resourceID string, holderID string)
}

// MockConsensusStore simulates a centralized strongly consistent store (like etcd).
type MockConsensusStore struct {
	mu           sync.Mutex
	currentToken int64
	lockHolder   string
}

func NewMockConsensusStore() *MockConsensusStore {
	return &MockConsensusStore{}
}

func (s *MockConsensusStore) AcquireLock(resourceID string, holderID string) (int64, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// In a real system (like etcd leases or Redlock), locks expire if the holder dies.
	// For this mock, we allow someone to aggressively steal the lock to simulate
	// a network partition where the consensus system grants the lock to a new node
	// because it can't reach the old node.

	s.currentToken++
	s.lockHolder = holderID
	fmt.Printf("[CONSENSUS] Granted Lock to %s with Fencing Token: %d\n", holderID, s.currentToken)
	return s.currentToken, nil
}

func (s *MockConsensusStore) ReleaseLock(resourceID string, holderID string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.lockHolder == holderID {
		s.lockHolder = ""
	}
}

// StatefulResource represents the actual infrastructure being mutated (e.g., swapping a model).
// It maintains the highest fencing token it has ever seen to reject stale writes.
type StatefulResource struct {
	mu           sync.Mutex
	highestToken int64
	State        string // The actual model version deployed, etc.
}

func NewStatefulResource() *StatefulResource {
	return &StatefulResource{
		highestToken: 0,
	}
}

// ApplyOperation performs the critical mutation, but ONLY if the token is valid.
func (r *StatefulResource) ApplyOperation(token int64, requesterID string, newState string) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	if token < r.highestToken {
		fmt.Printf("[RESOURCE] 🚨 REJECTED write from %s! Token %d is stale. Current highest is %d.\n", requesterID, token, r.highestToken)
		return ErrFencingTokenRejected
	}

	fmt.Printf("[RESOURCE] ACCEPTED write from %s. Token %d >= %d. State mutating to '%s'.\n", requesterID, token, r.highestToken, newState)
	r.highestToken = token
	r.State = newState
	return nil
}
