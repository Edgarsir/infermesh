package deployment

import (
	"errors"
	"fmt"
	"sync"
	"time"
)

var (
	ErrDeploymentFrozen = errors.New("deployment rejected: currently within a scheduled freeze block")
	ErrInvalidBypass    = errors.New("emergency bypass token is missing or invalid")
)

// DayOfWeek wrapper so users don't need to import time everywhere in config strings
type DayOfWeek time.Weekday

// FreezeWindow defines a recurring weekly period where no codebase/model modifications are logically permitted.
type FreezeWindow struct {
	Day       time.Weekday
	StartTime time.Time // Uses hour/minute bounded strictly (e.g. 08:00 AM)
	EndTime   time.Time // Uses hour/minute bounded strictly (e.g. 10:00 AM)
	Timezone  *time.Location
}

// TenantDeploymentConfig tracks geographical constraints and strict administrative overrides.
type TenantDeploymentConfig struct {
	FreezeWindows  []FreezeWindow
	EmergencyToken string // Explicit SHA-256 or secure UUID to override the block
}

// FreezeManager validates if a tenant is legally permitted to execute a Model/C++ release.
type FreezeManager struct {
	mu      sync.RWMutex
	tenants map[string]TenantDeploymentConfig
}

func NewFreezeManager() *FreezeManager {
	return &FreezeManager{
		tenants: make(map[string]TenantDeploymentConfig),
	}
}

// SetTenantPolicy provisions a schedule, defining e.g. "Tokyo Open" block vs "London Open" block.
func (fm *FreezeManager) SetTenantPolicy(tenantID string, cfg TenantDeploymentConfig) {
	fm.mu.Lock()
	defer fm.mu.Unlock()
	fm.tenants[tenantID] = cfg
}

// EvaluateDeployment checks the strict server clock against the timezone-aware bounds of the specific tenant.
func (fm *FreezeManager) EvaluateDeployment(tenantID string, bypassToken string, simulatedTime *time.Time) error {
	fm.mu.RLock()
	cfg, exists := fm.tenants[tenantID]
	fm.mu.RUnlock()

	// If no tenant config exists, they have zero active freezes. Deployments pass natively.
	if !exists {
		return nil
	}

	var now time.Time
	if simulatedTime != nil {
		now = *simulatedTime
	} else {
		now = time.Now()
	}

	// 1. Is there an active block right now?
	isFrozen := false
	var activeReason string

	for _, window := range cfg.FreezeWindows {
		// Convert current machine time to the designated localized time of the Tenant
		localTime := now.In(window.Timezone)

		// Evaluates recurring bounds
		if localTime.Weekday() == window.Day {
			// Extract just the Hour/Minute scalar into a daily delta representing total elapsed seconds
			currentSeconds := localTime.Hour()*3600 + localTime.Minute()*60 + localTime.Second()
			startSeconds := window.StartTime.Hour()*3600 + window.StartTime.Minute()*60
			endSeconds := window.EndTime.Hour()*3600 + window.EndTime.Minute()*60

			if currentSeconds >= startSeconds && currentSeconds <= endSeconds {
				isFrozen = true
				activeReason = fmt.Sprintf("%v (%02d:%02d -> %02d:%02d %s)", 
					window.Day, window.StartTime.Hour(), window.StartTime.Minute(), 
					window.EndTime.Hour(), window.EndTime.Minute(), window.Timezone.String())
				break
			}
		}
	}

	// 2. Evaluate Block / Bypass Topology
	if isFrozen {
		// A webhook or CI/CD pushed correctly, but the physical calendar strictly blocks it!
		
		if bypassToken == "" {
			fmt.Printf("[DEPLOYMENT_FREEZE] 🚨 Request severely rejected. Tenant '%s' is in active blackout: %s. Await boundary release.\n", tenantID, activeReason)
			return ErrDeploymentFrozen
		}

		// A human intervened with a critical bypass token
		if bypassToken == cfg.EmergencyToken {
			// This string must pipe to the AuditLogger to log the operator override explicitly
			fmt.Printf("[OVERRIDE] ⚠️ Warning: Emergency Bypass utilized by Tenant '%s' during active blackout: %s. This action is cryptographically attached to the Audit Log.\n", tenantID, activeReason)
			return nil
		} else {
			fmt.Printf("[DEPLOYMENT_FREEZE] 🚨 Request severely rejected. Bypass token invalid!\n")
			return ErrInvalidBypass
		}
	}

	return nil
}
