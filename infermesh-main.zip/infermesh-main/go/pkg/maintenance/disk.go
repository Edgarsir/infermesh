package maintenance

import (
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"sort"
	"time"
)

// DiskManager enforces retention policies and monitors absolute volume health.
type DiskManager struct {
	MaxVersionsAllowed int
	StabilityWindow    time.Duration // Time a version must be idle before it can be deleted
	DataDir            string        // Root directory holding all tenant models
	AlertCh            chan string   // Channel to push disk usage alerts to the operator
}

func NewDiskManager(dataDir string, alertCh chan string) *DiskManager {
	return &DiskManager{
		// E.g., keep 'current', 'previous', and 1 older fallback just in case.
		MaxVersionsAllowed: 3,           
		StabilityWindow:    24 * time.Hour,
		DataDir:            dataDir,
		AlertCh:            alertCh,
	}
}

// CheckCapacity performs a rapid lightweight scan of block device usage.
func (d *DiskManager) CheckCapacity(warningThresholdPercent float64) error {
	// For simulation / cross-platform, we use a mocked struct instead of syscall.Statfs
	usagePct := mockDiskUsage(d.DataDir)
	
	if usagePct > warningThresholdPercent {
		alertMsg := fmt.Sprintf("[DISK_ALERT] Capacity at %.1f%%! Approaching exhaustion.", usagePct)
		
		// Non-blocking alert push
		select {
		case d.AlertCh <- alertMsg:
		default:
			// Alert channel full, log it at least
			fmt.Println(alertMsg)
		}
		
		return fmt.Errorf("volume %s is approaching full capacity (%.1f%%)", d.DataDir, usagePct)
	}
	return nil
}

// CleanupTenant scans a specific tenant's directory, sorting deployed models 
// by modification time, and prunes any that exceed MaxVersionsAllowed AND 
// are older than the StabilityWindow.
func (d *DiskManager) CleanupTenant(tenantID string) error {
	tenantDir := filepath.Join(d.DataDir, tenantID)
	
	// Fast return if directory doesn't exist
	if _, err := os.Stat(tenantDir); os.IsNotExist(err) {
		return nil
	}

	entries, err := ioutil.ReadDir(tenantDir)
	if err != nil {
		return fmt.Errorf("failed to read tenant directory: %w", err)
	}

	// We only care about directories (each version is a dir)
	var versions []os.FileInfo
	for _, entry := range entries {
		if entry.IsDir() {
			// Never delete the strict symbolic-like target paths 'current' or 'previous'
			// during automated pruning unless they are explicitly orphaned.
			if entry.Name() == "current" || entry.Name() == "previous" {
				continue
			}
			versions = append(versions, entry)
		}
	}

	// If we have fewer than limit, nothing to do.
	if len(versions) <= d.MaxVersionsAllowed {
		return nil
	}

	// Sort by modification time (ascending - oldest first)
	sort.Slice(versions, func(i, j int) bool {
		return versions[i].ModTime().Before(versions[j].ModTime())
	})

	// Calculate how many we need to prune
	numToPrune := len(versions) - d.MaxVersionsAllowed
	prunedCount := 0

	now := time.Now()

	for i := 0; i < numToPrune; i++ {
		target := versions[i]
		
		// Stability Window Check: We only delete if it hasn't been touched 
		// (e.g., rolled back to) for the duration of the stability window.
		idleTime := now.Sub(target.ModTime())
		
		if idleTime > d.StabilityWindow {
			targetPath := filepath.Join(tenantDir, target.Name())
			fmt.Printf("[PRUNER] Tenant %s: Deleting old model version %s (Idle %v)\n", 
				tenantID, target.Name(), idleTime)
				
			if err := os.RemoveAll(targetPath); err != nil {
				fmt.Printf("[PRUNER] Error deleting %s: %v\n", targetPath, err)
			} else {
				prunedCount++
			}
		} else {
			fmt.Printf("[PRUNER] Tenant %s: Version %s exceeds count, but still within %v stability window. Skipping.\n", 
				tenantID, target.Name(), d.StabilityWindow)
		}
	}

	fmt.Printf("[PRUNER] Tenant %s: Cleanup finished. Pruned %d stale versions.\n", tenantID, prunedCount)
	return nil
}

// Mock syscall for demonstration
func mockDiskUsage(path string) float64 {
	// In reality: 
	// var stat syscall.Statfs_t
	// syscall.Statfs(path, &stat)
	// return float64(stat.Blocks-stat.Bfree) / float64(stat.Blocks) * 100
	return 85.5 // Simulate 85.5% full
}
