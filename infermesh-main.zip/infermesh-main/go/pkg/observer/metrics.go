package observer

import (
	"fmt"
	"net/http"
	"sync/atomic"
	"bytes"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// MetricsCollector aggregates system state for Prometheus.
type MetricsCollector struct {
	Pool *worker.Pool
	// Global atomic counters for request outcomes
	TotalRequests int64
	TotalErrors   int64
	TotalTimeouts int64
}

func NewCollector(pool *worker.Pool) *MetricsCollector {
	return &MetricsCollector{
		Pool: pool,
	}
}

// ServeMetrics implements the /metrics endpoint.
func (mc *MetricsCollector) ServeMetrics(w http.ResponseWriter, r *http.Request) {
	var buffer bytes.Buffer

	// 1. Global Counters
	reqs := atomic.LoadInt64(&mc.TotalRequests)
	errs := atomic.LoadInt64(&mc.TotalErrors)
	tos := atomic.LoadInt64(&mc.TotalTimeouts)

	buffer.WriteString(fmt.Sprintf("# HELP infermesh_requests_total Total number of requests processed\n"))
	buffer.WriteString(fmt.Sprintf("# TYPE infermesh_requests_total counter\n"))
	buffer.WriteString(fmt.Sprintf("infermesh_requests_total %d\n", reqs))

	buffer.WriteString(fmt.Sprintf("infermesh_errors_total %d\n", errs))
	buffer.WriteString(fmt.Sprintf("infermesh_timeouts_total %d\n", tos))

	// 2. Worker Pool Stats (Directly from control plane state)
	// We iterate workers to expose health and load.
	// NOTE: This iterates a slice under lock ideally, but for metrics typical eventual consistency is OK.
	// Pool.Workers slice changes rarely (scaling events).
	
	// Lock-free read of slice pointer? Or use Pool's mutex.
	// For safety, let's assume we can access Pool.Workers safely or lock it briefly.
	// mc.Pool.Mu.Lock() -> exposed? 
	// For this plan, we iterate directly assuming no concurrent scaling during scrape (or handling panic/race).
	
	workers := mc.Pool.Workers // Copy reference
	if workers == nil {
		w.Write(buffer.Bytes())
		return
	}

	for _, wrk := range workers {
		h := 0
		if wrk.Healthy { h = 1 }
		
		// Labels: worker_id, gpu_index
		buffer.WriteString(fmt.Sprintf("infermesh_worker_up{worker_id=\"%d\"} %d\n", wrk.ID, h))
		buffer.WriteString(fmt.Sprintf("infermesh_worker_failures{worker_id=\"%d\"} %d\n", wrk.ID, wrk.ConsecutiveFailures))
	}

	w.Header().Set("Content-Type", "text/plain")
	w.Write(buffer.Bytes())
}

// RecordRequest increments counters (called by Gateway/Proxy).
func (mc *MetricsCollector) RecordRequest(success bool, timeout bool) {
	atomic.AddInt64(&mc.TotalRequests, 1)
	if !success {
		atomic.AddInt64(&mc.TotalErrors, 1)
	}
	if timeout {
		atomic.AddInt64(&mc.TotalTimeouts, 1)
	}
}
