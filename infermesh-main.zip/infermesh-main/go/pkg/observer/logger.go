package observer

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sync"
	"time"
)

// AccessLogEntry defines the structure of a request log.
type AccessLogEntry struct {
	Timestamp       string  `json:"timestamp"`
	RequestID       string  `json:"request_id"`
	TenantID        string  `json:"tenant_id"`
	WorkerID        int     `json:"worker_id"`
	TotalLatencyMs  int64   `json:"total_latency_ms"`
	InternalLatency int64   `json:"internal_cpp_latency_ms"`
	ResultSignal    string  `json:"result_signal"`
	Confidence      float64 `json:"confidence"`
	Success         bool    `json:"success"`
	Error           string  `json:"error,omitempty"`
}

// AsyncLogger handles non-blocking structured logging.
type AsyncLogger struct {
	logChannel chan AccessLogEntry
	writer     io.Writer
	wg         sync.WaitGroup
}

func NewAsyncLogger(w io.Writer, bufferSize int) *AsyncLogger {
	l := &AsyncLogger{
		logChannel: make(chan AccessLogEntry, bufferSize),
		writer:     w,
	}
	l.wg.Add(1)
	go l.processLoop()
	return l
}

// LogRequest pushes a log entry to the buffer.
// It returns immediately. If buffer is full, it drops the log to preserve latency (optional).
// Or we can block. For an observability system, dropping > blocking request path.
func (l *AsyncLogger) LogRequest(entry AccessLogEntry) {
	select {
	case l.logChannel <- entry:
		// logged
	default:
		// Buffer full - drop log (metric ideally incremented here)
		fmt.Printf("[LOGGER] WARN: Log buffer full. Dropped request %s\n", entry.RequestID)
	}
}

func (l *AsyncLogger) processLoop() {
	defer l.wg.Done()
	encoder := json.NewEncoder(l.writer)

	for entry := range l.logChannel {
		if entry.Timestamp == "" {
			entry.Timestamp = time.Now().UTC().Format(time.RFC3339)
		}
		if err := encoder.Encode(entry); err != nil {
			fmt.Printf("[LOGGER] Error encoding log: %v\n", err)
		}
	}
}

// Close ensures all pending logs are flushed.
func (l *AsyncLogger) Close() {
	close(l.logChannel)
	l.wg.Wait()
}
