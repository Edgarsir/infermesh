package router

import (
	"fmt"
	"sync"
	"time"
)

type CircuitState int

const (
	StateClosed CircuitState = iota // Normal operation
	StateOpen                       // Worker is failing, no traffic allowed
	StateHalfOpen                   // Testing if worker has recovered
)

// CircuitBreaker tracks the health of an individual worker based on real request outcomes,
// rather than simple gRPC ping health checks.
type CircuitBreaker struct {
	mu sync.RWMutex

	State CircuitState

	// Sliding window counters (For simplicity, we use total counters that are reset periodically)
	Failures int64
	Successes int64

	// Settings
	ErrorThresholdRatio float64       // e.g., 0.10 (10%)
	MinRequests         int64         // Minimum requests before calculating ratio (e.g., 10)
	OpenTimeout         time.Duration // Time to wait in Open state before Half-Open (e.g., 30s)

	lastFailureTime time.Time
}

func NewCircuitBreaker(threshold float64, minReqs int64, openTimeout time.Duration) *CircuitBreaker {
	return &CircuitBreaker{
		State:               StateClosed,
		ErrorThresholdRatio: threshold,
		MinRequests:         minReqs,
		OpenTimeout:         openTimeout,
	}
}

// AllowRequest checks if a request should be routed to this worker.
func (cb *CircuitBreaker) AllowRequest() bool {
	cb.mu.RLock()
	state := cb.State
	lastFail := cb.lastFailureTime
	cb.mu.RUnlock()

	switch state {
	case StateClosed:
		return true
	case StateOpen:
		// Check if the timeout has passed to transition to Half-Open
		if time.Since(lastFail) > cb.OpenTimeout {
			cb.mu.Lock()
			// Double-check inside lock
			if cb.State == StateOpen {
				cb.State = StateHalfOpen
				fmt.Println("[CIRCUIT_BREAKER] Threshold timeout elapsed. Transitioning to HALF-OPEN (Testing recovery).")
			}
			cb.mu.Unlock()
			return true // Allow a test request
		}
		return false
	case StateHalfOpen:
		// In Half-Open, we allow a few requests through to test.
		// For simplicity, we just allow the request. The RecordResult will transition the state.
		return true
	}

	return false
}

// RecordResult updates the statistics based on the request outcome.
func (cb *CircuitBreaker) RecordResult(isError bool) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	if isError {
		cb.Failures++
		cb.lastFailureTime = time.Now()
	} else {
		cb.Successes++
	}

	totals := cb.Failures + cb.Successes

	switch cb.State {
	case StateClosed:
		// Check if we reached minimum requests to evaluate
		if totals >= cb.MinRequests {
			errorRate := float64(cb.Failures) / float64(totals)
			if errorRate > cb.ErrorThresholdRatio {
				// Trip the breaker!
				cb.State = StateOpen
				fmt.Printf("[CIRCUIT_BREAKER] TRIPPED! Error rate %.2f%% exceeded threshold. Circuit is OPEN.\n", errorRate*100)
			}
			// Reset window (sliding window approximation)
			cb.resetCounters()
		}

	case StateHalfOpen:
		// The very next request dictates the result in this simple model.
		// If it fails, went right back to open. If success, back to closed.
		if isError {
			cb.State = StateOpen
			fmt.Println("[CIRCUIT_BREAKER] Test request failed. Reverting to OPEN.")
		} else {
			cb.State = StateClosed
			fmt.Println("[CIRCUIT_BREAKER] Test request succeeded! Worker recovered. Circuit CLOSED.")
		}
		cb.resetCounters()
	}
}

// resetCounters resets the sliding window tallies. Assumes lock is held.
func (cb *CircuitBreaker) resetCounters() {
	cb.Failures = 0
	// We might keep an exponentially decayed success count in reality, but for now reset to 0.
	cb.Successes = 0
}
