package router

import (
	"errors"
	"fmt"
	"hash/fnv"
	"sort"
	"sync"
)

// SessionRecoveryPolicy dictates how the router handles the loss of hardware 
// holding the KV Cache or Recurrent Hidden State of a session.
type SessionRecoveryPolicy int

const (
	// PolicyRebuildState seamlessly hashes the session to a new worker.
	// The client is unaware of hardware faults but MUST send the entire context 
	// history to rebuild the GPU state cache from scratch. (Expensive compute).
	PolicyRebuildState SessionRecoveryPolicy = iota 
	
	// PolicyErrorSessionLost explicitly returns an HTTP Error (e.g., HTTP 410 Gone) 
	// forcing the client to explicitly acknowledge the session wipe before starting fresh.
	PolicyErrorSessionLost                          
)

var ErrSessionLost = errors.New("stateful session lost due to worker termination")

// AffinityRouter routes requests based on 'session_id' rather than least-loaded.
// It maps sessions deterministically to specific GPUs to maintain stateful contexts.
type AffinityRouter struct {
	mu              sync.RWMutex
	workerIDs       []string
	recoveryPolicy  SessionRecoveryPolicy
	
	// Maps exactly string sessionID -> string workerID to detect hardware death
	sessionToWorker map[string]string
}

func NewAffinityRouter(policy SessionRecoveryPolicy) *AffinityRouter {
	return &AffinityRouter{
		workerIDs:       make([]string, 0),
		recoveryPolicy:  policy,
		sessionToWorker: make(map[string]string),
	}
}

// UpdateWorkers is called by the Pool Manager whenever GPUs are spawned or reaped.
func (ar *AffinityRouter) UpdateWorkers(workers []string) {
	ar.mu.Lock()
	defer ar.mu.Unlock()
	
	// Create a copy and sort it to ensure deterministic hashing distributions
	copied := make([]string, len(workers))
	copy(copied, workers)
	sort.Strings(copied)
	ar.workerIDs = copied
}

// RouteSession guarantees the exact same GPU worker is selected for sequential requests.
func (ar *AffinityRouter) RouteSession(sessionID string) (string, error) {
	ar.mu.Lock()
	defer ar.mu.Unlock()

	if len(ar.workerIDs) == 0 {
		return "", fmt.Errorf("no active workers available for affinity routing")
	}

	// 1. Check if session is already actively pinned
	if assignedWorker, exists := ar.sessionToWorker[sessionID]; exists {
		// Is the hardware still alive?
		if ar.isWorkerActive(assignedWorker) {
			return assignedWorker, nil // Perfect Hardware Affinity Hit!
		}

		// GPU Crash! Worker process died, state lost from VRAM.
		if ar.recoveryPolicy == PolicyErrorSessionLost {
			// Wipe the tracker so the client can start fresh on their explicit retry
			delete(ar.sessionToWorker, sessionID)
			return "", ErrSessionLost
		}
		
		fmt.Printf("[AFFINITY] Worker '%s' died! Seamlessly migrating Session '%s' to new hardware. (Client must send full context).\n", assignedWorker, sessionID)
		// Fall through to dynamically hash across the remaining live pool
	}

	// 2. Hash sessionID to dynamically pin a new GPU assignment
	h := fnv.New32a()
	h.Write([]byte(sessionID))
	hashVal := h.Sum32()

	index := hashVal % uint32(len(ar.workerIDs))
	selectedWorker := ar.workerIDs[index]

	// Lock the pin
	ar.sessionToWorker[sessionID] = selectedWorker

	return selectedWorker, nil
}

// isWorkerActive checks if a string PID is still in the active pool slice
func (ar *AffinityRouter) isWorkerActive(workerID string) bool {
	for _, id := range ar.workerIDs {
		if id == workerID {
			return true
		}
	}
	return false
}
