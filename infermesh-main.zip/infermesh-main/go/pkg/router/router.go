package router

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// RouterStats tracks load balancing metrics per worker.
type RouterStats struct {
	InFlightRequests int64
	TotalRequests    int64
	LastUsed         int64
}

// Router maintains the map of workers and dispatches requests.
type Router struct {
	pool  *worker.Pool
	stats map[int]*RouterStats // Key: WorkerID
	mu    sync.RWMutex
}

func NewRouter(pool *worker.Pool) *Router {
	return &Router{
		pool:  pool,
		stats: make(map[int]*RouterStats),
	}
}

// SelectWorker implements the Least-Connections algorithm.
func (r *Router) SelectWorker(ctx context.Context, tenantID string) (*worker.Worker, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()

	var bestWorker *worker.Worker
	var minInFlight int64 = -1
	var minTotal int64 = -1

	// Iterate all HEALTHY workers assigned to this tenant
	// Assuming for now all workers serve all tenants (shared pool).
	// In multi-tenant dedicated pools, filtering would happen here.
	for _, w := range r.pool.Workers {
		if !w.Healthy {
			continue
		}

		s := r.getStats(w.ID)
		inFlight := atomic.LoadInt64(&s.InFlightRequests)
		total := atomic.LoadInt64(&s.TotalRequests)

		// 1. Initial Selection
		if bestWorker == nil {
			bestWorker = w
			minInFlight = inFlight
			minTotal = total
			continue
		}

		// 2. Least In-Flight Logic
		if inFlight < minInFlight {
			bestWorker = w
			minInFlight = inFlight
			minTotal = total
		} else if inFlight == minInFlight {
			// 3. Tie-Breaker: Least Total Requests (Load Balancer history)
			if total < minTotal {
				bestWorker = w
				minInFlight = inFlight
				minTotal = total
			}
		}
	}

	if bestWorker == nil {
		return nil, fmt.Errorf("no healthy workers available for tenant %s", tenantID)
	}

	// 4. Update Stats (Optimistic Application)
	// We increment InFlight *before* returning to reserve the slot.
	// The caller MUST ensure they call ReleaseWorker later.
	s := r.getStats(bestWorker.ID)
	atomic.AddInt64(&s.InFlightRequests, 1)
	atomic.AddInt64(&s.TotalRequests, 1)

	return bestWorker, nil
}

// ReleaseWorker decrements the in-flight count.
func (r *Router) ReleaseWorker(w *worker.Worker) {
	s := r.getStats(w.ID)
	atomic.AddInt64(&s.InFlightRequests, -1)
}

// Helper to safely get stats structure
func (r *Router) getStats(id int) *RouterStats {
	// Check read lock first (usually safe since map only grows on startup/scale)
	// But strictly we might need write lock if adding new keys.
	// For high-freq path, pre-allocating is better.
	if s, ok := r.stats[id]; ok {
		return s
	}
	// Fallback (Rare write case)
	// r.mu.RUnlock() -> r.mu.Lock() -> check again -> create -> unlock -> rlock
	// For prototype simplicity, assuming initialized:
	return &RouterStats{} // Should panic or handle properly
}

// InitializeStats ensures the map is populated (called after Pool Init)
func (r *Router) InitializeStats() {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, w := range r.pool.Workers {
		if _, ok := r.stats[w.ID]; !ok {
			r.stats[w.ID] = &RouterStats{}
		}
	}
}
