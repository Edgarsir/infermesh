package router

import (
	"math/rand"
	"time"
)

// CanaryRouter handles traffic splitting for active rollouts.
type CanaryRouter struct {
	// Base router components would be referenced here.
}

func NewCanaryRouter() *CanaryRouter {
	rand.Seed(time.Now().UnixNano())
	return &CanaryRouter{}
}

// SplitDecision determines if a request goes to the Canary (v2) or Stable (v1) pool.
// canaryWeight is 0-100 representing the percentage of traffic meant for the new model.
func (c *CanaryRouter) SplitDecision(canaryWeight int) string {
	if canaryWeight <= 0 {
		return "stable"
	}
	if canaryWeight >= 100 {
		return "canary"
	}

	// Probabilistic routing: Draw a random number up to 100.
	// If it falls under the weight, route to canary.
	if rand.Intn(100) < canaryWeight {
		return "canary"
	}
	return "stable"
}
