package router

import (
	"math"
	"sync/atomic"
	"time"
)

// BackpressureTracker maintains the mathematical state of the cluster
// to dynamically calculate HTTP 'Retry-After' headers during 503 Load Shedding.
type BackpressureTracker struct {
	activeWorkers int32
	queueDepth    int32
	// Storing Exponentially Weighted Moving Average (EWMA) latency in nanoseconds for lock-free atomic access
	ewmaLatencyNs int64
}

func NewBackpressureTracker() *BackpressureTracker {
	// Initialize with a sane default expectation (e.g., 20ms per inference)
	return &BackpressureTracker{
		ewmaLatencyNs: int64(20 * time.Millisecond),
	}
}

// RecordLatency updates the EWMA of single-request processing speed.
// In reality, this is called by the Dispatcher every time an inference finishes.
func (b *BackpressureTracker) RecordLatency(latency time.Duration) {
	oldNs := atomic.LoadInt64(&b.ewmaLatencyNs)
	// Alpha = 0.1 (New data represents 10% of the average, ensuring smooth, non-spiky tracking)
	newAvgNs := int64(float64(oldNs)*0.9 + float64(latency.Nanoseconds())*0.1)
	atomic.StoreInt64(&b.ewmaLatencyNs, newAvgNs)
}

// SetQueueDepth receives the instantaneous length of the global request channel dispatcher.
func (b *BackpressureTracker) SetQueueDepth(depth int32) {
	atomic.StoreInt32(&b.queueDepth, depth)
}

// SetActiveWorkers maps to the number of GPUs currently alive and pulling from the queue.
func (b *BackpressureTracker) SetActiveWorkers(workers int32) {
	atomic.StoreInt32(&b.activeWorkers, workers)
}

// CalculateRetryAfter computes the exact structural drain-time of the system and 
// returns the number of seconds the client SDK should wait to avoid a Thundering Herd.
func (b *BackpressureTracker) CalculateRetryAfterSeconds() int {
	depth := atomic.LoadInt32(&b.queueDepth)
	workers := atomic.LoadInt32(&b.activeWorkers)
	avgNs := atomic.LoadInt64(&b.ewmaLatencyNs)

	if workers <= 0 {
		return 5 // Failsafe: If cluster is structurally dead/rebooting, wait 5s
	}

	// Drain Time = (Queue Depth * Average Inference Speed) / Parallel GPUs
	drainTimeNs := float64(depth) * float64(avgNs) / float64(workers)
	
	// HTTP Spec: Retry-After must be an integer sequence of Seconds
	drainTimeSeconds := math.Ceil(drainTimeNs / float64(time.Second))

	// Cap the bounds between 1s (minimum backoff) and 60s (to prevent permanently freezing SDKs)
	if drainTimeSeconds < 1.0 {
		return 1
	} else if drainTimeSeconds > 60.0 {
		return 60
	}

	return int(drainTimeSeconds)
}
