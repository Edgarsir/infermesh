package router

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/worker"
)

// Dispatcher manages the flow: Router -> Worker (Pull)
// It encapsulates the logic where workers proactively consume from the queue.
type Dispatcher struct {
	router *Router
	queue  *worker.Queue
	pool   *worker.Pool
}

func NewDispatcher(r *Router, q *worker.Queue, p *worker.Pool) *Dispatcher {
	return &Dispatcher{
		router: r,
		queue:  q,
		pool:   p,
	}
}

// NotifyWorkerAvailable is called when a worker finishes a request or starts up.
// It triggers the "Pull" mechanism.
func (d *Dispatcher) NotifyWorkerAvailable(w *worker.Worker) {
	// 1. Try to pull pending request from Queue
	req := d.queue.TryDequeue()
	
	if req != nil {
		// 2. Found work! Assign immediately.
		// We optimistically mark the worker busy via Router stats
		// (Though Router stats are mainly for "SelectWorker", this keeps view consistent)
		// r.router.SelectWorker logic usually handles incoming new requests,
		// but here we serve queued ones.
		
		fmt.Printf("[DISPATCH] Worker %d pulled queued request.\n", w.ID)
		
		// Send assignment to the waiting Enqueue call
		select {
		case req.ResultCh <- w:
			// Success
		default:
			// Request timed out between Dequeue and Assignment?
			// Just release worker back to pool or try next.
			// Ideally we continue loop.
		}
	} else {
		// 3. No queued work. Worker remains idle in pool,
		// available for Router.SelectWorker() to pick it up for NEW traffic.
		// fmt.Printf("[DISPATCH] Worker %d idle (Empty Queue).\n", w.ID)
	}
}

// StartWorkerEventsLoop is a mock function demonstrating how this would hook into the real system events.
// In reality, this logic runs at the end of every gRPC call handler.
func (d *Dispatcher) OnRequestComplete(w *worker.Worker) {
	d.router.ReleaseWorker(w)
	d.NotifyWorkerAvailable(w)
}
