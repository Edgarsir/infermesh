package coordinator

import (
	"context"
	"fmt"
	"time"

	"d/startup-plan/infermesh/go/pkg/observer"
	"d/startup-plan/infermesh/go/pkg/proxy"
	"d/startup-plan/infermesh/go/pkg/router"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// RequestHandler integrates all components to process a request and log it.
type RequestHandler struct {
	Router     *router.Router
	Proxy      *proxy.RequestProxy
	Logger     *observer.AsyncLogger
	Collector  *observer.MetricsCollector
}

// HandleRequest orchestrates the flow and performs observability logic.
func (h *RequestHandler) HandleRequest(ctx context.Context, tenantID, requestID string, payload interface{}) (interface{}, error) {
	// 1. Start Go-Latency Timer
	start := time.Now()
	
	// Prepare Log Entry (Populate as we go)
	logEntry := observer.AccessLogEntry{
		Timestamp: time.Now().UTC().Format(time.RFC3339),
		RequestID: requestID,
		TenantID:  tenantID,
	}

	var err error
	var result interface{}
	var selectedWorker *worker.Worker

	// Defer Logging Logic (Guaranteed execution)
	defer func() {
		// Calculate Latency
		logEntry.TotalLatencyMs = time.Since(start).Milliseconds()
		logEntry.Success = (err == nil)
		if err != nil {
			logEntry.Error = err.Error()
		}

		// Push to Async Logger
		// "These logs are written asynchronously to avoid adding I/O latency"
		h.Logger.LogRequest(logEntry)

		// Update Prometheus Metrics
		h.Collector.RecordRequest(logEntry.Success, (logEntry.Error == "upstream timeout"))
	}()

	// 2. Select Worker (Router Logic)
	// (Note: In real flow, we'd Enqueue first, then Dispatcher pulls. 
	//  For direct handling simulation, we use SelectWorker to find *who* would handle it)
	selectedWorker, err = h.Router.SelectWorker(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	logEntry.WorkerID = selectedWorker.ID

	// 3. Execute Prediction (Proxy Logic)
	// Proxy returns result AND potentially metadata about internal latency
	// For simulation, proxy just returns string. In reality, it returns a struct.
	result, err = h.Proxy.Execute(ctx, selectedWorker, payload)
	
	if err != nil {
		return nil, err
	}

	// 4. Extract C++ Metadata (Mock)
	// In reality result is a struct { Signal, Confidence, InternalLatency }
	// We simulate extraction:
	logEntry.InternalLatency = 100 // Mock C++ reporting 100ms
	logEntry.ResultSignal = "HOLD"
	logEntry.Confidence = 0.88

	return result, nil
}
