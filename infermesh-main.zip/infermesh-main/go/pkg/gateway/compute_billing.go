package gateway

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// ComputeLedger persistently tracks GPU compute time per tenant per billing period.
// This mirrors the QuotaStore architecture — both use the same key structure
// so they land in the same Redis/Postgres durability layer naturally.
type ComputeLedger interface {
	// AddMicroseconds atomically accumulates compute time for a tenant in the current period.
	// Returns the new total compute microseconds for the period.
	AddMicroseconds(ctx context.Context, key string, microseconds int64) (int64, error)

	// GetMicroseconds reads the current accumulated total without incrementing.
	GetMicroseconds(ctx context.Context, key string) (int64, error)
}

// MockComputeLedger is a thread-safe in-process store for testing.
type MockComputeLedger struct {
	mu     sync.Mutex
	totals map[string]int64
}

func NewMockComputeLedger() *MockComputeLedger {
	return &MockComputeLedger{totals: make(map[string]int64)}
}

func (m *MockComputeLedger) AddMicroseconds(_ context.Context, key string, us int64) (int64, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.totals[key] += us
	return m.totals[key], nil
}

func (m *MockComputeLedger) GetMicroseconds(_ context.Context, key string) (int64, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.totals[key], nil
}

// ComputeBillingManager converts raw C++-reported durations into durable tenant ledger entries.
// It reuses the billing period key logic from QuotaManager so both counters
// (request count + compute-seconds) share the same cycle boundaries.
type ComputeBillingManager struct {
	ledger ComputeLedger
}

func NewComputeBillingManager(ledger ComputeLedger) *ComputeBillingManager {
	return &ComputeBillingManager{ledger: ledger}
}

// RecordInference is called by the Go gateway immediately after C++ returns an inference result.
// C++ reports its own internal compute duration (excluding socket overhead) so the billing
// reflects actual GPU time consumed — not network jitter.
func (cbm *ComputeBillingManager) RecordInference(
	ctx context.Context,
	tenantID string,
	cycleAnchor time.Time,
	gpuDuration time.Duration,
) error {
	// Derive the same period key as quota so both counters are co-located in the store.
	periodKey := computePeriodKey(tenantID, cycleAnchor, time.Now().UTC())

	us := gpuDuration.Microseconds()

	newTotal, err := cbm.ledger.AddMicroseconds(ctx, periodKey, us)
	if err != nil {
		return fmt.Errorf("ComputeBilling: failed to persist for tenant %s: %w", tenantID, err)
	}

	// Human-readable summary log — feeds the dashboard without an extra DB query.
	fmt.Printf("[BILLING] Tenant %-20s | GPU: %6v | Period Total: %.4f compute-seconds\n",
		tenantID, gpuDuration, float64(newTotal)/1e6)

	return nil
}

// GetComputeSeconds returns the total GPU compute time consumed in the current billing window.
// Used by the billing API endpoint and the admin dashboard.
func (cbm *ComputeBillingManager) GetComputeSeconds(
	ctx context.Context,
	tenantID string,
	cycleAnchor time.Time,
) (float64, error) {
	key := computePeriodKey(tenantID, cycleAnchor, time.Now().UTC())
	us, err := cbm.ledger.GetMicroseconds(ctx, key)
	if err != nil {
		return 0, err
	}
	return float64(us) / 1e6, nil
}

// computePeriodKey mirrors CalculateBillingPeriodKey from quota.go
// using a distinct prefix so request-count and compute-seconds never collide in the store.
func computePeriodKey(tenantID string, anchor time.Time, now time.Time) string {
	startYear, startMonth, _ := now.Date()
	if now.Day() < anchor.Day() {
		startMonth -= 1
		if startMonth < time.January {
			startMonth = time.December
			startYear--
		}
	}
	return fmt.Sprintf("compute:%s:%04d-%02d-%02d", tenantID, startYear, startMonth, anchor.Day())
}
