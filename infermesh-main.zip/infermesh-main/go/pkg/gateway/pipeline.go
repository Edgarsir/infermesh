package gateway

import (
	"context"
	"crypto/tls"
	"net"
	"sync"
	"time"

	"github.com/google/uuid"
)

// PipelineContext carries metadata about the request as it flows through the stages.
type PipelineContext struct {
	StartTime   time.Time
	ClientIP    string
	RequestID   string
	TenantID    string
	RawBody     []byte
	Endpoint    string // e.g. "/v1/predict"
	AuthToken   string
}

// PipelineError represents a failure at a specific stage with an HTTP status code.
type PipelineError struct {
	Stage      string
	Message    string
	StatusCode int
	Err        error
}

func (e *PipelineError) Error() string {
	return e.Message
}

// Stage 1: TLS Termination
// In a real Go server (e.g. net/http), this is handled by server configuration.
// Here we define the config loader to ensure it's enforced.
func LoadTLSConfig(certFile, keyFile string) (*tls.Config, error) {
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, err
	}
	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS13, // Enforce modern TLS
	}, nil
}

// Stage 2: Connection Rate Limiter (IP Based)
// Simple in-memory token bucket or counter for demonstration.
type IPRateLimiter struct {
	mu      sync.Mutex
	counters map[string]int
	lastReset time.Time
	limit   int // Requests per second
}

func NewIPRateLimiter(limit int) *IPRateLimiter {
	return &IPRateLimiter{
		counters:  make(map[string]int),
		lastReset: time.Now(),
		limit:     limit,
	}
}

func (rl *IPRateLimiter) Allow(ip string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	// Reset counters every second
	if time.Since(rl.lastReset) > time.Second {
		rl.counters = make(map[string]int)
		rl.lastReset = time.Now()
	}

	if rl.counters[ip] >= rl.limit {
		return false
	}
	rl.counters[ip]++
	return true
}

// RequestPipeline orchestrates the 8-stage flow.
type RequestPipeline struct {
	ipLimiter *IPRateLimiter
	// ... other dependencies (auth, registry, etc)
}

func NewRequestPipeline() *RequestPipeline {
	return &RequestPipeline{
		ipLimiter: NewIPRateLimiter(100), // Allow 100 conn/sec per IP default
	}
}

// Execute runs the request through the pipeline.
// Inputs are raw connection details to simulate the early stages.
func (p *RequestPipeline) Execute(ctx context.Context, conn net.Conn, rawReq []byte) (*PipelineContext, error) {
	pc := &PipelineContext{
		StartTime: time.Now(),
	}

	// Stage 1: TLS is assumed handled by the listener before this Execute call
	// but we could verify connection state here if we had access to tls.Conn.

	// Stage 2: IP Rate Limiting
	host, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	pc.ClientIP = host
	if !p.ipLimiter.Allow(host) {
		return nil, &PipelineError{Stage: "IPLimit", Message: "Too many connections", StatusCode: 429}
	}

	// Stage 3: Request Parsing (Mock)
	// In reality: Check Content-Length, parse JSON/Protobuf
	if len(rawReq) > 10*1024*1024 { // 10MB Limit
		return nil, &PipelineError{Stage: "Parsing", Message: "Request body too large", StatusCode: 413}
	}
	pc.RawBody = rawReq
	// Mock Parsing logic...
	pc.Endpoint = "/v1/predict" // extracted from bytes

	// Stage 4: Authentication (Mock)
	// Extract token from header...
	token := "dummy_token" // MOCK
	if token == "" {
		return nil, &PipelineError{Stage: "Auth", Message: "Missing Authorization header", StatusCode: 401}
	}
	// Verify JWT...
	pc.TenantID = "tenant_123" // Extracted from valid token

	// Stage 5: Registry Lookup (Mock)
	validTenants := map[string]bool{"tenant_123": true}
	if !validTenants[pc.TenantID] {
		return nil, &PipelineError{Stage: "Registry", Message: "Tenant not found or suspended", StatusCode: 403}
	}

	// Stage 6: Tenant Rate Limiting (Mock)
	// Check Redis/Memory for tenant_123 usage...
	tenantQuotaExceeded := false 
	if tenantQuotaExceeded {
		return nil, &PipelineError{Stage: "TenantLimit", Message: "Quota exceeded", StatusCode: 429}
	}

	// Stage 7: Request ID Assignment
	pc.RequestID = uuid.New().String()
	// Log immediately
	// logger.Info("Request Accepted", "id", pc.RequestID, "tenant", pc.TenantID)

	// Stage 8: Ready for Routing
	return pc, nil
}
