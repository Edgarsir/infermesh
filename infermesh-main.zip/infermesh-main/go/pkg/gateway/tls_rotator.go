package gateway

import (
	"crypto/tls"
	"fmt"
	"sync"
	"time"
)

// TLSRotator manages dynamic certificate loading for zero-downtime HTTPS.
type TLSRotator struct {
	mu       sync.RWMutex
	cert     *tls.Certificate
	certPath string
	keyPath  string

	// For polling/watching (in reality, fsnotify could be used, but polling is robust against symlink swaps)
	interval time.Duration
	stopCh   chan struct{}
}

func NewTLSRotator(certPath, keyPath string, interval time.Duration) (*TLSRotator, error) {
	rotator := &TLSRotator{
		certPath: certPath,
		keyPath:  keyPath,
		interval: interval,
		stopCh:   make(chan struct{}),
	}
	
	// Initial load
	if err := rotator.loadCertificate(); err != nil {
		return nil, fmt.Errorf("initial TLS certificate load failed: %w", err)
	}
	
	return rotator, nil
}

func (tr *TLSRotator) loadCertificate() error {
	cert, err := tls.LoadX509KeyPair(tr.certPath, tr.keyPath)
	if err != nil {
		return err
	}
	
	tr.mu.Lock()
	defer tr.mu.Unlock()
	tr.cert = &cert
	return nil
}

// GetCertificateFunc returns a function that implements tls.Config.GetCertificate
// Go's HTTP/HTTPS server invokes this natively exactly once at the start of every connection handshake. 
func (tr *TLSRotator) GetCertificateFunc() func(*tls.ClientHelloInfo) (*tls.Certificate, error) {
	return func(hello *tls.ClientHelloInfo) (*tls.Certificate, error) {
		tr.mu.RLock()
		defer tr.mu.RUnlock()
		return tr.cert, nil
	}
}

// Start begins a background goroutine to poll the disk files for changes.
// Certbot and cert-manager often use symlinks to atomically swap certificates.
// Polling the path absorbs arbitrary filesystem symlink behaviors securely.
func (tr *TLSRotator) Start() {
	go func() {
		ticker := time.NewTicker(tr.interval)
		defer ticker.Stop()
		
		for {
			select {
			case <-ticker.C:
				// Attempt to load. If it fails (file briefly unavailable mid-swap), 
				// we just ignore the error and keep the old cert actively in RAM.
				if err := tr.loadCertificate(); err != nil {
					// Log softly. Do not crash!
					// fmt.Printf("[TLS] Soft-Watch Error: %v\n", err)
				}
			case <-tr.stopCh:
				return
			}
		}
	}()
}

func (tr *TLSRotator) Stop() {
	close(tr.stopCh)
}
