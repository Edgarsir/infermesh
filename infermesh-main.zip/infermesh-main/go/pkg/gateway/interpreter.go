package gateway

import (
	"fmt"
)

// LabelConfig maps tensor output indices to human-readable string signals.
// This MUST perfectly match the LabelEncoder logic used during Python model training.
type LabelConfig struct {
	IndexToSignal map[int]string
}

// Interpreter translates raw C++ float outputs into business signals.
type Interpreter struct {
	// In reality, this would be fetched from the Tenant Registry Dynamic Config.
	// We store a global default for demonstration.
	DefaultLabels map[int]string
}

func NewInterpreter() *Interpreter {
	return &Interpreter{
		DefaultLabels: map[int]string{
			0: "BUY",
			1: "SELL",
			2: "HOLD",
		},
	}
}

// Interpret calculates Argmax on the raw probabilities and maps to a Signal.
// Returns (SignalString, ConfidenceScore, Error)
func (i *Interpreter) Interpret(probabilities []float32, customLabels map[int]string) (string, float64, error) {
	if len(probabilities) == 0 {
		return "", 0.0, fmt.Errorf("empty probability array returned from C++")
	}

	labels := customLabels
	if labels == nil {
		labels = i.DefaultLabels
	}

	// 1. Argmax calculation
	var maxIdx int = 0
	var maxProb float32 = probabilities[0]

	for idx, prob := range probabilities {
		if prob > maxProb {
			maxProb = prob
			maxIdx = idx
		}
	}

	// 2. Mapping Index to Signal
	signal, exists := labels[maxIdx]
	if !exists {
		// Fallback if tenant model outputs more classes than configured labels
		signal = fmt.Sprintf("CLASS_%d", maxIdx)
		fmt.Printf("[WARN] Interpreter: Missing label for index %d. Returning %s\n", maxIdx, signal)
	}

	// Confidence is the absolute probability of the chosen class.
	return signal, float64(maxProb), nil
}
