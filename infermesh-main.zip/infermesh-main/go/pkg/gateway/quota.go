package gateway

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

var ErrQuotaExhausted = errors.New("monthly billing quota exhausted")

// QuotaStore abstracts the persistent database (e.g., Redis, PostgreSQL) tracking cumulative counts.
type QuotaStore interface {
	// Increment adds 1 to the key and returns the new total
	Increment(ctx context.Context, key string) (int64, error)
}

// MockQuotaStore provides an in-memory implementation for testing
type MockQuotaStore struct {
	mu     sync.Mutex
	counts map[string]int64
}

func NewMockQuotaStore() *MockQuotaStore {
	return &MockQuotaStore{
		counts: make(map[string]int64),
	}
}

func (m *MockQuotaStore) Increment(ctx context.Context, key string) (int64, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.counts[key]++
	return m.counts[key], nil
}

// QuotaManager governs the absolute Monthly Billing limit separate from instantaneous Rate Limits.
type QuotaManager struct {
	store QuotaStore
}

func NewQuotaManager(store QuotaStore) *QuotaManager {
	return &QuotaManager{store: store}
}

// CheckAndIncrement verifies if the tenant has quota left in their current billing cycle.
// If valid, it persists the charge count. If exhausted, it returns ErrQuotaExhausted.
func (qm *QuotaManager) CheckAndIncrement(ctx context.Context, tenantID string, cycleAnchor time.Time, monthlyQuota int64) error {
	// 1. Calculate the exact billing period window based on the persistent anchor date
	periodKey := qm.CalculateBillingPeriodKey(tenantID, cycleAnchor, time.Now().UTC())

	// 2. Increment and fetch current persistent usage
	//    In a real system, you might want a pipeline/script to check AND increment atomically 
	//    to avoid pushing the counter past the quota. For simplicity, we increment then check.
	currentUsage, err := qm.store.Increment(ctx, periodKey)
	if err != nil {
		return fmt.Errorf("failed to update billing quota: %w", err)
	}

	// 3. Evaluate Hard Bound
	if currentUsage > monthlyQuota {
		return ErrQuotaExhausted
	}

	return nil
}

// CalculateBillingPeriodKey generates a deterministic string identifying the current
// active month for a specific tenant based on their unique billing signup day.
func (qm *QuotaManager) CalculateBillingPeriodKey(tenantID string, anchor time.Time, now time.Time) string {
	// A billing cycle runs from anchor day of month X to anchor day of month X+1.
	startYear, startMonth, _ := now.Date()
	
	// If today's day is before the anchor day, the current cycle started last month.
	if now.Day() < anchor.Day() {
		startMonth -= 1
		if startMonth < time.January {
			startMonth = time.December
			startYear -= 1
		}
	}

	// Output format: tenant-abc:2023-10-15
	return fmt.Sprintf("quota:%s:%04d-%02d-%02d", tenantID, startYear, startMonth, anchor.Day())
}
