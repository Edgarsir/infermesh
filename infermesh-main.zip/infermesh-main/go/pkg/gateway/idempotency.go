package gateway

import (
	"context"
	"fmt"
	"net/http"
	"sync"
	"time"
)

// IdempotencyStore defines the storage mechanism for caching duplicate request results.
// In a distributed production cluster, this would be a Redis client.
type IdempotencyStore interface {
	Get(ctx context.Context, key string) ([]byte, bool, error)
	Set(ctx context.Context, key string, data []byte, ttl time.Duration) error
}

// MockRedisStore simulates a distributed Redis cache with TTL management.
type MockRedisStore struct {
	mu    sync.RWMutex
	store map[string]CacheEntry
}

type CacheEntry struct {
	Data      []byte
	ExpiresAt time.Time
}

func NewMockRedisStore() *MockRedisStore {
	m := &MockRedisStore{
		store: make(map[string]CacheEntry),
	}
	// Background cleanup loop for expired keys
	go func() {
		for {
			time.Sleep(5 * time.Second)
			m.cleanup()
		}
	}()
	return m
}

func (m *MockRedisStore) cleanup() {
	m.mu.Lock()
	defer m.mu.Unlock()
	now := time.Now()
	for k, v := range m.store {
		if now.After(v.ExpiresAt) {
			delete(m.store, k)
		}
	}
}

func (m *MockRedisStore) Get(ctx context.Context, key string) ([]byte, bool, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	entry, exists := m.store[key]
	if !exists {
		return nil, false, nil
	}

	if time.Now().After(entry.ExpiresAt) {
		return nil, false, nil // Logically expired before cleanup loop caught it
	}

	return entry.Data, true, nil
}

func (m *MockRedisStore) Set(ctx context.Context, key string, data []byte, ttl time.Duration) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.store[key] = CacheEntry{
		Data:      data,
		ExpiresAt: time.Now().Add(ttl),
	}
	return nil
}

// responseRecorder intercepts the HTTP response so we can cache the bytes before returning to client
type responseRecorder struct {
	http.ResponseWriter
	body       []byte
	statusCode int
}

func (rw *responseRecorder) Write(b []byte) (int, error) {
	rw.body = append(rw.body, b...)
	return rw.ResponseWriter.Write(b)
}

func (rw *responseRecorder) WriteHeader(statusCode int) {
	rw.statusCode = statusCode
	rw.ResponseWriter.WriteHeader(statusCode)
}

// IdempotencyMiddleware ensures that if a client retries exactly the same transaction,
// they get the exactly identical previously computed output without hitting the GPU.
type IdempotencyMiddleware struct {
	Store   IdempotencyStore
	CacheTTL time.Duration
}

func NewIdempotencyMiddleware(store IdempotencyStore, ttl time.Duration) *IdempotencyMiddleware {
	return &IdempotencyMiddleware{
		Store:   store,
		CacheTTL: ttl,
	}
}

func (m *IdempotencyMiddleware) WrapHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		idemKey := r.Header.Get("Idempotency-Key")

		// If the client doesn't provide a key, we just process it normally
		if idemKey == "" {
			next.ServeHTTP(w, r)
			return
		}

		// Prefix the key with tenant ID to isolate namespaces
		tenantID := r.Header.Get("X-Tenant-Id")
		if tenantID == "" {
			tenantID = "unknown_tenant"
		}
		
		cacheKey := fmt.Sprintf("idem:%s:%s", tenantID, idemKey)

		// 1. Check Distributed Cache
		cachedData, found, err := m.Store.Get(r.Context(), cacheKey)
		if err != nil {
			// Redis failure shouldn't break the whole app, just bypass cache
			fmt.Printf("[IDEMPOTENCY] Warning: Cache fetch failed: %v\n", err)
		} else if found {
			// CACHE HIT! Short-circuit the request entirely.
			fmt.Printf("[IDEMPOTENCY] HIT on %s. Injecting cached response without utilizing GPU.\n", cacheKey)
			w.Header().Set("X-Idempotency-Status", "HIT")
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			w.Write(cachedData)
			return
		}

		// 2. CACHE MISS. Process the request normally.
		fmt.Printf("[IDEMPOTENCY] MISS on %s. Forwarding to Engine...\n", cacheKey)
		
		recorder := &responseRecorder{
			ResponseWriter: w,
			statusCode:     http.StatusOK, // default
		}

		next.ServeHTTP(recorder, r)

		// 3. Cache the deterministic answer on the way out (Only cache successful 200s!)
		if recorder.statusCode == http.StatusOK {
			err = m.Store.Set(r.Context(), cacheKey, recorder.body, m.CacheTTL)
			if err != nil {
				fmt.Printf("[IDEMPOTENCY] Warning: Failed to persist cache key %s: %v\n", cacheKey, err)
			}
			recorder.Header().Set("X-Idempotency-Status", "STORED")
		} else {
			// It's a 4xx or 5xx error. Do NOT cache it, so the client can organically retry 
			// and hopefully succeed on the next pass if the network stabilizes.
			fmt.Printf("[IDEMPOTENCY] BYPASS caching on %s due to HTTP %d error.\n", cacheKey, recorder.statusCode)
		}
	})
}
