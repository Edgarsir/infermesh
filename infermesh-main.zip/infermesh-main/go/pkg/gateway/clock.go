package gateway

import (
	"fmt"
	"net/http"
	"strconv"
	"time"
)

// ClockSkewConfig holds thresholds for staleness and future tolerances.
type ClockSkewConfig struct {
	MaxStalenessMs   int64 // e.g., 2000ms (Reject if older than 2s)
	FutureToleranceMs int64 // e.g., 200ms  (Reject if >200ms in the future)
}

// ClockMiddleware enforces timestamp freshness and provides server time to clients
// so they can offset their own local clocks dynamically.
type ClockMiddleware struct {
	config ClockSkewConfig
}

func NewClockMiddleware(cfg ClockSkewConfig) *ClockMiddleware {
	return &ClockMiddleware{config: cfg}
}

// ValidateRequest enforces the clock skew boundaries.
// Returns an HTTP error code if invalid, or 0 if valid.
func (c *ClockMiddleware) ValidateRequest(clientTimeMs int64, serverTimeMs int64) (int, error) {
	delta := serverTimeMs - clientTimeMs

	// 1. Future Tolerance
	// If delta is negative, the client thinks it's in the future.
	// We allow a small window (e.g. 200ms) to account for imperfect NTP syncing.
	if delta < -c.config.FutureToleranceMs {
		return http.StatusBadRequest, fmt.Errorf("request timestamp is %.0fms in the future (exceeds %dms tolerance)", float64(-delta), c.config.FutureToleranceMs)
	}

	// 2. Maximum Staleness
	// If the request took too long in the network or was queued indefinitely on the client,
	// we reject it because inference decisions are extremely time-sensitive.
	if delta > c.config.MaxStalenessMs {
		return http.StatusRequestTimeout, fmt.Errorf("request is %dms stale (exceeds %dms limit)", delta, c.config.MaxStalenessMs)
	}

	return 0, nil
}

// WrapHandler provides standard HTTP middleware injection.
func (c *ClockMiddleware) WrapHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		serverTime := time.Now().UnixMilli()
		
		// 1. Always inject the server timestamp for client-side offset calibration
		w.Header().Set("X-Server-Timestamp", strconv.FormatInt(serverTime, 10))

		// 2. Extract Client Timestamp
		clientTimeStr := r.Header.Get("X-Client-Timestamp")
		if clientTimeStr == "" {
			http.Error(w, "Missing X-Client-Timestamp header", http.StatusBadRequest)
			return
		}

		clientTime, err := strconv.ParseInt(clientTimeStr, 10, 64)
		if err != nil {
			http.Error(w, "Invalid X-Client-Timestamp format", http.StatusBadRequest)
			return
		}

		// 3. Enforce Skew Policies
		if status, err := c.ValidateRequest(clientTime, serverTime); err != nil {
			http.Error(w, err.Error(), status)
			return
		}

		// 4. Continue pipeline
		next.ServeHTTP(w, r)
	})
}
