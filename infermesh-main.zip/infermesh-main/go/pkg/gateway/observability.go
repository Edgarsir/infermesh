package gateway

import (
	"fmt"
	"sync"
	"time"
)

// LowCardinalityMetrics represents real-time Prometheus-style metrics.
// These use bounded labels (worker_id, model_version, error_type) to prevent TSDB explosions.
type LowCardinalityMetrics struct {
	// In reality this would be prometheus.CounterVec
	requestCounts map[string]int64
	mu            sync.RWMutex
}

func NewLowCardinalityMetrics() *LowCardinalityMetrics {
	return &LowCardinalityMetrics{
		requestCounts: make(map[string]int64),
	}
}

// RecordRequest tracks a request using only safe, low-cardinality labels.
// Notice TenantID is explicitly FORBIDDEN here.
func (lm *LowCardinalityMetrics) RecordRequest(workerID, modelVersion, errorType string) {
	// e.g. "worker-1|v1.2.0|none"
	key := fmt.Sprintf("%s|%s|%s", workerID, modelVersion, errorType)
	
	lm.mu.Lock()
	defer lm.mu.Unlock()
	lm.requestCounts[key]++
}

func (lm *LowCardinalityMetrics) GetSnapshot() map[string]int64 {
	lm.mu.RLock()
	defer lm.mu.RUnlock()
	
	snap := make(map[string]int64)
	for k, v := range lm.requestCounts {
		snap[k] = v
	}
	return snap
}

// HighCardinalityAggregator handles infinite-bound labels like TenantID efficiently.
// It maintains counters in RAM and flushes them to a specialized TSDB on a strict tick,
// resetting the RAM usage gracefully to prevent OOM errors and network storms.
type HighCardinalityAggregator struct {
	mu           sync.Mutex
	tenantCounts map[string]int64
	flushTick    time.Duration
	stopCh       chan struct{}
	
	// Mock external sender
	FlushHook func(snapshot map[string]int64)
}

func NewHighCardinalityAggregator(interval time.Duration) *HighCardinalityAggregator {
	return &HighCardinalityAggregator{
		tenantCounts: make(map[string]int64),
		flushTick:    interval,
		stopCh:       make(chan struct{}),
	}
}

func (ha *HighCardinalityAggregator) Start() {
	go func() {
		ticker := time.NewTicker(ha.flushTick)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				ha.flush()
			case <-ha.stopCh:
				return
			}
		}
	}()
}

func (ha *HighCardinalityAggregator) Stop() {
	close(ha.stopCh)
}

// RecordTenantUsage increments cheap RAM counters instantly per request.
func (ha *HighCardinalityAggregator) RecordTenantUsage(tenantID string) {
	ha.mu.Lock()
	defer ha.mu.Unlock()
	ha.tenantCounts[tenantID]++
}

// flush safely copies the map, resets RAM to 0 natively, and triggers the network push.
func (ha *HighCardinalityAggregator) flush() {
	ha.mu.Lock()
	if len(ha.tenantCounts) == 0 {
		ha.mu.Unlock()
		return
	}

	// Hot-swap map ptr for absolute zero-downtime execution
	snapshot := ha.tenantCounts
	ha.tenantCounts = make(map[string]int64) // Reset for next window
	ha.mu.Unlock()

	// Push over network (Invoking the hook)
	if ha.FlushHook != nil {
		ha.FlushHook(snapshot)
	}
}
