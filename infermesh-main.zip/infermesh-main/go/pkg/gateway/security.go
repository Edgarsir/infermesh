package gateway

import (
	"fmt"
	"math/rand"
	"sync"
)

// SecurityConfig holds the parameters for Model Extraction / Inversion defense.
type SecurityConfig struct {
	EnablePerturbation     bool
	NoiseScale             float64 // e.g., 0.005 for 0.5% noise
	
	EnableAnomalyDetection bool
	SweepHistorySize       int     // Number of sequential requests to track for probing
}

// SecurityInterceptor sits in front of the Gateway and sanitizes both incoming vectors and outgoing probabilities.
type SecurityInterceptor struct {
	config SecurityConfig
	
	// Anomaly Detection State (Tracks per-tenant recent vector history)
	mu            sync.Mutex
	tenantHistory map[string][][]float64
}

func NewSecurityInterceptor(cfg SecurityConfig) *SecurityInterceptor {
	return &SecurityInterceptor{
		config:        cfg,
		tenantHistory: make(map[string][][]float64),
	}
}

// PerturbOutput adds computationally harmless but cryptographically frustrating noise 
// to the actual prediction confidence score. This physically prevents an attacker from 
// mathematically differentiating the model weights using microscopic gradient shifts.
func (s *SecurityInterceptor) PerturbOutput(confidence float64) float64 {
	if !s.config.EnablePerturbation {
		return confidence
	}
	
	// Generate random noise between -NoiseScale and +NoiseScale
	noise := (rand.Float64() * 2.0 - 1.0) * s.config.NoiseScale
	
	perturbed := confidence + noise
	
	// Keep confidence bounds mathematically valid [0.0, 1.0]
	if perturbed > 1.0 {
		return 1.0
	}
	if perturbed < 0.0 {
		return 0.0
	}
	return perturbed
}

// AnalyzeFeatureDistribution inspects the statistical flow of incoming data.
// If an attacker attempts to systematically "Sweep" or "Grid Search" the API exactly,
// their feature inputs will exhibit a completely unnatural linear progression rather than 
// organic human/business variance.
func (s *SecurityInterceptor) AnalyzeFeatureDistribution(tenantID string, features []float64) error {
	if !s.config.EnableAnomalyDetection || len(features) == 0 {
		return nil
	}
	
	s.mu.Lock()
	defer s.mu.Unlock()
	
	history := s.tenantHistory[tenantID]
	// Clone the float array to avoid referential memory overwrites
	clone := make([]float64, len(features))
	copy(clone, features)
	
	history = append(history, clone)
	
	// Mantain a bounded sliding window
	if len(history) > s.config.SweepHistorySize {
		history = history[1:]
	}
	s.tenantHistory[tenantID] = history
	
	// We need a minimum number of consecutive data points to detect a geometric probing attack
	if len(history) >= s.config.SweepHistorySize {
		isLinearSweep := true
		
		// 1. Calculate the foundational translation vector (Delta between Request 0 and Request 1)
		baseDelta := make([]float64, len(features))
		for i := 0; i < len(features); i++ {
			baseDelta[i] = history[1][i] - history[0][i]
		}
		
		// 2. Validate if the attacker is just incrementing their floats steadily (e.g. loops)
		for j := 1; j < len(history)-1; j++ {
			for i := 0; i < len(features); i++ {
				currentDelta := history[j+1][i] - history[j][i]
				
				// Standard Floating Point tolerance
				if abs(currentDelta - baseDelta[i]) > 1e-5 {
					isLinearSweep = false
					break
				}
			}
			if !isLinearSweep {
				break
			}
		}
		
		if isLinearSweep {
			// Ignore exactly duplicate payloads (which might just be innocent client retries).
			// We only ban them if the Delta is actively shifting the boundary.
			isActivelySweeping := false
			for _, v := range baseDelta {
				if abs(v) > 1e-5 {
					isActivelySweeping = true
					break
				}
			}
			if isActivelySweeping {
				return fmt.Errorf("SECURITY ALERT: Systematic feature space probing detected. IP blocks and Tenant suspension recommended.")
			}
		}
	}
	
	return nil
}

func abs(x float64) float64 {
	if x < 0 {
		return -x
	}
	return x
}
