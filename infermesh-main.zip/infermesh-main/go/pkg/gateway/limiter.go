package gateway

import (
	"sync"

	"golang.org/x/time/rate"
)

// TenantLimiter manages per-tenant token buckets.
type TenantLimiter struct {
	limiters map[string]*rate.Limiter
	mu       sync.RWMutex
}

func NewTenantLimiter() *TenantLimiter {
	return &TenantLimiter{
		limiters: make(map[string]*rate.Limiter),
	}
}

// Allow checks if a request can proceed.
// rps: Requests Per Second limits.
// burst: Max tokens allowed in bucket (burst capability).
func (tl *TenantLimiter) Allow(tenantID string, rps int, burst int) bool {
	tl.mu.RLock()
	limiter, exists := tl.limiters[tenantID]
	tl.mu.RUnlock()

	if !exists {
		tl.mu.Lock()
		defer tl.mu.Unlock()
		// Double check
		if limiter, exists = tl.limiters[tenantID]; !exists {
			// Create new Token Bucket
			// Rate = rps, Burst = burst (typically rps or higher)
			limiter = rate.NewLimiter(rate.Limit(rps), burst)
			tl.limiters[tenantID] = limiter
		}
	}

	// Dynamic Update: If quota changed (e.g. plan upgrade), update limiter
	if limiter.Limit() != rate.Limit(rps) {
		limiter.SetLimit(rate.Limit(rps))
		limiter.SetBurst(burst)
	}

	// Try to consume 1 token
	return limiter.Allow()
}
