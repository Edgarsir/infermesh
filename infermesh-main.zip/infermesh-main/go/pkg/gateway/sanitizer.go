package gateway

import (
	"encoding/json"
	"fmt"
	"math"
)

// InferencePayload represents the expected JSON structure from the client.
type InferencePayload struct {
	FeatureDim int       `json:"feature_dim"`
	Features   []float64 `json:"features"`
}

// InputSanitizer handles the validation of incoming payload data before it reaches C++.
type InputSanitizer struct{}

// Validate Payload performs strict checks on the numerical data structure.
// Returns the parsed payload if valid, or an error detailing the validation failure.
func (s *InputSanitizer) ValidatePayload(rawJSON []byte, expectedDim int) (*InferencePayload, error) {
	var payload InferencePayload

	// 1. Basic JSON Parsing
	if err := json.Unmarshal(rawJSON, &payload); err != nil {
		return nil, fmt.Errorf("malformed JSON payload: %w", err)
	}

	// 2. Feature Dimension Validation
	// Prevent mismatch between declared dim, actual array length, and tenant's expected model dim.
	if payload.FeatureDim != expectedDim {
		return nil, fmt.Errorf("feature_dim mismatch: expected %d for this model, got %d", expectedDim, payload.FeatureDim)
	}

	if len(payload.Features) != payload.FeatureDim {
		return nil, fmt.Errorf("features array length (%d) does not match declared feature_dim (%d)", len(payload.Features), payload.FeatureDim)
	}

	// 3. Numerical Validation (IEEE 754 Safety)
	// JSON allows representing NaN and Infinity (sometimes loosely parsed depending on unmarshaler config/language), 
	// but sending these to C++ tensor operations can cause silent propagation of NaNs (corrupting math) 
	// or outright crashes in optimized BLAS/CUDA kernels.
	for i, val := range payload.Features {
		if math.IsNaN(val) {
			return nil, fmt.Errorf("invalid float at index %d: NaN is not allowed", i)
		}
		if math.IsInf(val, 0) {
			return nil, fmt.Errorf("invalid float at index %d: Infinity is not allowed", i)
		}
	}

	return &payload, nil
}
