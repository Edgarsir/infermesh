package gateway

import (
	"fmt"
	"runtime"
	"sync/atomic"
	"time"
)

// PressureState represents the current severity of Go's memory utilization.
type PressureState int

const (
	PressureNormal PressureState = iota
	PressureElevated             // e.g., > 60%
	PressureCritical             // e.g., > 85% - Actively shedding load
)

// MemoryManager monitors the Go runtime heap and dictates system-wide load shedding.
type MemoryManager struct {
	MaxHeapBytes   uint64
	AlertThreshold float64 // 0.60 (60%)
	ShedThreshold  float64 // 0.85 (85%)

	currentState int32 // atomic PressureState
	AlertCh      chan string
}

func NewMemoryManager(maxBytes uint64, alertCh chan string) *MemoryManager {
	mm := &MemoryManager{
		MaxHeapBytes:   maxBytes,
		AlertThreshold: 0.60,
		ShedThreshold:  0.85,
		currentState:   int32(PressureNormal),
		AlertCh:        alertCh,
	}

	// Start background monitoring loop
	go mm.monitorLoop()

	return mm
}

// monitorLoop periodically checks runtime.ReadMemStats.
func (mm *MemoryManager) monitorLoop() {
	var m runtime.MemStats
	for {
		time.Sleep(2 * time.Second) // Check interval

		runtime.ReadMemStats(&m)
		usageBytes := m.Alloc // Number of bytes allocated and still in use

		usagePct := float64(usageBytes) / float64(mm.MaxHeapBytes)

		if usagePct >= mm.ShedThreshold {
			if atomic.SwapInt32(&mm.currentState, int32(PressureCritical)) != int32(PressureCritical) {
				msg := fmt.Sprintf("[OOM_GUARD] CRITICAL MEMORY PRESSURE: Heap at %.1f%% (%d bytes). Initiating Load Shedding!", usagePct*100, usageBytes)
				fmt.Println(msg)
				mm.fireAlert(msg)
			}
		} else if usagePct >= mm.AlertThreshold {
			if atomic.SwapInt32(&mm.currentState, int32(PressureElevated)) != int32(PressureElevated) {
				msg := fmt.Sprintf("[OOM_GUARD] Elevated Memory Pressure: Heap at %.1f%% (%d bytes).", usagePct*100, usageBytes)
				fmt.Println(msg)
				mm.fireAlert(msg)
			}
		} else {
			if atomic.SwapInt32(&mm.currentState, int32(PressureNormal)) != int32(PressureNormal) {
				fmt.Printf("[OOM_GUARD] Memory Pressure Resolved: Heap recovered to %.1f%%.\n", usagePct*100)
			}
		}
	}
}

func (mm *MemoryManager) fireAlert(msg string) {
	select {
	case mm.AlertCh <- msg:
	default: // Channel full, don't block
	}
}

// ShouldShedLoad is called immediately by the Gateway HTTP Handler.
// If it returns true, the Gateway instantly drops the request with a 503 instead of queueing it
// or parsing the JSON payload (which costs memory).
func (mm *MemoryManager) ShouldShedLoad() bool {
	state := PressureState(atomic.LoadInt32(&mm.currentState))
	return state == PressureCritical
}

// GetDynamicQueueScale returns a multiplier (e.g. 0.5) to temporarily shrink buffered channels.
func (mm *MemoryManager) GetDynamicQueueScale() float64 {
	state := PressureState(atomic.LoadInt32(&mm.currentState))
	switch state {
	case PressureCritical:
		return 0.1 // Shrink queues to 10% capacity
	case PressureElevated:
		return 0.5 // Shrink queues to 50% capacity
	default:
		return 1.0 // Normal 100% capacity
	}
}
