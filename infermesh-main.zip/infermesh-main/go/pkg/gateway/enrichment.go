package gateway

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

// EnrichmentTimeoutBehavior defines how the Gateway reacts if the 
// external Feature Store fails to return the required vectors in time.
type EnrichmentTimeoutBehavior int

const (
	// TimeoutReject instantly aborts the inference request (HTTP 500/504).
	TimeoutReject EnrichmentTimeoutBehavior = iota
	// TimeoutProceedPartial passes whatever data the client had directly to C++ 
	// (usually assuming missing features are filled with zeros or NaNs in C++).
	TimeoutProceedPartial
	// TimeoutQueue blocks the request, retrying or waiting for the Feature Store 
	// to recover, effectively pausing inference indefinitely until data is fetched.
	TimeoutQueue
)

var (
	ErrEnrichmentTimeout = errors.New("feature store enrichment timed out")
	ErrEnrichmentFailed  = errors.New("feature store enrichment failed")
)

// FeatureStore defines the interface for an external ultra-low latency database (e.g. Redis/ScyllaDB).
type FeatureStore interface {
	FetchFeatures(ctx context.Context, keys []string) (map[string]float64, error)
}

// MockFeatureStore simulates an external ML Feature Store caching live market/user states.
type MockFeatureStore struct {
	mu            sync.RWMutex
	data          map[string]float64
	latency       time.Duration
	simulateError bool
}

func NewMockFeatureStore(latency time.Duration) *MockFeatureStore {
	return &MockFeatureStore{
		data:    make(map[string]float64),
		latency: latency,
	}
}

func (m *MockFeatureStore) SeedData(key string, value float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.data[key] = value
}

func (m *MockFeatureStore) SetLatency(l time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.latency = l
}

func (m *MockFeatureStore) FetchFeatures(ctx context.Context, keys []string) (map[string]float64, error) {
	m.mu.RLock()
	latency := m.latency
	fail := m.simulateError
	m.mu.RUnlock()

	if fail {
		return nil, errors.New("underlying database connection refused")
	}

	select {
	case <-time.After(latency):
		m.mu.RLock()
		defer m.mu.RUnlock()
		res := make(map[string]float64)
		for _, k := range keys {
			if val, ok := m.data[k]; ok {
				res[k] = val
			} else {
				res[k] = 0.0 // Default or NaN
			}
		}
		return res, nil
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

// EnrichmentConfig is distinct per tenant.
type EnrichmentConfig struct {
	Timeout          time.Duration
	TimeoutBehavior  EnrichmentTimeoutBehavior
	RequiredFeatures []string
}

// FeatureEnricher intercepts raw arrays and backfills them from external state.
type FeatureEnricher struct {
	Store FeatureStore
}

func NewFeatureEnricher(store FeatureStore) *FeatureEnricher {
	return &FeatureEnricher{Store: store}
}

// Enrich dynamically merges client payload with authoritative DB state.
func (fe *FeatureEnricher) Enrich(ctx context.Context, payload []float64, cfg EnrichmentConfig) ([]float64, error) {
	if len(cfg.RequiredFeatures) == 0 {
		return payload, nil // No enrichment required
	}

	// Wait loop for TimeoutQueue behavior (Retries)
	for {
		enrichCtx, cancel := context.WithTimeout(ctx, cfg.Timeout)
		fetched, err := fe.Store.FetchFeatures(enrichCtx, cfg.RequiredFeatures)
		cancel()

		if err == nil {
			// Success! Merge fetched features into the array.
			// (Assuming the model signature expects client features first, then DB features)
			enrichedPayload := make([]float64, len(payload))
			copy(enrichedPayload, payload)

			for _, key := range cfg.RequiredFeatures {
				enrichedPayload = append(enrichedPayload, fetched[key])
			}
			return enrichedPayload, nil
		}

		// Analysis of Failure Route
		if errors.Is(err, context.DeadlineExceeded) || err != nil {
			switch cfg.TimeoutBehavior {
			case TimeoutReject:
				return nil, fmt.Errorf("%w: %v", ErrEnrichmentTimeout, err)

			case TimeoutProceedPartial:
				fmt.Println("[ENRICHMENT] Warning: Core DB timed out. Proceeding strictly with partial/zeroed client vectors.")
				// We inject zeros (or NaNs) to satisfy the Tensor dimension signature
				enrichedPayload := make([]float64, len(payload))
				copy(enrichedPayload, payload)
				for range cfg.RequiredFeatures {
					enrichedPayload = append(enrichedPayload, 0.0) // Fill with defaults
				}
				return enrichedPayload, nil

			case TimeoutQueue:
				fmt.Printf("[ENRICHMENT] Delaying inference. Redis timeout... Retrying fetch layer in 500ms.\n")
				select {
				case <-time.After(500 * time.Millisecond):
					continue // Try the fetch loop again!
				case <-ctx.Done():
					return nil, fmt.Errorf("client abandoned request during prolonged enrichment queuing")
				}
			}
		}
	}
}
