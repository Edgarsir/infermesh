package gateway

import (
	"crypto/rsa"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// AuthConfig holds validation parameters including multiple keys for rotation.
type AuthConfig struct {
	Issuer string
	// Keys maps Key ID ('kid') to the RSA Public Key.
	// This allows smooth rollover where old tokens signed by KID '1' are accepted
	// while new tokens are signed with KID '2'.
	Keys map[string]*rsa.PublicKey
}

// TokenValidator enforces rigorous JWT security checks & seamless key rotation.
type TokenValidator struct {
	mu     sync.RWMutex
	config AuthConfig
}

func NewTokenValidator(cfg AuthConfig) *TokenValidator {
	if cfg.Keys == nil {
		cfg.Keys = make(map[string]*rsa.PublicKey)
	}
	return &TokenValidator{config: cfg}
}

// UpdateKeys allows dynamic key rotation by an admin background process
// without restarting the server or breaking in-flight sessions.
func (v *TokenValidator) UpdateKeys(newKeys map[string]*rsa.PublicKey) {
	v.mu.Lock()
	defer v.mu.Unlock()
	v.config.Keys = newKeys
}

// Custom Claims
type TenantClaims struct {
	TenantID string `json:"tenant_id"`
	jwt.RegisteredClaims
}

// VerifyToken performs the 5 checks: Sig, Alg, Exp, Iss, Tenant.
func (v *TokenValidator) VerifyToken(tokenString string) (*TenantClaims, error) {
	// 1. Parsing with Algorithm Check (RS256 ONLY) & Key ID Lookup
	token, err := jwt.ParseWithClaims(tokenString, &TenantClaims{}, func(token *jwt.Token) (interface{}, error) {
		// A. Algorithm Check
		// Reject 'none', 'HS256', etc.
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v (Only RS256 allowed)", token.Header["alg"])
		}
		
		// B. Key ID Extraction
		kidInter, ok := token.Header["kid"]
		if !ok {
			return nil, fmt.Errorf("missing 'kid' (Key ID) header in JWT")
		}
		
		kid, ok := kidInter.(string)
		if !ok {
			return nil, fmt.Errorf("invalid 'kid' format")
		}

		// C. Thread-safe Key Lookup during active rotation
		v.mu.RLock()
		defer v.mu.RUnlock()
		
		pubKey, exists := v.config.Keys[kid]
		if !exists {
			return nil, fmt.Errorf("unknown key ID '%s', possibly expired/rotated out", kid)
		}
		
		return pubKey, nil
	})

	if err != nil {
		return nil, fmt.Errorf("token parsing error: %w", err)
	}

	// 2. Validate Signature (Implicit in ParseWithClaims return)
	if !token.Valid {
		return nil, errors.New("signature verification failed")
	}

	claims, ok := token.Claims.(*TenantClaims)
	if !ok {
		return nil, errors.New("invalid claims structure")
	}

	// 3. Expiry Check (Handled by jwt library usually, but explicit check here)
	if time.Now().After(claims.ExpiresAt.Time) {
		return nil, errors.New("token expired")
	}

	// 4. Issuer Check
	if claims.Issuer != v.config.Issuer {
		return nil, fmt.Errorf("issuer mismatch: got %s, want %s", claims.Issuer, v.config.Issuer)
	}

	// 5. Tenant ID Check
	if claims.TenantID == "" {
		return nil, errors.New("missing tenant_id claim")
	}

	return claims, nil
}
