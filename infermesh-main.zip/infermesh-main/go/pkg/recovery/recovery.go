package recovery

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"d/startup-plan/infermesh/go/pkg/registry"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// PersistenceStore defines the interface for durable database storage.
type PersistenceStore interface {
	LoadAllTenants() ([]registry.TenantConfig, error)
	// Other methods (Deploy history, etc) omitted for brevity
}

// CoordinatorRecovery manages the state reconstruction when the Go process restarts.
type CoordinatorRecovery struct {
	DB   PersistenceStore
	Reg  *registry.Registry
	Pool *worker.Pool
	
	WorkerSocketsDir string // e.g. /tmp/
}

func NewRecoveryManager(db PersistenceStore, reg *registry.Registry, pool *worker.Pool, socketDir string) *CoordinatorRecovery {
	return &CoordinatorRecovery{
		DB:               db,
		Reg:              reg,
		Pool:             pool,
		WorkerSocketsDir: socketDir,
	}
}

// Recover handles the entire startup logic.
// MUST complete before bringing up the Gateway HTTP/gRPC listeners.
func (cr *CoordinatorRecovery) Recover(ctx context.Context) error {
	fmt.Println("[RECOVERY] Starting Go Coordinator State Reconstruction...")

	// 1. Authoritative State: Rebuild Registry from DB 
	tenants, err := cr.DB.LoadAllTenants()
	if err != nil {
		return fmt.Errorf("failed to load tenant registry from DB: %w", err)
	}

	for _, t := range tenants {
		cr.Reg.UpdateTenant(t)
	}
	fmt.Printf("[RECOVERY] Loaded %d tenants from database.\n", len(tenants))

	// 2. Orphan Adoption: Discover existing C++ Workers
	// Go crashed, but C++ processes kept running. We find them via socket files.
	// We assume convention: /tmp/infermesh_worker_{id}.sock
	
	entries, err := os.ReadDir(cr.WorkerSocketsDir)
	if err != nil {
		return fmt.Errorf("failed to read sockets dir: %w", err)
	}

	recoveredWorkers := 0
	
	for _, entry := range entries {
		name := entry.Name()
		if strings.HasPrefix(name, "infermesh_worker_") && strings.HasSuffix(name, ".sock") {
			// Extract ID
			idStr := strings.TrimSuffix(strings.TrimPrefix(name, "infermesh_worker_"), ".sock")
			var id int
			fmt.Sscanf(idStr, "%d", &id)

			socketPath := filepath.Join(cr.WorkerSocketsDir, name)

			// Create skeletal Worker struct
			w := &worker.Worker{
				ID:     id,
				Socket: socketPath,
				State:  "UNKNOWN",
				// Note: Cmd/Process handle is lost because it's a new Go process tree.
				// We can't monitor its exit via Go's exec.Cmd anymore.
				// We rely strictly on Health Checks dropping it if it dies.
			}

			// 3. Health Check to verify it's actually alive (not a stale socket file)
			// Mock Health Client
			// if w.PerformHealthCheck(ctx) { ... }
			
			// For this logic plan, we assume we ping it:
			isAlive := mockPingSocket(socketPath)
			
			if isAlive {
				w.Healthy = true
				w.State = "HEALTHY"
				
				cr.Pool.Mu.Lock()
				cr.Pool.Workers = append(cr.Pool.Workers, w)
				cr.Pool.Mu.Unlock()
				
				fmt.Printf("[RECOVERY] Adopted existing worker %d on %s\n", id, socketPath)
				recoveredWorkers++
			} else {
				// Dead socket from previous messy shutdown, clean it up
				os.Remove(socketPath)
				fmt.Printf("[RECOVERY] Cleaned up stale socket %s\n", socketPath)
			}
		}
	}

	fmt.Printf("[RECOVERY] Complete. Re-adopted %d orphan workers.\n", recoveredWorkers)
	return nil
}

func mockPingSocket(path string) bool {
	// Real logic: attempt Dial("unix", path)
	// For simulation: we assume "alive" if the file name contains "99" (just for testing logic)
	return strings.Contains(path, "99")
}
