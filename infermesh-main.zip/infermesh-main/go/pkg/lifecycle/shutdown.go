package lifecycle

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"
)

// GoServer defines an interface to stop HTTP listeners gracefully.
type GoServer interface {
	Shutdown(ctx context.Context) error
}

// LogFlusher ensures asynchronous I/O buffered logs are written.
type LogFlusher interface {
	Flush() error
}

// DistributedLock ensures if Go dies mid-deployment, the staging lock isn't held forever.
type DistributedLock interface {
	ReleaseIfHeld() error
}

// ShutdownManager orchestrates Go's graceful exit to preserve in-flight inferences.
type ShutdownManager struct {
	GatewayServer GoServer
	AdminServer   GoServer
	Logger        LogFlusher
	DeployLock    DistributedLock

	// Atomic flag to signal load balancer health checks to start failing.
	isDraining int32
}

func NewShutdownManager(gateway, admin GoServer, logger LogFlusher, lock DistributedLock) *ShutdownManager {
	return &ShutdownManager{
		GatewayServer: gateway,
		AdminServer:   admin,
		Logger:        logger,
		DeployLock:    lock,
	}
}

// ListenAndServe blocks until a termination signal is received.
func (sm *ShutdownManager) ListenAndServe() {
	stopChan := make(chan os.Signal, 1)
	// Catch standard termination signals from Kubernetes or the OS
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)

	// Block here
	sig := <-stopChan
	fmt.Printf("\n[SHUTDOWN] Received signal: %v. Initiating graceful drain...\n", sig)

	// 1. Signal Load Balancer (Fail Readiness Probes)
	// This immediately takes Go out of the upstream LB pool.
	atomic.StoreInt32(&sm.isDraining, 1)

	// In production, we yield briefly to give the network hardware 
	// (like AWS ALB or kube-proxy) time to notice the failed health check 
	// and stop routing NEW TCP connections here before we actually close the listener.
	time.Sleep(2 * time.Second)

	// 2. Stop Accepting Connections & Drain In-Flight Requests
	// We give the server 10 seconds to finish currently processing inference requests.
	// Since inference max is ~1s usually, 10s is a generous safety net.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	fmt.Println("[SHUTDOWN] Closing HTTP listeners and waiting for in-flight requests to complete...")

	// Ideally execute shutdowns concurrently
	errChan := make(chan error, 2)
	go func() {
		errChan <- sm.GatewayServer.Shutdown(ctx)
	}()
	go func() {
		if sm.AdminServer != nil {
			errChan <- sm.AdminServer.Shutdown(ctx)
		} else {
			errChan <- nil
		}
	}()

	for i := 0; i < 2; i++ {
		if err := <-errChan; err != nil {
			fmt.Printf("[WARN] Server shutdown error or timeout: %v\n", err)
		}
	}

	// 3. Flush Observability Telemetry
	fmt.Println("[SHUTDOWN] Flushing asynchronous trace/metric logs to disk...")
	if sm.Logger != nil {
		if err := sm.Logger.Flush(); err != nil {
			fmt.Printf("[WARN] Log flush failed: %v\n", err)
		}
	}

	// 4. Release Distributed Write Locks
	// Crucial if Go dies while copying a 10GB deployment artifact.
	if sm.DeployLock != nil {
		fmt.Println("[SHUTDOWN] Releasing deployment global lock...")
		sm.DeployLock.ReleaseIfHeld()
	}

	fmt.Println("[SHUTDOWN] Graceful exit complete. C++ workers remain running.")
	// Binary exits naturally now.
}

// HealthCheckHandler exposes the readiness state to ALBs or Kubernetes.
func (sm *ShutdownManager) HealthCheckHandler(w http.ResponseWriter, r *http.Request) {
	if atomic.LoadInt32(&sm.isDraining) == 1 {
		// During shutdown, we explicitly tell the LB we are unavailable.
		http.Error(w, "Node draining, refusing traffic", http.StatusServiceUnavailable)
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
}
