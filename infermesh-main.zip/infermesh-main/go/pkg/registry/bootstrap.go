package registry

import (
	"fmt"
)

const (
	StatusPendingModel = "PENDING_MODEL"
	StatusActive       = "ACTIVE"
	StatusSuspended    = "SUSPENDED"
)

// Registrar manages the lifecycle transitions of tenant accounts.
type Registrar struct {
	Registry *Registry
	// In reality, this would also hold a reference to the Worker Pool Manager
	// to trigger the actual spawning of workers once activated.
}

func NewRegistrar(r *Registry) *Registrar {
	return &Registrar{Registry: r}
}

// RegisterNewTenant creates the account but halts any compute provisioning.
// The tenant is placed in 'PENDING_MODEL' state.
// If a client attempts an inference now, they receive a strict "model not ready" error.
func (r *Registrar) RegisterNewTenant(tenantID string, tier string, minWorkers, maxWorkers int) error {
	if existing := r.Registry.GetTenant(tenantID); existing != nil {
		return fmt.Errorf("tenant %s already exists", tenantID)
	}

	cfg := TenantConfig{
		TenantID:     tenantID,
		Status:       StatusPendingModel, // <--- Key Architectural State
		BillingTier:  tier,
		MinWorkers:   minWorkers,
		MaxWorkers:   maxWorkers,
		ModelVersion: "none",
	}

	r.Registry.UpdateTenant(cfg)
	fmt.Printf("[BOOTSTRAP] Registered Tenant %s in PENDING_MODEL state. Awaiting artifact upload.\n", tenantID)
	return nil
}

// ActivateTenantModel is called exclusively by the Deployment/Webhook layer
// ONLY after a model artifact is successfully downloaded to S3, validated, and hashed.
func (r *Registrar) ActivateTenantModel(tenantID, version, hash string) error {
	cfg := r.Registry.GetTenant(tenantID)
	if cfg == nil {
		return fmt.Errorf("tenant %s not found", tenantID)
	}

	// Update configuration to active
	cfg.Status = StatusActive
	cfg.ModelVersion = version
	cfg.ModelHash = hash

	r.Registry.UpdateTenant(*cfg)
	fmt.Printf("[BOOTSTRAP] Tenant %s is now ACTIVE (Model %s). Signaling PoolManager to spawn %d workers.\n", 
		tenantID, version, cfg.MinWorkers)
		
	// Here we would call PoolManager.SpawnTargetCapacity(tenantID, cfg.MinWorkers)
	return nil
}

// SuspendTenant triggers an immediate emergency stop (kill-switch) for routing decisions.
// The physical workers are left running (no compute restart penalty), but no traffic can reach them.
func (r *Registrar) SuspendTenant(tenantID, reason string) error {
	cfg := r.Registry.GetTenant(tenantID)
	if cfg == nil {
		return fmt.Errorf("tenant %s not found", tenantID)
	}

	cfg.Status = StatusSuspended
	r.Registry.UpdateTenant(*cfg)
	fmt.Printf("[EMERGENCY] Tenant %s SUSPENDED. Traffic halted instantly. Reason: %s\n", tenantID, reason)
	return nil
}

// ResumeTenant lifts an emergency suspension safely, instantly unblocking routes to the warm hardware.
func (r *Registrar) ResumeTenant(tenantID string) error {
	cfg := r.Registry.GetTenant(tenantID)
	if cfg == nil {
		return fmt.Errorf("tenant %s not found", tenantID)
	}

	cfg.Status = StatusActive
	r.Registry.UpdateTenant(*cfg)
	fmt.Printf("[RECOVERY] Tenant %s is ACTIVE again. Traffic resumed to warm workers.\n", tenantID)
	return nil
}

// EvaluateRequestReadiness intercepts inference API payloads.
func (r *Registrar) EvaluateRequestReadiness(tenantID string) (bool, string) {
	cfg := r.Registry.GetTenant(tenantID)
	if cfg == nil {
		return false, "Tenant not found"
	}

	if cfg.Status == StatusPendingModel {
		// Differentiates from a standard 503 "Workers Unavailable". 
		// Returns a code (like 409 Conflict) informing the client sdk to WAIT, not infinitely retry.
		return false, "Model configuration pending. Please finalize CI/CD artifact upload before sending inference traffic."
	}
	
	if cfg.Status == StatusSuspended {
		return false, "Tenant account is suspended due to an administrative or safety hold."
	}
	
	if cfg.Status != StatusActive {
		return false, "Tenant account is invalid."
	}

	return true, ""
}
