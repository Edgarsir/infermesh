package registry

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// ConsistencyLayer wraps the Registry with Cache TTL and DB-Fetch Logic.
type ConsistencyLayer struct {
	BaseRegistry *Registry
	DBFetchFunc  func(string) (*TenantConfig, error) // Mockable fetcher
	CacheTTL     time.Duration
	
	// Cache expiration tracking
	expirations map[string]time.Time
	mu          sync.RWMutex
}

func NewConsistencyLayer(reg *Registry, ttl time.Duration, fetcher func(string) (*TenantConfig, error)) *ConsistencyLayer {
	return &ConsistencyLayer{
		BaseRegistry: reg,
		DBFetchFunc:  fetcher,
		CacheTTL:     ttl,
		expirations:  make(map[string]time.Time),
	}
}

// GetTenantWithCache handles the read-through logic: Check Memory -> If Stale/Missing -> Fetch DB -> Update Memory.
func (c *ConsistencyLayer) GetTenantWithCache(ctx context.Context, id string) (*TenantConfig, error) {
	// 1. Check Memory (RLock)
	c.mu.RLock()
	expiry, exists := c.expirations[id]
	c.mu.RUnlock()

	// 2. If valid cache hit
	if exists && time.Now().Before(expiry) {
		// Fast path: pure memory read
		return c.BaseRegistry.GetTenant(id), nil
	}

	// 3. Cache Miss or Update Needed (Double-Check Locking pattern)
	c.mu.Lock()
	defer c.mu.Unlock()

	// Re-check in case another goroutine just updated it
	if expiry, exists = c.expirations[id]; exists && time.Now().Before(expiry) {
		return c.BaseRegistry.GetTenant(id), nil
	}

	// 4. Fetch from Source of Truth (DB)
	// This simulates the latency of SQL query
	fmt.Printf("[CACHE] Miss/Expire for %s. Fetching from DB...\n", id)
	cfg, err := c.DBFetchFunc(id)
	if err != nil {
		return nil, err
	}
	if cfg == nil {
		return nil, fmt.Errorf("tenant not found")
	}

	// 5. Update Memory Cache
	c.BaseRegistry.UpdateTenant(*cfg)
	c.expirations[id] = time.Now().Add(c.CacheTTL)
	
	return cfg, nil
}

// Invalidate explicitly forces a refresh on next read (e.g. triggered by webhook/pubsub).
func (c *ConsistencyLayer) Invalidate(id string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	delete(c.expirations, id)
	fmt.Printf("[CACHE] Invalidated %s\n", id)
}
