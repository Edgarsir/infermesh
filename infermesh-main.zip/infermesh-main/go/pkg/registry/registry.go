package registry

import (
	"sync"
	"fmt"
)

// TenantConfig defines the operational parameters for a tenant.
type TenantConfig struct {
	TenantID          string
	Status            string // e.g., "PENDING_MODEL", "ACTIVE"
	ModelVersion      string
	ModelHash         string // Strict integrity check
	
	// Pool Sizing
	MinWorkers        int
	MaxWorkers        int
	
	// Policy
	RateLimitRPS      int
	BillingTier       string // "pro", "enterprise", "starter"
}

// Registry is the thread-safe, high-speed lookup table.
type Registry struct {
	tenants map[string]*TenantConfig
	mu      sync.RWMutex
}

func NewRegistry() *Registry {
	return &Registry{
		tenants: make(map[string]*TenantConfig),
	}
}

// GetTenant returns a copy of the config to ensure thread safety for the caller.
// Returns nil if not found.
func (r *Registry) GetTenant(id string) *TenantConfig {
	r.mu.RLock()
	defer r.mu.RUnlock()
	
	cfg, ok := r.tenants[id]
	if !ok {
		return nil
	}
	// Return copy
	c := *cfg
	return &c
}

// UpdateTenant allows dynamic updates (e.g. after a deployment or plan upgrade).
func (r *Registry) UpdateTenant(cfg TenantConfig) {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	// Clone to store
	c := cfg
	r.tenants[cfg.TenantID] = &c
	fmt.Printf("[REGISTRY] Updated config for tenant %s (Ver: %s)\n", cfg.TenantID, cfg.ModelVersion)
}

// RemoveTenant handles account deletion or suspension.
func (r *Registry) RemoveTenant(id string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.tenants, id)
}
