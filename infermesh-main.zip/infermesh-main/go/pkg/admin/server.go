package admin

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	"d/startup-plan/infermesh/go/pkg/registry"
	"d/startup-plan/infermesh/go/pkg/worker"
)

// AdminServer exposes management endpoints securely via mTLS.
type AdminServer struct {
	Registry *registry.Registry
	Pool     *worker.Pool
	// Add deployment manager or history logger as needed
}

func NewAdminServer(reg *registry.Registry, pool *worker.Pool) *AdminServer {
	return &AdminServer{
		Registry: reg,
		Pool:     pool,
	}
}

// Start launches the mTLS HTTP server.
func (s *AdminServer) Start(port int, serverCert, serverKey, caCertFile string) error {
	// 1. Load CA cert to verify clients
	caCert, err := ioutil.ReadFile(caCertFile)
	if err != nil {
		return fmt.Errorf("failed to read CA cert: %w", err)
	}
	caCertPool := x509.NewCertPool()
	if ok := caCertPool.AppendCertsFromPEM(caCert); !ok {
		return fmt.Errorf("failed to append CA cert")
	}

	// 2. Configure mTLS
	tlsConfig := &tls.Config{
		ClientCAs:  caCertPool,
		ClientAuth: tls.RequireAndVerifyClientCert, // Critical: Enforce mTLS
		MinVersion: tls.VersionTLS13,
	}

	mux := http.NewServeMux()
	
	// 3. Register Routes
	mux.HandleFunc("/admin/tenants", s.handleRegisterTenant) // POST
	mux.HandleFunc("/admin/status", s.handleGetStatus)       // GET
	mux.HandleFunc("/admin/workers/drain", s.handleDrainWorker) // POST

	server := &http.Server{
		Addr:      fmt.Sprintf(":%d", port),
		TLSConfig: tlsConfig,
		Handler:   mux,
	}

	fmt.Printf("[ADMIN] Starting mTLS Admin API on port %d\n", port)
	return server.ListenAndServeTLS(serverCert, serverKey)
}

// ---- Handlers ----

func (s *AdminServer) handleRegisterTenant(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var cfg registry.TenantConfig
	if err := json.NewDecoder(r.Body).Decode(&cfg); err != nil {
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	// In reality: Trigger worker pool provisioning here asynchronously
	s.Registry.UpdateTenant(cfg)
	
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte(`{"status": "tenant registered"}`))
}

func (s *AdminServer) handleGetStatus(w http.ResponseWriter, r *http.Request) {
	// Iterate pool and summarize status
	// For simplicity, returning mock JSON
	status := map[string]interface{}{
		"total_workers": len(s.Pool.Workers),
		"healthy":       0,
	}
	for _, wrk := range s.Pool.Workers {
		if wrk.Healthy {
			status["healthy"] = status["healthy"].(int) + 1
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

func (s *AdminServer) handleDrainWorker(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// In reality: Parse worker ID from URL query or body
	// Transition worker state to DRAINING, wait for in-flight=0, then kill.
	
	workerID := r.URL.Query().Get("id")
	if strings.TrimSpace(workerID) == "" {
		http.Error(w, "Missing worker ID", http.StatusBadRequest)
		return
	}

	fmt.Printf("[ADMIN] Draining and killing worker %s\n", workerID)
	w.Write([]byte(fmt.Sprintf(`{"status": "worker %s draining"}`, workerID)))
}
