package config

import (
	"fmt"
	"sync"
)

// AppConfig represents global dynamic settings that can change at runtime.
type AppConfig struct {
	MaxWorkers   int
	MinWorkers   int
	RateLimitRPS int
	TLSCertPath  string
}

// ConfigListener defines callbacks for subsystems affected by configuration changes.
type ConfigListener interface {
	OnWorkerLimitsChanged(min, max int)
	OnRateLimitChanged(rps int)
	OnTLSCertChanged(path string)
}

// ConfigManager handles the thread-safe loading, validation, and hot-swapping
// of application configurations without requiring an OS process restart.
type ConfigManager struct {
	mu            sync.RWMutex
	currentConfig AppConfig
	listeners     []ConfigListener
}

func NewConfigManager(initial AppConfig) *ConfigManager {
	return &ConfigManager{
		currentConfig: initial,
		listeners:     make([]ConfigListener, 0),
	}
}

// RegisterListener allows subsystems (like Router, RateLimiter, TLS server) to subscribe to hot-reloads.
func (cm *ConfigManager) RegisterListener(l ConfigListener) {
	cm.mu.Lock()
	defer cm.mu.Unlock()
	cm.listeners = append(cm.listeners, l)
}

// GetConfig returns a safe copy of the current configuration.
func (cm *ConfigManager) GetConfig() AppConfig {
	cm.mu.RLock()
	defer cm.mu.RUnlock()
	return cm.currentConfig
}

// Reload validates and applies a new configuration dynamically.
func (cm *ConfigManager) Reload(newCfg AppConfig) error {
	// 1. Strict Validation Phase (Preventing unserviceable state)
	if err := validateConfig(newCfg); err != nil {
		fmt.Printf("[ALERT] 🚨 CRITICAL: Invalid configuration rejected! System retains previous healthy state. Reason: %v\n", err)
		return err // Discard newCfg, maintain currentCfg
	}

	cm.mu.Lock()
	oldCfg := cm.currentConfig
	cm.currentConfig = newCfg
	// Capture listeners to avoid holding the lock during slow callbacks
	listeners := make([]ConfigListener, len(cm.listeners))
	copy(listeners, cm.listeners)
	cm.mu.Unlock()

	fmt.Println("[HOT-RELOAD] Valid configuration ingested. Executing intelligent zero-downtime subsystem swaps...")

	// 2. Surgical Notification Phase
	// Only reload the exact subsystems that actually mutated.
	for _, listener := range listeners {
		if newCfg.MinWorkers != oldCfg.MinWorkers || newCfg.MaxWorkers != oldCfg.MaxWorkers {
			listener.OnWorkerLimitsChanged(newCfg.MinWorkers, newCfg.MaxWorkers)
		}
		if newCfg.RateLimitRPS != oldCfg.RateLimitRPS {
			listener.OnRateLimitChanged(newCfg.RateLimitRPS)
		}
		if newCfg.TLSCertPath != oldCfg.TLSCertPath {
			listener.OnTLSCertChanged(newCfg.TLSCertPath)
		}
	}

	return nil
}

// validateConfig enforces structural constraints on the operational variables.
func validateConfig(cfg AppConfig) error {
	if cfg.MaxWorkers <= 0 {
		return fmt.Errorf("MaxWorkers must be > 0. (Got: %d)", cfg.MaxWorkers)
	}
	if cfg.MinWorkers < 0 {
		return fmt.Errorf("MinWorkers cannot be negative. (Got: %d)", cfg.MinWorkers)
	}
	if cfg.MinWorkers > cfg.MaxWorkers {
		return fmt.Errorf("MinWorkers (%d) cannot exceed MaxWorkers (%d)", cfg.MinWorkers, cfg.MaxWorkers)
	}
	if cfg.RateLimitRPS < 0 {
		return fmt.Errorf("RateLimitRPS cannot be negative. (Got: %d)", cfg.RateLimitRPS)
	}
	if cfg.TLSCertPath == "" {
		return fmt.Errorf("TLSCertPath cannot be empty")
	}
	return nil
}
