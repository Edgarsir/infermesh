package chaos

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var ErrChaosDisabled = errors.New("chaos engineering API is rigidly disabled in this environment")

// Config flags the availability of catastrophic testing endpoints.
// In actual production, this must be aggressively set to False via env variables or compile-time flags.
type Config struct {
	EnableChaosAPI bool
}

// TargetSystem interfaces with the physical layers of the Go Orchestrator 
// to execute controlled demolition and regression testing.
type TargetSystem interface {
	KillWorker(workerID string) error
	GetActiveWorkers() []string
	InjectSocketLatency(latency time.Duration)
	SimulateQueueSpike(depth int32)
	SimulateS3Failure(state bool)
}

// MockTargetSystem is used for our test harnesses to validate the Chaos engine.
type MockTargetSystem struct {
	mu             sync.Mutex
	ActiveWorkers  []string
	SocketLatency  time.Duration
	QueueDepth     int32
	S3Failing      bool
}

func NewMockTargetSystem() *MockTargetSystem {
	return &MockTargetSystem{
		ActiveWorkers: []string{"worker-0", "worker-1", "worker-2", "worker-3"},
	}
}

func (m *MockTargetSystem) KillWorker(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	for i, w := range m.ActiveWorkers {
		if w == id {
			// Remove from slice
			m.ActiveWorkers = append(m.ActiveWorkers[:i], m.ActiveWorkers[i+1:]...)
			fmt.Printf(" [SYSTEM] SIGKILL executed against PID/Worker: %s\n", id)
			return nil
		}
	}
	return fmt.Errorf("worker %s not found", id)
}

func (m *MockTargetSystem) GetActiveWorkers() []string {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.ActiveWorkers
}

func (m *MockTargetSystem) InjectSocketLatency(latency time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.SocketLatency = latency
	fmt.Printf(" [SYSTEM] Unix Socket I/O mathematically delayed by %v\n", latency)
}

func (m *MockTargetSystem) SimulateQueueSpike(depth int32) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.QueueDepth = depth
	fmt.Printf(" [SYSTEM] Gateway Dispatch Channel artificially bloated to %d depth\n", depth)
}

func (m *MockTargetSystem) SimulateS3Failure(state bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.S3Failing = state
	status := "RECOVERED"
	if state {
		status = "FAILING"
	}
	fmt.Printf(" [SYSTEM] External S3 Storage Gateway marked as: %s\n", status)
}

// API handles incoming admin requests mapped securely via mTLS.
type API struct {
	cfg    Config
	target TargetSystem
}

func NewAPI(cfg Config, target TargetSystem) *API {
	return &API{
		cfg:    cfg,
		target: target,
	}
}

// TriggerRandomWorkerKill simulates random hardware/kernel failures.
func (a *API) TriggerRandomWorkerKill() error {
	if !a.cfg.EnableChaosAPI {
		return ErrChaosDisabled
	}

	workers := a.target.GetActiveWorkers()
	if len(workers) == 0 {
		return errors.New("no active workers to kill")
	}

	// Pick a random worker to assassinate
	idx := rand.Intn(len(workers))
	target := workers[idx]

	fmt.Printf("[CHAOS] API Authorized. Triggering assassination of %s...\n", target)
	return a.target.KillWorker(target)
}

// TriggerSocketLatency simulates severe I/O degradation or CPU throttling on the target machine.
func (a *API) TriggerSocketLatency(latencyMs int) error {
	if !a.cfg.EnableChaosAPI {
		return ErrChaosDisabled
	}
	fmt.Printf("[CHAOS] API Authorized. Injecting %dms I/O latency to simulate extreme CPU contention...\n", latencyMs)
	a.target.InjectSocketLatency(time.Duration(latencyMs) * time.Millisecond)
	return nil
}

// TriggerQueueSpike simulates a sudden thundering herd traffic spike violating all bounds.
func (a *API) TriggerQueueSpike(dummyRequests int32) error {
	if !a.cfg.EnableChaosAPI {
		return ErrChaosDisabled
	}
	fmt.Printf("[CHAOS] API Authorized. Simulating Thundering Herd Spike (%d requests)...\n", dummyRequests)
	a.target.SimulateQueueSpike(dummyRequests)
	return nil
}

// TriggerS3Failure mathematically severs the cross-region storage linkage.
func (a *API) TriggerS3Failure(isFailing bool) error {
	if !a.cfg.EnableChaosAPI {
		return ErrChaosDisabled
	}
	fmt.Printf("[CHAOS] API Authorized. Toggling S3 Disaster state to %v...\n", isFailing)
	a.target.SimulateS3Failure(isFailing)
	return nil
}
