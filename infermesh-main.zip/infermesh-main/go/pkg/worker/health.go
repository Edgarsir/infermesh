package worker

import (
	"context"
	"fmt"
	"time"
)

// Constants for Health Logic
const (
	HealthCheckInterval = 500 * time.Millisecond
	HealthCheckTimeout  = 300 * time.Millisecond
	MaxFailures         = 3
	MaxMemoryBytes      = 12 * 1024 * 1024 * 1024 // e.g. 12GB panic threshold
)

// PerformHealthCheck executes a single verification logic.
// Returns true if healthy, false if failed.
func (w *Worker) PerformHealthCheck(ctx context.Context) bool {
	w.mu.Lock()
	defer w.mu.Unlock()

	// 1. Skip if already dead
	if w.State == StatusDead {
		return false
	}

	// 2. Setup Context with strict 300ms timeout
	checkCtx, cancel := context.WithTimeout(ctx, HealthCheckTimeout)
	defer cancel()

	// 3. Call gRPC (Mocked via Interface)
	if w.HealthClient == nil {
		// In real app, we'd Dial() here if nil, or panic. 
		// For prototype, assume it's set.
		w.recordFailure("No health client connection")
		return false
	}

	hash, memUsage, err := w.HealthClient.CheckHealth(checkCtx)
	
	// 4. Validate Response
	if err != nil {
		w.recordFailure(fmt.Sprintf("RPC Error: %v", err))
		return false
	}

	if hash != w.ExpectedModelHash {
		w.recordFailure(fmt.Sprintf("Hash Mismatch: got %s, want %s", hash, w.ExpectedModelHash))
		return false
	}

	if memUsage > MaxMemoryBytes {
		w.recordFailure(fmt.Sprintf("Memory Unsafe: %d bytes", memUsage))
		// Optional: Trigger restart immediately?
		return false
	}

	// 5. Success Logic
	w.ConsecutiveFailures = 0
	// fmt.Printf("[HEALTH] Worker %d OK.\n", w.ID)
	return true
}

func (w *Worker) recordFailure(reason string) {
	w.ConsecutiveFailures++
	fmt.Printf("[HEALTH] Worker %d Check Failed (%d/%d): %s\n", w.ID, w.ConsecutiveFailures, MaxFailures, reason)

	if w.ConsecutiveFailures >= MaxFailures {
		w.State = StatusDead
		w.Healthy = false
		fmt.Printf("[HEALTH] Worker %d marked DEAD. Triggering replacement...\n", w.ID)
		// Trigger Pool replacement logic here (via channel or callback)
	}
}

// StartHealthMonitor runs the continuous health loop for the pool.
// This would be run as a goroutine: go pool.StartHealthMonitor(ctx)
func (p *Pool) StartHealthMonitor(ctx context.Context) {
	ticker := time.NewTicker(HealthCheckInterval)
	defer ticker.Stop()

	fmt.Println("[POOL] Health Monitor Started.")

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			// Iterate all workers
			p.mu.Lock()
			workers := make([]*Worker, len(p.Workers))
			copy(workers, p.Workers)
			p.mu.Unlock()

			for _, w := range workers {
				// Only check HEALTHY workers (ignore STARTING/DEAD)
				// We need to lock to read state, or use atomic
				w.mu.Lock()
				state := w.State
				w.mu.Unlock()

				if state == StatusReady || state == "HEALTHY" {
					w.PerformHealthCheck(ctx)
				}
			}
		}
	}
}
