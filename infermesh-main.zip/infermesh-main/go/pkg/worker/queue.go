package worker

import (
	"context"
	"errors"
	"sync"
	"time"
)

// ErrQueueFull is returned when we shed load.
var ErrQueueFull = errors.New("request queue full (load shedding)")

// TimeoutErr is returned when a specific request waits too long.
var ErrQueueTimeout = errors.New("request timed out in queue")

// PendingRequest wraps the caller's context and a result channel.
type PendingRequest struct {
	Ctx      context.Context
	Deadline time.Time
	ResultCh chan *Worker // Returns the assigned worker
}

// Queue manages the backlog of requests waiting for execution.
type Queue struct {
	maxSize  int
	// Buffered channel acts as the semaphore/queue combination
	requests chan *PendingRequest
	mu       sync.Mutex
}

func NewQueue(maxSize int) *Queue {
	return &Queue{
		maxSize:  maxSize,
		requests: make(chan *PendingRequest, maxSize),
	}
}

// Enqueue adds a request to the waitlist.
// It blocks until a worker is found OR the context/deadline expires.
func (q *Queue) Enqueue(ctx context.Context, tenantID string) (*Worker, error) {
	// 1. Check Load Shedding (Is Queue Full?)
	// Len of buffered channel is approximate but safe for "shedding"
	if len(q.requests) >= q.maxSize {
		return nil, ErrQueueFull
	}

	// 2. Determine Deadline
	deadline, ok := ctx.Deadline()
	if !ok {
		// Default timeout if none set (safeguard)
		deadline = time.Now().Add(30 * time.Second)
	}

	// 3. Create Ticket
	req := &PendingRequest{
		Ctx:      ctx,
		Deadline: deadline,
		ResultCh: make(chan *Worker, 1), // Buffered to avoid blocking sender
	}

	// 4. Push to Queue (Non-blocking usually due to check above)
	select {
	case q.requests <- req:
		// Successfully queued
	default:
		return nil, ErrQueueFull // Race condition edge case
	}

	// 5. Wait for Worker Assignment
	select {
	case w := <-req.ResultCh:
		return w, nil
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-time.After(time.Until(deadline)):
		return nil, ErrQueueTimeout
	}
}

// TryDequeue attempts to get the next valid request from the queue.
// Called by a worker when it becomes free.
func (q *Queue) TryDequeue() *PendingRequest {
    // Non-blocking dequeue
	select {
	case req := <-q.requests:
		// Check validity (expired?)
		if req.Ctx.Err() != nil || time.Now().After(req.Deadline) {
			// Skip and try recursivly or loop outside
            // For simplicity, just return nil or loop? 
            // Better to loop until valid or empty.
            return q.TryDequeue()
		}
		return req
	default:
		return nil // Queue empty
	}
}
