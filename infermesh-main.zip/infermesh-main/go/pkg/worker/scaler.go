package worker

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// Constants for Scaling
const (
	ScaleUpThreshold         = 50
	ScaleUpDuration          = 2 * time.Second
	ScaleDownIdleDuration    = 60 * time.Second
)

// Scaler manages the dynamic sizing of the Worker Pool.
type Scaler struct {
	pool *Pool
	
	// Metrics
	queueDepth      int
	highLoadStart   time.Time
	lowLoadStart    time.Time
	
	mu sync.Mutex
}

func NewScaler(pool *Pool) *Scaler {
	return &Scaler{
		pool:          pool,
		lowLoadStart:  time.Now(),
	}
}

// UpdateQueueDepth is called periodically with the current queue size.
func (s *Scaler) UpdateQueueDepth(depth int) {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.queueDepth = depth
	now := time.Now()

	// -------------------------------------------------------------------------
	// SCALE UP LOGIC (Hysteresis Check)
	// -------------------------------------------------------------------------
	if depth >= ScaleUpThreshold {
		// If load just started spiking, record start time
		if s.highLoadStart.IsZero() {
			s.highLoadStart = now
		} else if time.Since(s.highLoadStart) > ScaleUpDuration {
			// Persisted load > 2s -> Trigger Scale Up
			s.triggerScaleUp()
			s.highLoadStart = time.Time{} // Reset timer after action
		}
		
		// Reset low load timer since we are high load
		s.lowLoadStart = time.Time{}
	} else {
		// Load dropped below threshold, reset high load timer
		s.highLoadStart = time.Time{}
		
		// ---------------------------------------------------------------------
		// SCALE DOWN LOGIC
		// ---------------------------------------------------------------------
		// Start tracking low load duration if not already
		if s.lowLoadStart.IsZero() {
			s.lowLoadStart = now
		} else if time.Since(s.lowLoadStart) > ScaleDownIdleDuration {
			// Idle > 60s -> Trigger Scale Down
			s.triggerScaleDown()
			s.lowLoadStart = now // Reset to prevent rapid-fire killing
		}
	}
}

func (s *Scaler) triggerScaleUp() {
	current := len(s.pool.Workers) // Should be thread-safe read
	max := s.pool.Config.MaxWorkers

	if current < max {
		fmt.Printf("[SCALER] Queue Depth %d persisted >2s. Scaling UP (%d -> %d)\n", s.queueDepth, current, current+1)
		// Logic to spawn worker (async)
		// In real app: go s.pool.AddWorker()
	} else {
		fmt.Printf("[SCALER] Load high but at MaxWorkers cap (%d). Cannot scale.\n", max)
	}
}

func (s *Scaler) triggerScaleDown() {
	current := len(s.pool.Workers)
	min := s.pool.Config.MinWorkers

	if current > min {
		fmt.Printf("[SCALER] Idle for >60s. Scaling DOWN (%d -> %d)\n", current, current-1)
		// Logic to remove worker (graceful stop)
		// In real app: go s.pool.RemoveWorker()
	}
}
