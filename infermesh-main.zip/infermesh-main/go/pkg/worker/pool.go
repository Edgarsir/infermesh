package worker

import (
	"context"
	"fmt"
	"sync"
	"time"

	"os/exec"
)

// Config defines worker pool parameters.
type Config struct {
	MinWorkers        int
	MaxWorkers        int
	WorkerBinaryPath  string
	ModelPath         string
	StartupTimeout    time.Duration
}

// Worker represents a single C++ process instance.
type Worker struct {
	ID        int
	Process   *LaunchedProcess // Updated to use tracked process
	Socket    string
	Cmd       *exec.Cmd
	ProtoVersion int32
	Healthy   bool
	State     string // "STARTING", "HEALTHY", "DEAD"
	
	// Health Check Fields
	ConsecutiveFailures int
	ExpectedModelHash   string
	mu                  sync.Mutex // Protects state changes
	
	// Mockable Client for Health Checks
	HealthClient interface {
		CheckHealth(ctx context.Context) (string, uint64, error) // Returns (hash, memoryBytes, error)
	}
}

// WaitUntilHealthy uses file polling to detect when C++ is ready.
func (w *Worker) WaitUntilHealthy(ctx context.Context) error {
	// Status file path convention: {socket_path}.status to avoid collisions?
	// OR: {log_dir}/worker_{id}.status. 
	// For simplicity, let's assume it's related to ID.
	// In launcher.go we define logs/worker_N.log. 
	// Ideally, we pass the status file path during launch.
	
	// Convention: /tmp/infermesh_worker_{id}.status matching main.cpp default?
	// Actually, C++ Config.cpp doesn't set status file path from Env.
	// Logger.cpp hardcodes "infermesh_worker.status". 
	// TO FIX: launcher.go should pass INFERMESH_STATUS_FILE env var.
	// For this logic step, we'll assume the path is predictable:
	statusPath := fmt.Sprintf("/tmp/infermesh_worker_%d.status", w.ID)
	
	ready, err := w.WatchStatusFile(ctx, statusPath)
	if err != nil {
		return err
	}
	if !ready {
		return fmt.Errorf("worker failed to reach READY state")
	}
	return nil
}

// Pool manages a collection of Workers.
type Pool struct {
	Config    Config
	Workers   []*Worker
	mu        sync.Mutex
	ready     bool // True only if enough workers are healthy
}

func NewPool(cfg Config) *Pool {
	return &Pool{
		Config:  cfg,
		Workers: make([]*Worker, 0),
	}
}

// Initialize launches the minimum required workers in parallel.
// Returns error only if critical failure (e.g. 0 workers started).
func (p *Pool) Initialize(ctx context.Context) error {
	fmt.Printf("[POOL] Initializing with %d workers (Target Min).\n", p.Config.MinWorkers)
	
	var wg sync.WaitGroup
	errChan := make(chan error, p.Config.MinWorkers)

	// Launch MinWorkers in parallel
	for i := 0; i < p.Config.MinWorkers; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			
			// 1. Create Worker Struct
			w := &Worker{
				ID:       id,
				Socket:   fmt.Sprintf("/tmp/infermesh_worker_%d.sock", id),
				Cmd:      exec.Command(p.Config.WorkerBinaryPath), // Mock: actual exec
			}

			// 2. Start Process (Mocked here, normally verify err)
			// if err := w.Cmd.Start(); err != nil ...
			
			// 3. Wait for Healthy Signal (with timeout from ctx)
			if err := w.WaitUntilHealthy(ctx); err != nil {
				errChan <- fmt.Errorf("worker %d failed startup: %w", id, err)
				return // Don't add to pool
			}

			// 4. Register Healthy Worker safely
			p.mu.Lock()
			p.Workers = append(p.Workers, w)
			p.mu.Unlock()
			fmt.Printf("       Worker %d is HEALTHY.\n", id)

		}(i)
	}

	wg.Wait()
	close(errChan)

	// Check results
	p.mu.Lock()
	defer p.mu.Unlock()

	totalHealthy := len(p.Workers)
	fmt.Printf("[POOL] Initialization complete. %d/%d workers healthy.\n", totalHealthy, p.Config.MinWorkers)

	if totalHealthy == 0 {
		return fmt.Errorf("CRITICAL: 0 workers started successfully. Check binary path or config")
	}

	if totalHealthy < p.Config.MinWorkers {
		fmt.Printf("[WARN] Pool started degraded (%d < %d req). Auto-scaling will attempt recovery later.\n", totalHealthy, p.Config.MinWorkers)
	}

	p.ready = true
	return nil
}
