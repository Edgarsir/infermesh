package worker

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// ProcessKiller defines an interface for sending signals, allowing us to mock 
// OS-level syscall.Kill during testing to avoid actually killing our test runner.
type ProcessKiller interface {
	Kill(pid int, sig syscall.Signal) error
}

type RealProcessKiller struct{}

func (RealProcessKiller) Kill(pid int, sig syscall.Signal) error {
	process, err := os.FindProcess(pid)
	if err != nil {
		return err
	}
	return process.Signal(sig)
}

// WatchdogMonitor oversees the liveliness of a specific C++ Worker PID
// by aggressively checking the atomic timestamp written to the watchdog file.
type WatchdogMonitor struct {
	PID           int
	WatchdogFile  string
	Timeout       time.Duration
	Killer        ProcessKiller
	
	stopCh chan struct{}
}

func NewWatchdogMonitor(pid int, watchdogFile string, timeout time.Duration, killer ProcessKiller) *WatchdogMonitor {
	if killer == nil {
		killer = RealProcessKiller{}
	}
	return &WatchdogMonitor{
		PID:          pid,
		WatchdogFile: watchdogFile,
		Timeout:      timeout,
		Killer:       killer,
		stopCh:       make(chan struct{}),
	}
}

// Start begins the asynchronous polling loop.
func (wm *WatchdogMonitor) Start() {
	go func() {
		ticker := time.NewTicker(time.Second) // Poll every 1 second
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				if !wm.checkHealth() {
					fmt.Printf("[WATCHDOG] C++ Worker (PID: %d) frozen! Terminating via SIGKILL.\n", wm.PID)
					wm.Killer.Kill(wm.PID, syscall.SIGKILL)
					return // End monitor loop since process is dead
				}
			case <-wm.stopCh:
				return // Graceful stop
			}
		}
	}()
}

func (wm *WatchdogMonitor) Stop() {
	close(wm.stopCh)
}

// CheckHealthExported is pure testability wrapper for the unexported logic.
func (wm *WatchdogMonitor) CheckHealthExported() bool {
	return wm.checkHealth()
}

func (wm *WatchdogMonitor) checkHealth() bool {
	// 1. Read the watchdog file
	data, err := os.ReadFile(wm.WatchdogFile)
	if err != nil {
		// Tolerating read errors (e.g. file momentarily locked during write) by not instantly killing.
		// However, if it hasn't written anything in the timeout window, it will fail the Time bounds below eventually.
		stat, statErr := os.Stat(wm.WatchdogFile)
		if statErr == nil {
			if time.Since(stat.ModTime()) > wm.Timeout {
				return false // The file itself hasn't been modified recently
			}
			return true // Unreadable right now, but recently modified. Forgive it.
		}
		// File missing entirely? Might be booting or dead.
		return true 
	}

	content := strings.TrimSpace(string(data))
	epochSec, err := strconv.ParseInt(content, 10, 64)
	if err != nil {
		return true // File garbled (mid-write). Forgive it.
	}

	lastPing := time.Unix(epochSec, 0)
	
	// 2. Validate Heartbeat Freshness
	if time.Since(lastPing) > wm.Timeout {
		return false // It's frozen! Time exceeded.
	}

	return true
}
