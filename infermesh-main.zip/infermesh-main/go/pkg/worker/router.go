package worker

import (
	"context"
	"fmt"
	"sync"
	"time"
    "sync/atomic"
)

// RouterStats tracks load balancing metrics per worker.
type RouterStats struct {
	InFlightRequests int64
	TotalRequests    int64
	LastUsed         int64
}

// Router maintains the map of workers and dispatches requests.
type Router struct {
	pool  *Pool
	stats map[int]*RouterStats // Key: WorkerID
	mu    sync.RWMutex
}

func NewRouter(pool *Pool) *Router {
	return &Router{
		pool:  pool,
		stats: make(map[int]*RouterStats),
	}
}

// SelectWorker implements the Least-Connections algorithm.
func (r *Router) SelectWorker(ctx context.Context, tenantID string) (*Worker, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()

	var bestWorker *Worker
	var minInFlight int64 = -1
	var minTotal int64 = -1

	// Iterate all HEALTHY workers assigned to this tenant
	for _, w := range r.pool.Workers {
		// Use atomic load or mutex if strict consistency needed
        // For router speed, we read boolean directly (assuming eventually consistent)
		if !w.Healthy {
			continue
		}

        // Get Stats
        stat := r.getStats(w.ID)
        if stat == nil { continue }
        
        inFlight := atomic.LoadInt64(&stat.InFlightRequests)
        total := atomic.LoadInt64(&stat.TotalRequests)

		// 1. Initial Selection
		if bestWorker == nil {
			bestWorker = w
			minInFlight = inFlight
			minTotal = total
			continue
		}

		// 2. Least In-Flight Logic
		if inFlight < minInFlight {
			bestWorker = w
			minInFlight = inFlight
			minTotal = total
		} else if inFlight == minInFlight {
			// 3. Tie-Breaker: Least Total Requests (Load Balancer history)
			if total < minTotal {
				bestWorker = w
				minInFlight = inFlight
				minTotal = total
			}
		}
	}

	if bestWorker == nil {
		return nil, fmt.Errorf("no healthy workers available for tenant %s", tenantID)
	}

	// 4. Update Stats (Optimistic Application)
	stat := r.getStats(bestWorker.ID)
    if stat != nil {
	    atomic.AddInt64(&stat.InFlightRequests, 1)
	    atomic.AddInt64(&stat.TotalRequests, 1)
    }

	return bestWorker, nil
}

// ReleaseWorker decrements the in-flight count.
func (r *Router) ReleaseWorker(w *Worker) {
    if w == nil { return }
	s := r.getStats(w.ID)
    if s != nil {
	    atomic.AddInt64(&s.InFlightRequests, -1)
    }
}

func (r *Router) getStats(id int) *RouterStats {
    // Read lock is held by caller of SelectWorker, but this method needs care
    // Stats map should be immutable after init for max speed
    if s, ok := r.stats[id]; ok {
        return s
    }
    return nil
}

// InitializeStats ensures the map is populated (called after Pool Init)
func (r *Router) InitializeStats() {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, w := range r.pool.Workers {
		if _, ok := r.stats[w.ID]; !ok {
			r.stats[w.ID] = &RouterStats{}
		}
	}
}
