package worker

import (
	"fmt"
)

// ProtoVersion represents the schema compatibility of the C++ Worker.
type ProtoVersion int32

const (
	// Version 1: Initial schema
	ProtoV1 ProtoVersion = 1
	// Version 2: Added dynamic batching support (example increment)
	ProtoV2 ProtoVersion = 2
)

// VersionMatcher enforces backward compatibility during Rolling Upgrades.
type VersionMatcher struct{}

// IsCompatible identifies if the C++ worker can safely process the tenant's model payload.
// Rule: A C++ binary compiled with Proto Version X can accept any payload formulated 
// for Version X or lower. It CANNOT safely accept payloads requiring Version X+1 
// (because it doesn't have the logic to parse or utilize the new fields).
func (v *VersionMatcher) IsCompatible(tenantRequiredVersion, workerSupportedVersion int32) bool {
	return workerSupportedVersion >= tenantRequiredVersion
}

// FilterCompatibleWorkers takes a list of healthy workers and filters out those
// running obsolete C++ binaries that cannot handle the requested schema.
func (v *VersionMatcher) FilterCompatibleWorkers(workers []*Worker, requiredVersion int32) []*Worker {
	var compatible []*Worker

	for _, w := range workers {
		if !w.Healthy {
			continue // Skip dead workers entirely
		}
		
		if v.IsCompatible(requiredVersion, w.ProtoVersion) {
			compatible = append(compatible, w)
		} else {
			// This happens during a rolling upgrade where Go was updated, 
			// the new tenant's model requires V2 features, but this specific 
			// C++ worker hasn't been cycled/upgraded to V2 yet.
			// Go correctly avoids routing to it, preventing a hard crash.
			fmt.Printf("[ROUTING] Worker %d skipped (Proto V%d < Required V%d)\n", 
				w.ID, w.ProtoVersion, requiredVersion)
		}
	}

	return compatible
}
