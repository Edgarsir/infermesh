package worker

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"time"
)

// ProcessLauncher handles the complexities of spawning a C++ worker process.
// It manages Environment variables, socket paths, and I/O redirection.
type ProcessLauncher struct {
	BinaryPath string
	ModelPath  string
	BaseSocketPath string // e.g., /tmp/infermesh_
	LogDir     string
}

// LaunchConfig contains specific parameters for this worker instance.
type LaunchConfig struct {
	WorkerID int
	GPUIndex int
}

// LaunchedProcess wraps the running command and metadata.
type LaunchedProcess struct {
	Cmd        *exec.Cmd
	SocketPath string
	WorkerID   int
	ExitChan   chan error // Signals when the process dies
}

func NewProcessLauncher(binary, model, logDir string) *ProcessLauncher {
	return &ProcessLauncher{
		BinaryPath: binary,
		ModelPath:  model,
		BaseSocketPath: filepath.Join(os.TempDir(), "infermesh_worker_"),
		LogDir:     logDir,
	}
}

// Launch starts a new worker process.
// It returns immediately once the process is spawned (does not wait for completion).
func (pl *ProcessLauncher) Launch(ctx context.Context, cfg LaunchConfig) (*LaunchedProcess, error) {
	// 1. Assign Unique Socket Path
	socketPath := fmt.Sprintf("%s%d.sock", pl.BaseSocketPath, cfg.WorkerID)
	
	// 2. Prepare Command
	// We use exec.CommandContext so the process is killed if the parent context dies (optional)
	cmd := exec.CommandContext(ctx, pl.BinaryPath)
	
	// 3. Inject Environment Variables (The C++ config method)
	// We inherit current env and append our critical configs.
	cmd.Env = append(os.Environ(),
		fmt.Sprintf("INFERMESH_SOCKET_PATH=%s", socketPath),
		fmt.Sprintf("INFERMESH_MODEL_PATH=%s", pl.ModelPath),
		fmt.Sprintf("INFERMESH_GPU_ID=%d", cfg.GPUIndex),
		fmt.Sprintf("INFERMESH_WORKER_ID=%d", cfg.WorkerID),
	)

	// 4. Capture Stdout/Stderr
	// Redirect to specific log files for debugging crashes.
	logFile := filepath.Join(pl.LogDir, fmt.Sprintf("worker_%d.log", cfg.WorkerID))
	f, err := os.OpenFile(logFile, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		return nil, fmt.Errorf("failed to open log file: %w", err)
	}
	cmd.Stdout = f
	cmd.Stderr = f // Capture both streams

	// 5. Start Process (Non-blocking)
	fmt.Printf("[LAUNCHER] Spawning Worker %d (GPU %d) -> %s\n", cfg.WorkerID, cfg.GPUIndex, socketPath)
	if err := cmd.Start(); err != nil {
		f.Close()
		return nil, fmt.Errorf("failed to start process: %w", err)
	}

	// 6. Monitor Exit (Goroutine)
	exitChan := make(chan error, 1)
	go func() {
		// Wait for process to exit
		waitErr := cmd.Wait()
		f.Close() // Close log file handle
		
		// Map exit codes
		if exitErr, ok := waitErr.(*exec.ExitError); ok {
			status := exitErr.Sys().(syscall.WaitStatus)
			if status.Signaled() {
				// Killed by signal (e.g. SIGKILL, SIGSEGV)
				exitChan <- fmt.Errorf("process killed by signal %d", status.Signal())
			} else {
				// Exited with non-zero code
				exitChan <- fmt.Errorf("process exited with code %d", status.ExitStatus())
			}
		} else {
			// Clean exit (code 0) or other error
			exitChan <- waitErr
		}
		close(exitChan)
	}()

	return &LaunchedProcess{
		Cmd:        cmd,
		SocketPath: socketPath,
		WorkerID:   cfg.WorkerID,
		ExitChan:   exitChan,
	}, nil
}
