package worker

import (
	"context"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
	"time"
)

// StatusCode definitions for clarity
const (
	StatusStarting = "STARTING"
	StatusReady    = "READY"
	StatusCrashed  = "CRASHED"
	StatusDead     = "DEAD"
)

// WatchStatusFile monitors the worker status file.
// It returns true if the worker becomes READY, or false if it CRASHED or timed out.
func (w *Worker) WatchStatusFile(ctx context.Context, statusFilePath string) (bool, error) {
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()

	// Timeout logic should be handled by the passed context wrapper
	for {
		select {
		case <-ctx.Done():
			return false, ctx.Err() // Timeout or cancelled

		case <-ticker.C:
			// 1. Try to read file
			content, err := ioutil.ReadFile(statusFilePath)
			if os.IsNotExist(err) {
				continue // File not created yet, keep waiting
			}
			if err != nil {
				// Access error (log warning but keep trying?)
				continue
			}

			status := strings.TrimSpace(string(content))

			// 2. Check Signals
			if status == StatusReady {
				w.State = StatusReady // Update memory state
				w.Healthy = true
				return true, nil
			}
			
			if status == StatusCrashed {
				w.State = StatusCrashed
				w.Healthy = false
				return false, fmt.Errorf("worker reported fatal crash during startup")
			}
			
			// If file exists but is empty or garbage, wait.
		}
	}
}
