package worker

import (
	"fmt"
	"math"
	"sync"
)

// GPU status definitions.
const (
	GPUStatusHealthy = "HEALTHY"
	GPUStatusDead    = "DEAD"
)

// GPUContext tracks the utilization and health of a single physical GPU device.
type GPUContext struct {
	ID           int
	Status       string
	WorkerCount  int
	TenantCounts map[string]int // Number of workers per tenant on this GPU
	Workers      map[int]bool   // Set of worker IDs assigned to this GPU
}

// GPUManager handles intelligent device assignment, tenant affinity, and failure isolation.
type GPUManager struct {
	mu            sync.RWMutex
	GPUs          map[int]*GPUContext
	WorkerToGPU   map[int]int // Maps WorkerID to GPU ID
}

// NewGPUManager initializes the registry for a server with `numGPUs` devices.
func NewGPUManager(numGPUs int) *GPUManager {
	mgr := &GPUManager{
		GPUs:        make(map[int]*GPUContext),
		WorkerToGPU: make(map[int]int),
	}
	
	for i := 0; i < numGPUs; i++ {
		mgr.GPUs[i] = &GPUContext{
			ID:           i,
			Status:       GPUStatusHealthy,
			WorkerCount:  0,
			TenantCounts: make(map[string]int),
			Workers:      make(map[int]bool),
		}
	}
	return mgr
}

// AssignGPU determines the optimal GPU for a worker.
// `previousGPUID` can be provided (-1 if none) to maintain exact assignment for replacement workers.
func (m *GPUManager) AssignGPU(workerID int, tenantID string, previousGPUID int) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	// 1. Replacement Affinity: Try to place it exactly where its predecessor was.
	if previousGPUID >= 0 {
		if gpu, exists := m.GPUs[previousGPUID]; exists && gpu.Status == GPUStatusHealthy {
			m.assignToGpuUnsafe(gpu, workerID, tenantID)
			return previousGPUID, nil
		}
		fmt.Printf("[GPU_MGR] Previous GPU %d is dead or invalid. Reassigning worker %d.\n", previousGPUID, workerID)
	}

	// 2. Tenant Affinity & Load Balancing
	// Find the healthy GPU with the lowest overall WorkerCount.
	// Tie-breaker: Pick a GPU that already hosts workers for this tenant (cache locality).
	var bestGPU *GPUContext
	minLoad := math.MaxInt32
	maxTenantAffinity := -1

	for _, gpu := range m.GPUs {
		if gpu.Status != GPUStatusHealthy {
			continue
		}

		tenantWorkers := gpu.TenantCounts[tenantID]

		// Condition for "Better GPU":
		// - Strictly lower load
		// - Or equal load, but higher tenant affinity
		if gpu.WorkerCount < minLoad || (gpu.WorkerCount == minLoad && tenantWorkers > maxTenantAffinity) {
			minLoad = gpu.WorkerCount
			maxTenantAffinity = tenantWorkers
			bestGPU = gpu
		}
	}

	if bestGPU == nil {
		return -1, fmt.Errorf("no healthy GPUs available for assignment")
	}

	m.assignToGpuUnsafe(bestGPU, workerID, tenantID)
	return bestGPU.ID, nil
}

// internal helper, assumes lock is held
func (m *GPUManager) assignToGpuUnsafe(gpu *GPUContext, workerID int, tenantID string) {
	gpu.WorkerCount++
	gpu.TenantCounts[tenantID]++
	gpu.Workers[workerID] = true
	m.WorkerToGPU[workerID] = gpu.ID
	fmt.Printf("[GPU_MGR] Assigned Worker %d (Tenant %s) to GPU %d (Load: %d)\n", workerID, tenantID, gpu.ID, gpu.WorkerCount)
}

// ReleaseGPU frees up the resources tracked for a worker.
func (m *GPUManager) ReleaseGPU(workerID int, tenantID string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	gpuID, exists := m.WorkerToGPU[workerID]
	if !exists {
		return
	}

	gpu := m.GPUs[gpuID]
	gpu.WorkerCount--
	gpu.TenantCounts[tenantID]--
	if gpu.TenantCounts[tenantID] <= 0 {
		delete(gpu.TenantCounts, tenantID)
	}
	delete(gpu.Workers, workerID)
	delete(m.WorkerToGPU, workerID)

	fmt.Printf("[GPU_MGR] Released Worker %d from GPU %d\n", workerID, gpuID)
}

// MarkGPUDead quarantines a failing physical device (e.g., C++ reported unrecoverable SECDED ECC error).
func (m *GPUManager) MarkGPUDead(gpuID int) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if gpu, exists := m.GPUs[gpuID]; exists {
		gpu.Status = GPUStatusDead
		fmt.Printf("[GPU_MGR] CRITICAL: GPU %d marked DEAD. No new workers will be routed here.\n", gpuID)
	}
}

// ClearGPUError restores a GPU to the active pool (e.g., operator ran nvidia-smi -r).
func (m *GPUManager) ClearGPUError(gpuID int) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if gpu, exists := m.GPUs[gpuID]; exists {
		gpu.Status = GPUStatusHealthy
		fmt.Printf("[GPU_MGR] RECOVERY: GPU %d marked HEALTHY by operator.\n", gpuID)
	}
}
