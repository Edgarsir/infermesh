package artifact

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

// Downloader handles robust file transfer from S3/HTTP sources.
type Downloader struct {
	Client *http.Client
}

func NewDownloader() *Downloader {
	return &Downloader{
		Client: &http.Client{
			Timeout: 30 * time.Minute, // Long timeout for huge files
		},
	}
}

// DownloadFile implementation of resumable logical download.
// URL: Source. DestPath: Local file path.
func (d *Downloader) DownloadFile(ctx context.Context, url, destPath string) error {
	// 1. Check if file partially exists
	var startByte int64 = 0
	if info, err := os.Stat(destPath); err == nil {
		startByte = info.Size()
		fmt.Printf("[DOWNLOAD] Resuming from byte %d\n", startByte)
	}

	// 2. Prepare Request with Range Header
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return err
	}

	if startByte > 0 {
		req.Header.Set("Range", fmt.Sprintf("bytes=%d-", startByte))
	}

	// 3. Execute Request
	resp, err := d.Client.Do(req)
	if err != nil {
		return fmt.Errorf("network error: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusRequestedRangeNotSatisfiable {
		return nil // Already fully downloaded
	}
	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusPartialContent {
		return fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	// 4. Open Local File (Append Mode)
	flags := os.O_CREATE | os.O_WRONLY
	if startByte > 0 {
		flags |= os.O_APPEND
	}
	
	outFile, err := os.OpenFile(destPath, flags, 0644)
	if err != nil {
		return fmt.Errorf("file IO error: %w", err)
	}
	defer outFile.Close()

	// 5. Stream Copy (Efficient buffering)
	// io.Copy handles buffering automatically (typically 32KB chunks)
	// This prevents loading 10GB into RAM.
	n, err := io.Copy(outFile, resp.Body)
	if err != nil {
		return fmt.Errorf("stream copy failure: %w", err)
	}

	fmt.Printf("[DOWNLOAD] Downloaded %d bytes.\n", n)
	return nil
}
