package artifact

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
)

// Verifier handles integrity checking of downloaded models.
type Verifier struct{}

// VerifyHash computes SHA-256 of filePath and compares it to expectedHash.
// Returns nil on match, error on mismatch or IO failure.
// On mismatch, it DELETES the corrupted file to prevent usage.
func (v *Verifier) VerifyHash(filePath string, expectedHash string) error {
	f, err := os.Open(filePath)
	if err != nil {
		return fmt.Errorf("failed to open file for verification: %w", err)
	}
	defer f.Close()

	hasher := sha256.New()
	
	// Stream the file through the hasher (efficient for large files)
	if _, err := io.Copy(hasher, f); err != nil {
		return fmt.Errorf("failed to compute hash: %w", err)
	}

	computed := hex.EncodeToString(hasher.Sum(nil))

	if computed != expectedHash {
		// critical: Delete corrupted file
		f.Close() // Ensure handle is released before delete
		if delErr := os.Remove(filePath); delErr != nil {
			return fmt.Errorf("hash mismatch (%s != %s) AND failed to delete file: %v", computed, expectedHash, delErr)
		}
		return fmt.Errorf("integrity failure: hash mismatch. Computed %s, Expected %s. File deleted.", computed, expectedHash)
	}

	fmt.Printf("[VERIFY] Integrity Check Passed: %s\n", computed)
	return nil
}
