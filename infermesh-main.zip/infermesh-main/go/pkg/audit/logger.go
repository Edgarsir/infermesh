package audit

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"
)

// AuditEvent represents a single authenticated action taken by a human operator.
type AuditEvent struct {
	Timestamp     time.Time `json:"timestamp"`
	Actor         string    `json:"actor"`          // e.g., "admin_user_id", "mtls_cert_serial"
	Action        string    `json:"action"`         // e.g., "DEPLOY_MODEL", "UPDATE_RATE_LIMIT"
	TargetTenant  string    `json:"target_tenant"`  // e.g., "tenant-123"
	PreviousState string    `json:"previous_state,omitempty"`
	NewState      string    `json:"new_state"`
	
	// Cryptographic Chaining
	PreviousHash  string    `json:"previous_hash"`
	CurrentHash   string    `json:"current_hash"`
}

// AuditLogger manages the append-only, cryptographically chained human audit trail.
type AuditLogger struct {
	mu          sync.Mutex
	logFilePath string
	lastHash    string
	file        *os.File
}

// NewAuditLogger initializes the logger. If the file exists, it recovers the last hash.
func NewAuditLogger(filePath string) (*AuditLogger, error) {
	// Open file in append-only mode, create if it doesn't exist
	f, err := os.OpenFile(filePath, os.O_APPEND|os.O_CREATE|os.O_RDWR, 0644)
	if err != nil {
		return nil, fmt.Errorf("failed to open audit file: %w", err)
	}

	logger := &AuditLogger{
		logFilePath: filePath,
		lastHash:    "GENESIS", // Default root hash
		file:        f,
	}

	// In a real system, we'd read the last line of the file to recover the previous CurrentHash.
	// For immediate simulation, if file > 0 bytes, we just use a placeholder to represent recovery.
	stat, _ := f.Stat()
	if stat.Size() > 0 {
		logger.lastHash = "last_hash_recovered_from_disk"
	}

	return logger, nil
}

// LogAction computes the verifiable hash chain and writes the JSON record to disk.
func (a *AuditLogger) LogAction(actor, action, tenant, previousState, newState string) error {
	a.mu.Lock()
	defer a.mu.Unlock()

	event := AuditEvent{
		Timestamp:     time.Now().UTC(),
		Actor:         actor,
		Action:        action,
		TargetTenant:  tenant,
		PreviousState: previousState,
		NewState:      newState,
		PreviousHash:  a.lastHash,
	}

	// 1. Serialize deterministic fields for hashing
	rawToHash := fmt.Sprintf("%d:%s:%s:%s:%s:%s:%s",
		event.Timestamp.UnixNano(),
		event.Actor,
		event.Action,
		event.TargetTenant,
		event.PreviousState,
		event.NewState,
		event.PreviousHash,
	)

	// 2. Compute cryptographic link
	hash := sha256.Sum256([]byte(rawToHash))
	event.CurrentHash = hex.EncodeToString(hash[:])
	
	// 3. Update internal pointer chain
	a.lastHash = event.CurrentHash

	// 4. Serialize to JSON for append
	logBytes, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal audit event: %w", err)
	}
	
	// Append newline
	logBytes = append(logBytes, '\n')

	// 5. Write and Sync (fsync) to guarantee persistence
	if _, err := a.file.Write(logBytes); err != nil {
		return fmt.Errorf("failed to write audit event: %w", err)
	}
	if err := a.file.Sync(); err != nil {
		return fmt.Errorf("failed to fsync audit event: %w", err)
	}

	fmt.Printf("[AUDIT] Recorded [%s] %s -> %s (Hash: %s...)\n", actor, action, tenant, event.CurrentHash[:8])
	return nil
}

// Close gracefully closes the file descriptor.
func (a *AuditLogger) Close() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.file != nil {
		return a.file.Close()
	}
	return nil
}
