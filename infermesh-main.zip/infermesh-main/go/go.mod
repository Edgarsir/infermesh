module infermesh.com/core

go 1.25.5

require (
	github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
	github.com/google/uuid v1.6.0 // indirect
	golang.org/x/time v0.14.0 // indirect
)
